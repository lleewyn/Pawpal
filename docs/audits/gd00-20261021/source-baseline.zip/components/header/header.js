/**
 * header-auth.js — Cập nhật header dựa trên trạng thái đăng nhập
 */

(function() {
    function getCurrentUser() {
        try {
            const user = JSON.parse(localStorage.getItem('pawpal_current_user')) || null;
            if (user && (user.system_role === 'ADMIN' || user.system_role === 'STAFF' || user.system_role === 'MANAGER' || user.role === 'admin' || user.role === 'staff')) {
                return null;
            }
            return user;
        } catch {
            return null;
        }
    }

    function getRootPath() {
        const pathname = window.location.pathname;
        const searchTerms = ['/pages/', '/assets/'];
        for (const term of searchTerms) {
            const idx = pathname.toLowerCase().indexOf(term);
            if (idx !== -1) {
                const subPath = pathname.substring(idx + 1); // "pages/public/landing/landing.html"
                const depth = subPath.split('/').length - 1;
                return '../'.repeat(depth) || './';
            }
        }
        return './';
    }

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function sanitizeHref(url) {
        if (!url || typeof url !== 'string') return '#';
        const trimmed = url.trim();
        if (/^(javascript|data):/i.test(trimmed)) {
            return '#';
        }
        return trimmed;
    }

    function getSharedNotifications() {
        try {
            const currentUser = getCurrentUser();
            if (currentUser && currentUser.id) {
                const userNotis = JSON.parse(localStorage.getItem(`pawpal_notifications_${currentUser.id}`) || 'null');
                if (Array.isArray(userNotis)) return userNotis;
            }
            const notis = JSON.parse(localStorage.getItem('pawpal_notifications') || '[]');
            if (Array.isArray(notis) && notis.length > 0) return notis;
        } catch (e) {}
        return [];
    }

    function getRelativeTimeString(dateStr) {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr;
        const diffMs = Date.now() - date.getTime();
        const diffMin = Math.floor(diffMs / 60000);
        if (diffMin < 1) return 'Vừa xong';
        if (diffMin < 60) return `${diffMin} phút trước`;
        const diffHour = Math.floor(diffMin / 60);
        if (diffHour < 24) return `${diffHour} giờ trước`;
        const diffDay = Math.floor(diffHour / 24);
        if (diffDay < 7) return `${diffDay} ngày trước`;
        
        const d = String(date.getDate()).padStart(2, '0');
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const y = date.getFullYear();
        return `${d}/${m}/${y}`;
    }

    function renderNotifications() {
        const notis = getSharedNotifications();
        if (!notis || !notis.length) {
            return `
                <div style="padding: 24px; text-align: center; color: #4F7A65; font-size: 13.5px;">
                    Bạn không có thông báo mới nào.
                </div>
            `;
        }
        const sorted = [...notis].sort((a, b) => new Date(b.time || 0) - new Date(a.time || 0));
        return sorted.map(n => {
            const safeLink = sanitizeHref(n.link || n.url || '#');
            const safeTitle = escapeHtml(n.title || 'Thông báo');
            const safeContent = escapeHtml(n.content || n.message || '');
            const isRead = Boolean(n.read || n.isRead);
            return `
                <a href="${safeLink}" class="notification-item-dropdown ${isRead ? '' : 'unread'}" data-id="${escapeHtml(n.id)}">
                    ${!isRead ? '<span class="unread-dot"></span>' : ''}
                    <span class="item-content">
                        <span class="item-title">${safeTitle}</span>
                        <span class="item-text">${safeContent}</span>
                        <span class="item-time">${getRelativeTimeString(n.time || n.sent_at)}</span>
                    </span>
                </a>
            `;
        }).join('');
    }

    window.updateNotificationBadge = function() {
        const notis = getSharedNotifications();
        const unreadCount = notis.filter(n => !n.read && !n.isRead).length;
        const badge = document.getElementById('notificationBadge');
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount > 9 ? '9+' : unreadCount;
                badge.style.display = 'flex';
            } else {
                badge.style.display = 'none';
                badge.textContent = '0';
            }
        }
        const list = document.getElementById('headerNotificationList');
        if (list) {
            list.innerHTML = renderNotifications();
            // Gắn sự kiện click cho từng item
            list.querySelectorAll('.notification-item-dropdown').forEach(item => {
                item.addEventListener('click', (e) => {
                    const notiId = item.getAttribute('data-id');
                    const allNotis = getSharedNotifications();
                    const targetNoti = allNotis.find(x => String(x.id) === String(notiId));
                    if (targetNoti) {
                        targetNoti.read = true;
                        targetNoti.isRead = true;
                        const currentUser = getCurrentUser();
                        if (currentUser && currentUser.id) {
                            localStorage.setItem(`pawpal_notifications_${currentUser.id}`, JSON.stringify(allNotis));
                        }
                        localStorage.setItem('pawpal_notifications', JSON.stringify(allNotis));
                        window.updateNotificationBadge();

                        // Cập nhật bền vững lên Supabase
                        const client = window.getSupabaseClient?.() || window.SupabaseClient;
                        if (client && notiId && !String(notiId).startsWith('seed-') && !String(notiId).startsWith('local-')) {
                            client.from('notification')
                                .update({ is_read: true, read_at: new Date().toISOString() })
                                .eq('id', notiId)
                                .then()
                                .catch(() => {});
                        }
                    }
                });
            });
        }
    };

    document.addEventListener('notifications_updated', () => {
        if (typeof window.updateNotificationBadge === 'function') {
            window.updateNotificationBadge();
        }
    });

    let cartBadgeRevision = 0;
    window.updateCartBadge = async function() {
        const revision = ++cartBadgeRevision;
        const currentUser = (typeof window.getCurrentUser === 'function')
            ? window.getCurrentUser()
            : (function() { try { return JSON.parse(localStorage.getItem('pawpal_current_user')) || null; } catch { return null; }})();

        // Lựa chọn A: Chỉ hiển thị giỏ hàng khi người dùng ĐÃ ĐĂNG NHẬP chính thức
        if (!currentUser || currentUser.is_temporary) {
            const cartBadges = document.querySelectorAll('.cart-badge');
            cartBadges.forEach(badge => {
                badge.textContent = '0';
                badge.style.display = 'none';
                badge.classList.add('d-none');
                badge.classList.remove('d-flex');
            });
            const cartBadgeMobile = document.querySelector('.cart-badge-mobile');
            if (cartBadgeMobile) {
                cartBadgeMobile.textContent = '';
            }
            return;
        }

        let totalItems = 0;
        let hasLocalCart = false;
        try {
            const rawCart = localStorage.getItem('pawpal_cart');
            if (rawCart !== null && localStorage.getItem('pawpal_cart_owner') === String(currentUser.id)) {
                hasLocalCart = true;
                const cartList = JSON.parse(rawCart);
                if (Array.isArray(cartList)) {
                    totalItems = cartList.reduce((sum, item) => sum + Number(item.quantity ?? item.qty ?? 1), 0);
                }
            }
        } catch(e) {}
            
        if (!hasLocalCart && currentUser && currentUser.id && window.API && window.API.getUserCart) {
            try {
                const cart = await window.API.getUserCart(currentUser.id);
                if (Array.isArray(cart)) {
                    totalItems = cart.reduce((sum, item) => sum + Number(item.quantity ?? item.qty ?? 1), 0);
                }
            } catch (e) {
                console.error("Failed to update cart badge", e);
            }
        }
        
        if (revision !== cartBadgeRevision || getCurrentUser()?.id !== currentUser.id) return;
        // Badge trên desktop header
        const cartBadges = document.querySelectorAll('.cart-badge');
        cartBadges.forEach(badge => {
            if (totalItems > 0) {
                badge.textContent = totalItems > 99 ? '99+' : totalItems;
                badge.style.display = 'flex';
                badge.classList.add('d-flex');
                badge.classList.remove('d-none');
            } else {
                badge.textContent = '0';
                badge.style.display = 'none';
                badge.classList.add('d-none');
                badge.classList.remove('d-flex');
            }
        });
        
        // Badge trên mobile nav drawer
        const cartBadgeMobile = document.querySelector('.cart-badge-mobile');
        if (cartBadgeMobile) {
            cartBadgeMobile.textContent = totalItems > 0 ? `(${totalItems})` : '';
        }
    };

    function setMobileGroupVisibility(elements, isVisible) {
        elements.forEach(el => {
            const item = el.closest('.nav-item') || el;
            if (isVisible) {
                item.classList.remove('d-none');
            } else {
                item.classList.add('d-none');
            }
        });
    }

    function syncMobileAuthLinks(state) {
        const nav = document.getElementById('primaryNavigation');
        if (!nav) return;

        const loginLinks = nav.querySelectorAll(
            'a[href*="/login"], a[href*="login.html"], a[href*="#register"], a[href*="action=register"]'
        );
        const guestLoginItems = nav.querySelectorAll(
            '.mobile-guest-only, .mobile-auth-login'
        );
        const userOnlyItems = nav.querySelectorAll('.mobile-user-only');
        const tempOnlyItems = nav.querySelectorAll('.mobile-temp-only');

        const isUser = state === 'user';
        const isTemp = state === 'temp';

        loginLinks.forEach((link) => {
            const label = (link.textContent || '').trim().toLowerCase();
            if (label.includes('đăng nhập') || label.includes('đăng ký') || label.includes('login') || label.includes('register')) {
                const item = link.closest('.nav-item') || link;
                if (isUser) {
                    item.classList.add('d-none');
                } else if (!isTemp) {
                    item.classList.remove('d-none');
                }
            }
        });

        setMobileGroupVisibility(guestLoginItems, !isUser && !isTemp);
        setMobileGroupVisibility(userOnlyItems, isUser);
        setMobileGroupVisibility(tempOnlyItems, isTemp);
    }

    async function resolveUserDisplayName(user) {
        if (!user) return user;
        const currentName = String(user.name || '').trim();
        const currentPhone = String(user.phone || '').trim();
        const looksLikePhone = /^\d{8,15}$/.test(currentName.replace(/\s+/g, '')) || (currentPhone && currentName === currentPhone);
        const looksLikeEmail = currentName.includes('@');
        if (currentName && !looksLikePhone && !looksLikeEmail) return user;

        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !user.id) return user;

        try {
            const { data, error } = await db
                .from('customer')
                .select(`
                    phone_main,
                    email,
                    customer_profile ( full_name )
                `)
                .eq('id', user.id)
                .limit(1);

            if (error || !data || !data.length) return user;

            const row = data[0];
            const profile = Array.isArray(row.customer_profile) ? (row.customer_profile[0] || {}) : (row.customer_profile || {});
            const resolvedName = String(profile.full_name || '').trim()
                || (currentName && !currentName.includes('@') ? currentName : '')
                || String(row.phone_main || user.phone || '').trim()
                || 'Khách hàng';
            const updatedUser = {
                ...user,
                name: resolvedName,
                phone: row.phone_main || user.phone || '',
                email: row.email || user.email || '',
            };

            localStorage.setItem('pawpal_current_user', JSON.stringify(updatedUser));
            return updatedUser;
        } catch (err) {
            console.warn('[header-auth] Cannot resolve user display name:', err);
            return user;
        }
    }

    function updateHeaderAuth() {
        const isGuestLookupPage = window.location.pathname.includes('return-guest');
        const user = isGuestLookupPage ? null : getCurrentUser();
        const authActions = document.querySelector('.auth-actions');
        const lookupBtn = document.querySelector('.lookup-btn');
        const lookupDivider = document.querySelector('.lookup-divider');
        const primaryNavigation = document.getElementById('primaryNavigation');
        
        const mobileGuestOnly = document.querySelectorAll('.mobile-guest-only');
        const mobileUserOnly = document.querySelectorAll('.mobile-user-only');
        const mobileTempOnly = document.querySelectorAll('.mobile-temp-only');
        document
            .querySelectorAll('#primaryNavigation .mobile-guest-only, #primaryNavigation .mobile-user-only, #primaryNavigation .mobile-temp-only, #primaryNavigation .nav-link-cta-mobile')
            .forEach(el => {
                const item = el.closest('.nav-item');
                if (!item) return;
                item.classList.remove('d-lg-none');
                item.classList.add('mobile-drawer-only');
            });
        
        if (!authActions) return; // Header chưa load
        
        const root = getRootPath();
        if (primaryNavigation) {
            primaryNavigation.classList.remove('nav-auth-user', 'nav-auth-temp', 'nav-auth-guest');
        }
        
        if (user && !user.is_temporary) {
            if (primaryNavigation) primaryNavigation.classList.add('nav-auth-user');
            // User đã đăng nhập chính thức
            // Ẩn: Tra cứu, Đăng nhập, Đăng ký và divider
            if (lookupBtn) lookupBtn.classList.add('d-none');
            if (lookupDivider) lookupDivider.classList.add('d-none');
            
            // Thay bằng: Giỏ hàng + Avatar + Tên + Dropdown
            const userName = String(user.name || user.full_name || '').trim() || user.phone || 'Khách hàng';
            const userInitial = userName.charAt(0).toUpperCase();

            // Cập nhật tên nền từ Supabase nếu cần
            resolveUserDisplayName(user).then((resolved) => {
                if (resolved && resolved.name && resolved.name !== userName) {
                    const nameEl = document.querySelector('.user-name');
                    if (nameEl) nameEl.textContent = resolved.name;
                    const infoNameEl = document.querySelector('.user-info-name');
                    if (infoNameEl) infoNameEl.textContent = resolved.name;
                }
            }).catch(() => {});
            
            const existingDropdown = authActions.querySelector('#userDropdown');
            if (!existingDropdown) {
                authActions.innerHTML = `
                    <div class="notification-menu-wrapper me-3">
                        <button class="notification-btn position-relative" id="headerNotificationBtn" title="Thông báo" type="button">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                            </svg>
                            <span class="notification-badge" id="notificationBadge">0</span>
                        </button>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-dropdown-header">
                                <span>Thông báo</span>
                                <button class="btn-mark-all-read" id="btnMarkAllRead" type="button">Đọc tất cả</button>
                            </div>
                            <div class="notification-list" id="headerNotificationList">
                                ${renderNotifications()}
                            </div>
                            <div class="notification-dropdown-footer">
                                <a href="/pages/user/#notifications" id="btnSeeAllNotis">Xem tất cả</a>
                            </div>
                        </div>
                    </div>
                    <a href="/cart" class="cart-btn position-relative me-3" id="headerCartBtn" title="Giỏ hàng của tôi">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="20" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        <span class="cart-badge">0</span>
                    </a>
                    <div class="user-menu-wrapper">
                        <button class="user-menu-toggle" id="userMenuToggle">
                            <div class="user-avatar">${userInitial}</div>
                            <span class="user-name">${userName}</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                        </button>
                        <div class="user-dropdown" id="userDropdown">
                            <div class="dropdown-header">
                                <div class="user-avatar-large">${userInitial}</div>
                                <div class="user-info">
                                    <div class="user-info-name">${userName}</div>
                                    <div class="user-info-phone">${user.phone || ''}</div>
                                    <div class="user-info-points">${user.points || 0} Paw Points</div>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a href="/pages/user/#profile" class="dropdown-item">Tài khoản của tôi</a>
                            <a href="/pages/user/#pets" class="dropdown-item">Hồ sơ bé cưng</a>
                            <a href="/pages/user/#bookings" class="dropdown-item">Lịch hẹn của bé</a>
                            <a href="/pages/user/#orders" class="dropdown-item">Đơn hàng của bé</a>
                            <a href="/pages/user/#wishlist" class="dropdown-item">Yêu thích</a>
                            <a href="/pages/user/#diary" class="dropdown-item">Nhật ký chăm sóc</a>
                            <a href="/pages/user/#loyalty" class="dropdown-item">Paw Points</a>
                            <a href="/pages/user/#settings" class="dropdown-item">Cài đặt</a>
                            <div class="dropdown-divider"></div>
                            <button class="dropdown-item dropdown-item-danger" id="btnLogout">Đăng xuất</button>
                        </div>
                    </div>
                `;
            } else {
                const nameEl = authActions.querySelector('.user-name');
                if (nameEl && nameEl.textContent !== userName) nameEl.textContent = userName;
                const avatarEl = authActions.querySelector('.user-avatar');
                if (avatarEl && avatarEl.textContent !== userInitial) avatarEl.textContent = userInitial;
            }
            
            // Cập nhật Mobile Nav
            setMobileGroupVisibility(mobileGuestOnly, false);
            setMobileGroupVisibility(mobileUserOnly, true);
            setMobileGroupVisibility(mobileTempOnly, false);
            syncMobileAuthLinks('user');
            setupMobileAccountToggle();
            
            // Gắn sự kiện đóng mở dropdown
            setupUserDropdown();
            
        } else if (user && user.is_temporary) {
            if (primaryNavigation) primaryNavigation.classList.add('nav-auth-temp');
            if (lookupBtn) lookupBtn.classList.remove('d-none');
            if (lookupDivider) lookupDivider.classList.remove('d-none');

            // Lựa chọn A: Ẩn giỏ hàng khi là tài khoản tạm thời
            authActions.innerHTML = `
                <a href="/login" class="login-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                    <span>Đăng nhập</span>
                </a>
                <a href="/login?action=setup-password" class="btn-signup">Kích hoạt</a>
            `;

            // Mobile Nav
            setMobileGroupVisibility(mobileGuestOnly, false);
            setMobileGroupVisibility(mobileUserOnly, false);
            setMobileGroupVisibility(mobileTempOnly, true);
            syncMobileAuthLinks('temp');
            setupMobileAccountToggle();
            setupUserDropdown();
            
        } else {
            if (primaryNavigation) primaryNavigation.classList.add('nav-auth-guest');
            if (lookupBtn) lookupBtn.classList.remove('d-none');
            if (lookupDivider) lookupDivider.classList.remove('d-none');
            
            // Lựa chọn A: Ẩn giỏ hàng khi chưa đăng nhập (Khách vãng lai), hiện rõ ràng Đăng nhập / Đăng ký
            authActions.innerHTML = `
                <a href="/login" class="login-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                    <span>Đăng nhập</span>
                </a>
                <a href="/login#register" class="btn-signup">Đăng ký</a>
            `;
            
            // Cập nhật Mobile Nav
            setMobileGroupVisibility(mobileGuestOnly, true);
            setMobileGroupVisibility(mobileUserOnly, false);
            setMobileGroupVisibility(mobileTempOnly, false);
            syncMobileAuthLinks('guest');
            setupMobileAccountToggle();
            setupUserDropdown();
        }

        // Thực thi cập nhật số lượng badge tức thì
        if (typeof window.updateNotificationBadge === 'function') {
            window.updateNotificationBadge();
        }
        window.updateCartBadge(true);
    }
    
    function setupUserDropdown() {
        const toggle = document.getElementById('userMenuToggle');
        const dropdown = document.getElementById('userDropdown');
        const notiToggle = document.getElementById('headerNotificationBtn');
        const notiDropdown = document.getElementById('notificationDropdown');
        
        if (toggle && dropdown && toggle.dataset.dropdownBound !== 'true') {
            toggle.dataset.dropdownBound = 'true';
            toggle.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
                if (notiDropdown) notiDropdown.classList.remove('show');
            });
        }

        if (notiToggle && notiDropdown && notiToggle.dataset.dropdownBound !== 'true') {
            notiToggle.dataset.dropdownBound = 'true';
            notiToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                notiDropdown.classList.toggle('show');
                if (dropdown) dropdown.classList.remove('show');
            });

            const btnMarkAll = notiDropdown.querySelector('#btnMarkAllRead');
            if (btnMarkAll && btnMarkAll.dataset.bound !== 'true') {
                btnMarkAll.dataset.bound = 'true';
                btnMarkAll.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const currentUser = getCurrentUser();
                    try {
                        const notis = getSharedNotifications();
                        if (Array.isArray(notis)) {
                            notis.forEach(n => { n.read = true; n.isRead = true; });
                            if (currentUser && currentUser.id) {
                                localStorage.setItem(`pawpal_notifications_${currentUser.id}`, JSON.stringify(notis));
                            }
                            localStorage.setItem('pawpal_notifications', JSON.stringify(notis));
                            document.dispatchEvent(new CustomEvent('notifications_updated'));
                        }
                    } catch(err) {}

                    // Cập nhật bền vững lên Supabase
                    const client = window.getSupabaseClient?.() || window.SupabaseClient;
                    if (client && currentUser?.id) {
                        client.from('notification')
                            .update({ is_read: true, read_at: new Date().toISOString() })
                            .eq('customer_id', currentUser.id)
                            .eq('is_read', false)
                            .then()
                            .catch(() => {});
                    }

                    const list = document.getElementById('headerNotificationList');
                    if (list) list.innerHTML = renderNotifications();
                    const badge = document.getElementById('notificationBadge');
                    if (badge) {
                        badge.style.display = 'none';
                        badge.textContent = '0';
                    }
                });
            }
            const btnSeeAll = notiDropdown.querySelector('#btnSeeAllNotis');
            if (btnSeeAll && btnSeeAll.dataset.bound !== 'true') {
                btnSeeAll.dataset.bound = 'true';
                btnSeeAll.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    notiDropdown.classList.remove('show');
                    openAllNotificationsModal();
                });
            }
        }
        
        setupLogoutButtons();
    }

    // Đóng dropdown khi click ra ngoài (đăng ký 1 lần duy nhất)
    document.addEventListener('click', (e) => {
        const dropdown = document.getElementById('userDropdown');
        const notiDropdown = document.getElementById('notificationDropdown');
        if (dropdown && !e.target.closest('.user-menu-wrapper')) {
            dropdown.classList.remove('show');
        }
        if (notiDropdown && !e.target.closest('.notification-menu-wrapper')) {
            notiDropdown.classList.remove('show');
        }
    });

    async function handleGlobalLogout(e) {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        const client = window.getSupabaseClient?.() || window.SupabaseClient;
        if (client) {
            const { error } = await client.auth.signOut();
            if (error) { console.error('[Header] Không thể đăng xuất:', error.message); return; }
        }
        try {
            localStorage.removeItem('pawpal_current_user');
            sessionStorage.removeItem('pawpal_current_user');
            localStorage.removeItem('pawpal_cart');
            sessionStorage.removeItem('pawpal_cart');
            localStorage.removeItem('pawpal_notifications');
            sessionStorage.removeItem('pawpal_component_site-header');
            localStorage.removeItem('pawpal_component_site-header');
        } catch(err) {}
        
        document.dispatchEvent(new CustomEvent('auth_state_changed', { detail: null }));
        window.location.href = '/';
    }

    window.pawpalLogout = handleGlobalLogout;

    function setupLogoutButtons() {
        document.querySelectorAll('#btnLogout, #logoutBtn, #tempLogoutBtn, #sidebarLogoutBtn, #nav-logout, .mobile-logout-btn, .sidebar-logout-btn, .dropdown-item-danger, a[href*="logout"]').forEach(btn => {
            if (btn.dataset.logoutBound === 'true') return;
            btn.addEventListener('click', handleGlobalLogout);
            btn.dataset.logoutBound = 'true';
        });
    }

    // Global event delegation for logout buttons anywhere in DOM
    document.addEventListener('click', (e) => {
        const logoutTarget = e.target.closest('#btnLogout, #logoutBtn, #tempLogoutBtn, #sidebarLogoutBtn, #nav-logout, .mobile-logout-btn, .sidebar-logout-btn, .dropdown-item-danger, a[href="#logout"]');
        if (logoutTarget) {
            handleGlobalLogout(e);
        }
    });

    // -------------------------------------------------------------
    // POPUP MODAL TRUNG TÂM THÔNG BÁO (MODAL THEO CHUẨN AGENTS.MD)
    // -------------------------------------------------------------
    function formatNotiTime(timeStr) {
        if (!timeStr) return '';
        const date = new Date(timeStr);
        if (isNaN(date.getTime())) return timeStr;
        const diffMs = Date.now() - date.getTime();
        const diffMin = Math.floor(diffMs / 60000);
        if (diffMin < 1) return 'Vừa xong';
        if (diffMin < 60) return `${diffMin} phút trước`;
        const diffHour = Math.floor(diffMin / 60);
        if (diffHour < 24) return `${diffHour} giờ trước`;
        const diffDay = Math.floor(diffHour / 24);
        if (diffDay < 7) return `${diffDay} ngày trước`;
        const hours = String(date.getHours()).padStart(2, '0');
        const mins = String(date.getMinutes()).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const y = date.getFullYear();
        return `${hours}:${mins} • ${d}/${m}/${y}`;
    }

    function getNotiCategoryName(noti) {
        const type = String(noti.type || noti.notification_type || '').toLowerCase();
        const title = String(noti.title || '').toLowerCase();
        if (type.includes('lich_hen') || type.includes('service') || type === 'booking' || title.includes('dịch vụ') || title.includes('spa') || title.includes('lịch') || title.includes('khám')) return 'Dịch vụ';
        if (type.includes('don_hang') || type.includes('order') || title.includes('đơn hàng') || title.includes('giao')) return 'Đơn hàng';
        if (type.includes('ho_tro') || type.includes('support') || title.includes('hỗ trợ') || title.includes('khiếu nại')) return 'Hỗ trợ';
        if (type.includes('hoan_tien') || type.includes('refund') || title.includes('hoàn tiền')) return 'Hoàn tiền';
        if (type.includes('uu_dai') || type.includes('promo') || title.includes('khuyến mãi') || title.includes('giảm giá') || title.includes('voucher') || title.includes('pawpoint')) return 'Ưu đãi';
        return 'Thông báo';
    }

    function openAllNotificationsModal(initialNoti = null) {
        let overlay = document.getElementById('pawpalAllNotiModalOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'pawpalAllNotiModalOverlay';
            overlay.className = 'pawpal-noti-modal-overlay';
            overlay.innerHTML = `
                <div class="pawpal-noti-modal-card pawpal-noti-modal-2col" role="dialog" aria-modal="true">
                    <div class="pawpal-noti-modal-header" id="notiModalHeader">
                        <div>
                            <h3 class="pawpal-noti-modal-title" id="notiModalMainTitle">Trung tâm thông báo</h3>
                        </div>
                        <div class="d-flex align-items-center gap-3">
                            <button type="button" class="btn-modal-mark-all" id="btnModalMarkAllRead">Đọc tất cả</button>
                            <button type="button" class="btn-close-noti-modal" id="btnCloseNotiModal">&times;</button>
                        </div>
                    </div>
                    
                    <div class="pawpal-noti-modal-split-body">
                        <!-- Cột Trái: Tabs Lọc & Danh Sách Thông Báo -->
                        <div class="pawpal-noti-left-col">
                            <div class="pawpal-noti-modal-tabs" id="notiModalTabs">
                                <button type="button" class="noti-tab-btn active" data-tab="all">Tất cả</button>
                                <span class="noti-tab-divider">|</span>
                                <button type="button" class="noti-tab-btn" data-tab="unread">Chưa đọc</button>
                                <span class="noti-tab-divider">|</span>
                                <button type="button" class="noti-tab-btn" data-tab="service">Dịch vụ</button>
                                <span class="noti-tab-divider">|</span>
                                <button type="button" class="noti-tab-btn" data-tab="order">Đơn hàng</button>
                            </div>
                            <div class="pawpal-noti-items-scroll" id="notiModalListBody">
                                <!-- Danh sách thông báo -->
                            </div>
                        </div>

                        <!-- Cột Phải: Khung Chi Tiết Thông Báo -->
                        <div class="pawpal-noti-right-col" id="notiModalDetailPane">
                            <!-- Chi tiết thông báo đang chọn -->
                        </div>
                    </div>

                    <div class="pawpal-noti-modal-footer" id="notiModalFooter">
                        <button type="button" class="btn-modal-close-action" id="btnFooterCloseNotiModal">Đóng</button>
                    </div>
                </div>
            `;
            document.body.appendChild(overlay);

            // Gắn sự kiện đóng
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) closeNotiModal();
            });
            overlay.querySelector('#btnCloseNotiModal').addEventListener('click', closeNotiModal);
            overlay.querySelector('#btnFooterCloseNotiModal').addEventListener('click', closeNotiModal);

            // Đánh dấu đã đọc tất cả
            overlay.querySelector('#btnModalMarkAllRead').addEventListener('click', () => {
                const currentUser = getCurrentUser();
                try {
                    const notis = getSharedNotifications();
                    if (Array.isArray(notis)) {
                        notis.forEach(n => { n.read = true; n.isRead = true; });
                        if (currentUser && currentUser.id) {
                            localStorage.setItem(`pawpal_notifications_${currentUser.id}`, JSON.stringify(notis));
                        }
                        localStorage.setItem('pawpal_notifications', JSON.stringify(notis));
                        document.dispatchEvent(new CustomEvent('notifications_updated'));
                    }
                } catch(e) {}

                // Cập nhật bền vững lên Supabase
                const client = window.getSupabaseClient?.() || window.SupabaseClient;
                if (client && currentUser?.id) {
                    client.from('notification')
                        .update({ is_read: true, read_at: new Date().toISOString() })
                        .eq('customer_id', currentUser.id)
                        .eq('is_read', false)
                        .then()
                        .catch(() => {});
                }

                const badge = document.getElementById('notificationBadge');
                if (badge) {
                    badge.style.display = 'none';
                    badge.textContent = '0';
                }
                const headerList = document.getElementById('headerNotificationList');
                if (headerList) headerList.innerHTML = renderNotifications();
                renderModalNotiList('all');
            });

            // Tabs chuyển đổi
            overlay.querySelectorAll('.noti-tab-btn').forEach(tabBtn => {
                tabBtn.addEventListener('click', () => {
                    overlay.querySelectorAll('.noti-tab-btn').forEach(b => b.classList.remove('active'));
                    tabBtn.classList.add('active');
                    renderModalNotiList(tabBtn.dataset.tab);
                });
            });

            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && overlay.classList.contains('show')) {
                    closeNotiModal();
                }
            });
        }

        function closeNotiModal() {
            overlay.classList.remove('show');
            document.body.style.overflow = '';
        }

        let currentSelectedNotiId = null;

        function renderDetailPane(noti) {
            const detailPane = overlay.querySelector('#notiModalDetailPane');
            if (!detailPane) return;

            if (!noti) {
                detailPane.innerHTML = `
                    <div class="pawpal-noti-detail-empty">
                        <p class="pawpal-noti-detail-empty-title">Chi tiết thông báo</p>
                        <p class="pawpal-noti-detail-empty-desc">Chọn một thông báo từ danh sách bên trái để xem nội dung đầy đủ.</p>
                    </div>
                `;
                return;
            }

            // Đánh dấu đã đọc
            noti.isRead = true;
            noti.read = true;
            try {
                const notis = getSharedNotifications();
                if (Array.isArray(notis)) {
                    const found = notis.find(x => String(x.id) === String(noti.id));
                    if (found) {
                        found.read = true;
                        found.isRead = true;
                    }
                    const currentUser = getCurrentUser();
                    if (currentUser && currentUser.id) {
                        localStorage.setItem(`pawpal_notifications_${currentUser.id}`, JSON.stringify(notis));
                    }
                    localStorage.setItem('pawpal_notifications', JSON.stringify(notis));
                    document.dispatchEvent(new CustomEvent('notifications_updated'));
                }
            } catch(e) {}

            // Cập nhật bền vững lên Supabase
            const client = window.getSupabaseClient?.() || window.SupabaseClient;
            if (client && noti.id && !String(noti.id).startsWith('seed-') && !String(noti.id).startsWith('local-')) {
                client.from('notification')
                    .update({ is_read: true, read_at: new Date().toISOString() })
                    .eq('id', noti.id)
                    .then()
                    .catch(() => {});
            }

            // Cập nhật giao diện thẻ bên trái
            const activeCard = overlay.querySelector(`.pawpal-noti-modal-item[data-id="${noti.id}"]`);
            if (activeCard) {
                activeCard.classList.remove('unread');
                activeCard.classList.add('selected');
                const dot = activeCard.querySelector('.pawpal-noti-unread-dot');
                if (dot) dot.remove();
            }

            const category = getNotiCategoryName(noti);
            const formattedTime = formatNotiTime(noti.time);
            
            // Xử lý link đích nếu có
            let actionText = '';
            let rawUrl = noti.url || noti.link || '#';
            if (category === 'Dịch vụ') {
                actionText = 'Xem lịch hẹn của bé';
                if (!rawUrl || rawUrl === '#') {
                    rawUrl = noti.appointment_id
                        ? `/pages/user/#booking-detail?id=${encodeURIComponent(noti.appointment_id)}`
                        : '/pages/user/#bookings';
                }
            } else if (category === 'Đơn hàng') {
                actionText = 'Xem đơn hàng của bé';
                if (!rawUrl || rawUrl === '#') {
                    rawUrl = noti.sales_order_id
                        ? `/pages/user/#order-detail?id=${encodeURIComponent(noti.sales_order_id)}`
                        : '/pages/user/#orders';
                }
            } else if (category === 'Ưu đãi') {
                actionText = 'Xem ưu đãi Paw Points';
                if (!rawUrl || rawUrl === '#') rawUrl = '/pages/user/#loyalty';
            } else if (category === 'Hỗ trợ') {
                actionText = 'Xem phiếu hỗ trợ';
                if (!rawUrl || rawUrl === '#') {
                    rawUrl = noti.support_ticket_id
                        ? `/pages/user/#support?id=${encodeURIComponent(noti.support_ticket_id)}`
                        : '/pages/user/#support';
                }
            } else if (category === 'Hoàn tiền') {
                actionText = 'Xem đơn hàng hoàn tiền';
                if (!rawUrl || rawUrl === '#') {
                    rawUrl = noti.sales_order_id
                        ? `/pages/user/#order-detail?id=${encodeURIComponent(noti.sales_order_id)}`
                        : '/pages/user/#orders';
                }
            } else if (rawUrl && rawUrl !== '#' && rawUrl !== '') {
                actionText = 'Đến trang liên kết';
            }
            const safeTargetUrl = sanitizeHref(rawUrl);

            detailPane.innerHTML = `
                <div class="pawpal-noti-detail-pane-content">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <span class="pawpal-noti-category-badge">${escapeHtml(category)}</span>
                        <span class="pawpal-noti-detail-time">${escapeHtml(formattedTime)}</span>
                    </div>
                    <h4 class="pawpal-noti-detail-title">${escapeHtml(noti.title)}</h4>
                    <div class="pawpal-noti-detail-content">
                        ${escapeHtml(noti.content || 'Không có nội dung chi tiết cho thông báo này.')}
                    </div>
                    ${actionText ? `
                        <div class="pawpal-noti-detail-action mt-4">
                            <a href="${safeTargetUrl}" class="btn-noti-action-cta" id="btnNotiDetailCTA">${escapeHtml(actionText)}</a>
                        </div>
                    ` : ''}
                </div>
            `;

            detailPane.querySelector('#btnNotiDetailCTA')?.addEventListener('click', (e) => {
                const href = e.currentTarget.getAttribute('href');
                if (href && href !== '#' && href !== '') {
                    closeNotiModal();
                    if (window.location.pathname.includes('/pages/user/') && href.includes('#')) {
                        const targetHash = href.substring(href.indexOf('#'));
                        window.location.hash = targetHash;
                        if (typeof window.handleHashRouting === 'function') {
                            window.handleHashRouting();
                        }
                    }
                }
            });
        }

        function renderModalNotiList(filterType = 'all', targetNotiId = null) {
            const listContainer = overlay.querySelector('#notiModalListBody');

            let items = [];
            try {
                const stored = getSharedNotifications();
                if (Array.isArray(stored) && stored.length > 0) {
                    items = stored.map(s => ({
                        id: s.id,
                        title: s.title,
                        content: s.content || s.message,
                        time: s.time,
                        isRead: Boolean(s.read || s.isRead),
                        type: s.type || s.notification_type || 'info',
                        url: s.link || s.url || '#',
                        sales_order_id: s.sales_order_id,
                        appointment_id: s.appointment_id,
                        support_ticket_id: s.support_ticket_id,
                        refund_transaction_id: s.refund_transaction_id
                    }));
                }
            } catch(e) {}

            let filtered = items;
            if (filterType === 'unread') {
                filtered = items.filter(n => !n.isRead);
            } else if (filterType === 'service') {
                filtered = items.filter(n => getNotiCategoryName(n) === 'Dịch vụ');
            } else if (filterType === 'order') {
                filtered = items.filter(n => getNotiCategoryName(n) === 'Đơn hàng');
            }

            if (!filtered.length) {
                listContainer.innerHTML = `
                    <div class="pawpal-noti-empty">
                        Không có thông báo nào trong mục này.
                    </div>
                `;
                renderDetailPane(null);
                return;
            }

            // Chọn thông báo mục tiêu hoặc thông báo đầu tiên
            let selectedItem = null;
            if (targetNotiId) {
                selectedItem = filtered.find(x => String(x.id) === String(targetNotiId));
            }
            if (!selectedItem && filtered.length > 0) {
                selectedItem = filtered[0];
            }
            currentSelectedNotiId = selectedItem ? selectedItem.id : null;

            listContainer.innerHTML = filtered.map(n => {
                const category = getNotiCategoryName(n);
                const displayTime = formatNotiTime(n.time);
                const isSelected = selectedItem && String(selectedItem.id) === String(n.id);
                return `
                    <div class="pawpal-noti-modal-item ${n.isRead ? '' : 'unread'} ${isSelected ? 'selected' : ''}" data-id="${escapeHtml(n.id)}">
                        ${!n.isRead ? '<span class="pawpal-noti-unread-dot"></span>' : ''}
                        <div class="pawpal-noti-modal-item-content">
                            <div class="d-flex align-items-center justify-content-between mb-1">
                                <span class="pawpal-noti-category-badge">${escapeHtml(category)}</span>
                                <span class="pawpal-noti-modal-item-time">${escapeHtml(displayTime)}</span>
                            </div>
                            <div class="pawpal-noti-modal-item-title">${escapeHtml(n.title)}</div>
                            <div class="pawpal-noti-modal-item-text">${escapeHtml(n.content || '')}</div>
                        </div>
                    </div>
                `;
            }).join('');

            // Gắn sự kiện click cho từng item
            listContainer.querySelectorAll('.pawpal-noti-modal-item').forEach(itemEl => {
                itemEl.addEventListener('click', () => {
                    const id = itemEl.dataset.id;
                    const notiObj = items.find(x => String(x.id) === String(id));
                    if (notiObj) {
                        listContainer.querySelectorAll('.pawpal-noti-modal-item').forEach(el => el.classList.remove('selected'));
                        itemEl.classList.add('selected');
                        currentSelectedNotiId = id;
                        renderDetailPane(notiObj);
                    }
                });
            });

            // Hiển thị chi tiết của item được chọn vào cột phải
            renderDetailPane(selectedItem);
        }

        const initialId = initialNoti ? initialNoti.id : null;
        renderModalNotiList('all', initialId);
        overlay.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    window.openAllNotificationsModal = openAllNotificationsModal;

    function setupMobileAccountToggle() {
        const accountGroup = document.querySelector('.mobile-account-group');
        const toggle = document.querySelector('.mobile-account-toggle');
        if (!accountGroup || !toggle) return;

        if (toggle.dataset.bound === '1') return;
        toggle.dataset.bound = '1';

        toggle.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const isOpen = accountGroup.classList.toggle('open');
            toggle.setAttribute('aria-expanded', String(isOpen));
            console.log('Toggle clicked, isOpen:', isOpen);
        });
    }


    
    // -------------------------------------------------------------
    // TÍCH HỢP DẢI THÔNG BÁO TOP-BAR TỪ PHÂN HỆ CẤU HÌNH ADMIN (GIAI ĐOẠN 2)
    // -------------------------------------------------------------
    function renderDynamicTopBarNotice() {
        try {
            const notices = JSON.parse(localStorage.getItem('pawpal_settings_notices') || '[]');
            const activeTopNotice = notices.find(n => n.status === 'active' && (n.type === 'Top-bar' || n.type === 'topbar'));
            
            // Tìm hoặc tạo container Topbar
            let topBarEl = document.getElementById('pawpal-public-topbar-notice');
            if (!activeTopNotice) {
                if (topBarEl) topBarEl.remove();
                return;
            }

            if (!topBarEl) {
                topBarEl = document.createElement('div');
                topBarEl.id = 'pawpal-public-topbar-notice';
                topBarEl.style.cssText = `
                    background-color: #236B48;
                    color: #FFFFFF;
                    font-size: 13px;
                    font-weight: 500;
                    text-align: center;
                    padding: 8px 16px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 12px;
                    z-index: 1050;
                    position: relative;
                    letter-spacing: 0.1px;
                `;
                const siteHeader = document.getElementById('mainHeader') || document.querySelector('.main-header') || document.getElementById('site-header') || document.body;
                if (siteHeader === document.body) {
                    document.body.insertBefore(topBarEl, document.body.firstChild);
                } else {
                    siteHeader.parentNode.insertBefore(topBarEl, siteHeader);
                }
            }

            const safeContent = escapeHtml(activeTopNotice.content || '');
            const rawNoticeLink = activeTopNotice.link;
            const safeNoticeLink = rawNoticeLink && rawNoticeLink !== '#' ? sanitizeHref(rawNoticeLink) : '';
            const noticeBodyHtml = safeNoticeLink && safeNoticeLink !== '#'
                ? `<a href="${safeNoticeLink}" style="color: #FFFFFF; text-decoration: underline; font-weight: 600;">${safeContent}</a>`
                : `<span>${safeContent}</span>`;

            topBarEl.innerHTML = `
                ${noticeBodyHtml}
                <button type="button" id="btnCloseTopBarNotice" style="background: none; border: none; color: rgba(255,255,255,0.8); cursor: pointer; font-size: 14px; padding: 0 4px; line-height: 1;" title="Đóng">✕</button>
            `;

            document.getElementById('btnCloseTopBarNotice')?.addEventListener('click', () => {
                topBarEl.style.display = 'none';
            });
        } catch (e) {
            console.warn('Lỗi hiển thị topbar notice:', e);
        }
    }

    // -------------------------------------------------------------
    // TÌM KIẾM TRÊN HEADER (DỊCH VỤ HOẶC SẢN PHẨM)
    // -------------------------------------------------------------
    function setupHeaderSearch() {
        document.querySelectorAll('.search-bar').forEach(bar => {
            if (bar.dataset.searchBound === 'true') return;

            const input = bar.querySelector('input');
            const icon = bar.querySelector('.search-icon');
            if (!input) return;
            bar.dataset.searchBound = 'true';

            const executeSearch = (event) => {
                event?.preventDefault?.();
                event?.stopPropagation?.();
                const query = input.value.trim();
                if (!query) return;
                const keyword = query.normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '').replace(/[đĐ]/g, 'd').toLowerCase();
                const serviceKeywords = new Set([
                    'taxi', 'pet taxi', 'dua ruoc',
                    'spa', 'pet spa',
                    'hotel', 'pet hotel', 'khach san', 'luu tru'
                ]);
                const destination = serviceKeywords.has(keyword) ? '/services' : '/shop';
                window.location.href = `${destination}?search=${encodeURIComponent(query)}`;
            };

            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    executeSearch(e);
                }
            });
            const form = input.closest('form');
            if (form) form.addEventListener('submit', executeSearch);

            if (icon) {
                icon.style.cursor = 'pointer';
                icon.style.pointerEvents = 'auto';
                icon.addEventListener('click', executeSearch);
            }
        });
    }

    // -------------------------------------------------------------
    // ĐIỀU KHIỂN MENU MOBILE DRAWER (HAMBURGER BUTTON)
    // -------------------------------------------------------------
    function initMobileNavigation() {
        const toggleBtn = document.getElementById('mobileNavToggle');
        const nav = document.getElementById('primaryNavigation');
        if (!toggleBtn || !nav) return;

        if (toggleBtn.dataset.mobileNavReady === 'true' && nav.dataset.mobileNavReady === 'true') {
            return;
        }

        let mobileOverlay = null;
        let previousOverflow = null;
        const closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'mobile-nav-close';
        closeBtn.setAttribute('aria-label', 'Đóng menu');
        closeBtn.textContent = 'Đóng';
        closeBtn.addEventListener('click', closeDrawer);
        nav.prepend(closeBtn);
        nav.setAttribute('data-lenis-prevent', '');
        function createOverlay() {
            if (mobileOverlay) return;
            mobileOverlay = document.createElement('div');
            mobileOverlay.className = 'mobile-nav-overlay';
            mobileOverlay.style.position = 'fixed';
            mobileOverlay.style.inset = '0';
            mobileOverlay.style.background = 'rgba(0,0,0,0.45)';
            mobileOverlay.style.zIndex = '9995';
            mobileOverlay.style.opacity = '0';
            mobileOverlay.style.transition = 'opacity 220ms ease';
            document.body.appendChild(mobileOverlay);
            mobileOverlay.addEventListener('click', closeDrawer);
            requestAnimationFrame(() => {
                if (mobileOverlay) mobileOverlay.style.opacity = '1';
            });
        }

        function removeOverlay() {
            if (!mobileOverlay) return;
            const closingOverlay = mobileOverlay;
            mobileOverlay = null;
            closingOverlay.style.opacity = '0';
            closingOverlay.style.pointerEvents = 'none';
            setTimeout(() => {
                closingOverlay.remove();
            }, 240);
        }

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeDrawer();
        });

        // Đóng menu khi click ra ngoài drawer
        document.addEventListener('click', (e) => {
            if (!nav.classList.contains('show')) return;
            if (nav.contains(e.target) || toggleBtn.contains(e.target)) return;
            closeDrawer();
        });

        let wasMobile = window.innerWidth < 1250;
        window.addEventListener('resize', () => {
            const isMobile = window.innerWidth < 1250;
            if (isMobile !== wasMobile) {
                closeDrawer();
            }
            wasMobile = isMobile;
        });

        nav.classList.remove('show');
        toggleBtn.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
        nav.querySelectorAll('.dropdown-menu').forEach(menu => menu.classList.remove('show'));
        nav.querySelectorAll('.dropdown-toggle').forEach(dt => {
            dt.setAttribute('aria-expanded', 'false');
            const svg = dt.querySelector('svg');
            if (svg) svg.style.transform = 'rotate(0deg)';
        });

        function openDrawer() {
            if (nav.classList.contains('show')) return;
            previousOverflow = document.body.style.overflow;
            nav.classList.add('show');
            const header = document.querySelector('.main-header');
            if (header) header.classList.add('nav-open');
            toggleBtn.setAttribute('aria-expanded', 'true');
            document.body.style.overflow = 'hidden';
            createOverlay();
            if (typeof setupMobileAccountToggle === 'function') setupMobileAccountToggle();
            if (typeof setupLogoutButtons === 'function') setupLogoutButtons();
        }

        function closeDrawer() {
            if (!nav.classList.contains('show')) return;
            nav.classList.remove('show');
            const header = document.querySelector('.main-header');
            if (header) header.classList.remove('nav-open');
            toggleBtn.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = previousOverflow ?? '';
            previousOverflow = null;
            removeOverlay();
            nav.querySelectorAll('.dropdown-toggle svg').forEach(svg => svg.style.transform = 'rotate(0deg)');
            nav.querySelectorAll('.dropdown-menu').forEach(menu => menu.classList.remove('show'));
            nav.querySelectorAll('.dropdown-toggle').forEach(dt => {
                dt.classList.remove('show');
                dt.setAttribute('aria-expanded', 'false');
            });
        }

        toggleBtn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const isOpen = nav.classList.contains('show');
            if (isOpen) {
                closeDrawer();
            } else {
                openDrawer();
            }
        };

        nav.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            if (window.innerWidth < 1250 && link && nav.contains(link) && !link.classList.contains('dropdown-toggle')) {
                closeDrawer();
            }
        });

        const dropdownToggles = nav.querySelectorAll('.dropdown-toggle');
        dropdownToggles.forEach(dt => {
            if (dt.dataset.mobileDropdownBound === 'true') return;
            
            dt.addEventListener('click', (e) => {
                if (window.innerWidth < 1250) {
                    e.preventDefault();
                    e.stopPropagation();
                    const parentItem = dt.closest('.nav-item.dropdown') || dt.parentElement;
                    const menu = parentItem ? parentItem.querySelector('.dropdown-menu') : dt.nextElementSibling;
                    if (menu) {
                        const isCurrentlyOpen = menu.classList.contains('show');
                        // Đóng các dropdown khác để tránh tràn màn hình mobile
                        nav.querySelectorAll('.dropdown-menu.show').forEach(m => {
                            if (m !== menu) m.classList.remove('show');
                        });
                        nav.querySelectorAll('.dropdown-toggle').forEach(t => {
                            if (t !== dt) {
                                t.classList.remove('show');
                                t.setAttribute('aria-expanded', 'false');
                                const s = t.querySelector('svg');
                                if (s) s.style.transform = 'rotate(0deg)';
                            }
                        });

                        menu.classList.toggle('show', !isCurrentlyOpen);
                        dt.classList.toggle('show', !isCurrentlyOpen);
                        dt.setAttribute('aria-expanded', String(!isCurrentlyOpen));
                        const svg = dt.querySelector('svg');
                        if (svg) svg.style.transform = !isCurrentlyOpen ? 'rotate(180deg)' : 'rotate(0deg)';
                    }
                }
            });
            
            dt.dataset.mobileDropdownBound = 'true';
        });

        if (typeof setupMobileAccountToggle === 'function') setupMobileAccountToggle();
        if (typeof setupLogoutButtons === 'function') setupLogoutButtons();

        toggleBtn.dataset.mobileNavReady = 'true';
        nav.dataset.mobileNavReady = 'true';
    }

    window.initMobileNavigation = initMobileNavigation;
    window.initHeaderMobileNavigation = initMobileNavigation;

    // Chạy khi header được chèn vào HTML
    document.addEventListener('headerInjected', () => {
        updateHeaderAuth();
        setupHeaderSearch();
        renderDynamicTopBarNotice();
        initMobileNavigation();
    });
    
    // Also run if header already exists (for pages that don't use components.js)
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            updateHeaderAuth();
            setupHeaderSearch();
            renderDynamicTopBarNotice();
            initMobileNavigation();
        });
    } else {
        updateHeaderAuth();
        setupHeaderSearch();
        renderDynamicTopBarNotice();
        initMobileNavigation();
    }
    
    // Lắng nghe thay đổi trạng thái đăng nhập, giỏ hàng và cấu hình cập nhật
    document.addEventListener('auth_state_changed', updateHeaderAuth);
    document.addEventListener('cart_updated', () => {
        if (typeof window.updateCartBadge === 'function') window.updateCartBadge();
    });
    window.addEventListener('pawpal_settings_updated', renderDynamicTopBarNotice);
    window.addEventListener('storage', (e) => {
        if (e.key === 'pawpal_notifications' || e.key === null) {
            window.updateNotificationBadge();
        }
        if (e.key === 'pawpal_settings_notices') {
            renderDynamicTopBarNotice();
        }
        if (e.key === 'pawpal_cart') {
            if (typeof window.updateCartBadge === 'function') window.updateCartBadge();
        }
    });
    window.addEventListener('focus', () => {
        window.updateNotificationBadge();
        if (typeof window.updateCartBadge === 'function') window.updateCartBadge();
    });
})();
