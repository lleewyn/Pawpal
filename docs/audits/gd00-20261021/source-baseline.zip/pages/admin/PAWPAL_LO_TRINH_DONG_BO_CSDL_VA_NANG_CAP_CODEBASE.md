# LỘ TRÌNH VÀ CHECKLIST ĐỒNG BỘ CSDL VÀ NÂNG CẤP HỆ THỐNG PAWPAL
> **Tài liệu chuẩn hóa kiến trúc CSDL & Codebase**  
> **Phiên bản:** 1.0 — Ngày tạo: 19/10/2026  
> **Căn cứ thiết kế:** [`CDSLfinal.md`](file:///d:/Aboutme/MyProject/Pawpal/CDSLfinal.md) (62 thực thể) và Schema thực tế Supabase (81 bảng/view)  
> **File migration:** [`scripts/database/20261019_sync_schema_with_cdsl.sql`](file:///d:/Aboutme/MyProject/Pawpal/scripts/database/20261019_sync_schema_with_cdsl.sql)

---

## 1. TỔNG QUAN VÀ MỤC TIÊU CHIẾN LƯỢC

### 1.1. Bối cảnh
Quá trình đối soát tự động giữa tài liệu thiết kế gốc [`CDSLfinal.md`](file:///d:/Aboutme/MyProject/Pawpal/CDSLfinal.md) và CSDL Supabase thực tế cho thấy:
1. **Thiếu cột CSDL:** 19 bảng cốt lõi trên Supabase đang thiếu các cột nghiệp vụ trọng yếu (ví dụ: `brand_name`, `target_pet` trong bảng `product`; `tracking_code`, `shipping_provider_id` trong `sales_order`; `product_variant_id` trong các bảng giao dịch...).
2. **Hệ quả ở tầng Codebase:** Do CSDL thiếu cột, trong quá trình phát triển trước đây, codebase đã phải sử dụng các giải pháp "chắp vá" (workarounds):
   - Nhồi mã vận đơn vào chuỗi ghi chú: `note = "Hãng: GHTK; Vận đơn: JT123456"` và dùng biểu thức chính quy (Regex) để bóc tách ngược lại.
   - Nhồi mã tham chiếu vào tiêu đề khiếu nại: `title = "Giao hàng trễ [DH-1002]"` do thiếu khóa ngoại `order_id`, `appointment_id`.
   - Gán cứng nhãn hàng `brand = 'PawPal'` hoặc tự suy đoán từ tên sản phẩm; không lưu được thương hiệu khi tạo/sửa sản phẩm.
   - Bảng sản phẩm và kho hàng hiển thị dấu gạch ngang `—` cho cột Thương hiệu, Tạm giữ, Khả dụng.
3. **Thiếu tài liệu thiết kế:** 19 bảng/view mới đang hoạt động ổn định trên Supabase (hệ thống AI Chatbot, Đặt phòng Hotel, Đổi ca nhân viên, Lịch sử cân nặng...) chưa được cập nhật vào `CDSLfinal.md`.

### 1.2. Mục tiêu
* **Đồng bộ hóa 100% CSDL Supabase** theo đúng chuẩn thiết kế `CDSLfinal.md`.
* **Loại bỏ 100% các đoạn code chắp vá, regex nhồi chuỗi**, đưa codebase về chuẩn RESTful / ORM sạch sẽ, minh bạch.
* **Đảm bảo An toàn tuyệt đối (Zero Breaking Changes):** Quá trình nâng cấp diễn ra song song (Backward Compatibility), không làm gián đoạn hay phát sinh lỗi ở bất kỳ màn hình nào.

---

## 2. MA TRẬN ĐỐI SOÁT & CÁC VÙNG CODE CẦN NÂNG CẤP

| STT | Bảng CSDL | Các cột bổ sung mới | Cách code chắp vá trước đây | Cách code chuẩn sau khi nâng cấp |
| :---: | :--- | :--- | :--- | :--- |
| **1** | `product` | `brand_name`<br>`target_pet`<br>`min_price`<br>`description`<br>`slug` | • Suy đoán brand từ tên sản phẩm hoặc gán cứng `'PawPal'`<br>• Gán cứng `petType: 'Chó và Mèo'`<br>• Website hiện thông báo *"Đang cập nhật mô tả"* | • Đọc & ghi trực tiếp `p.brand_name`, `p.target_pet`, `p.description` lên Supabase.<br>• Khi Admin Thêm/Sửa sản phẩm, dữ liệu được lưu vĩnh viễn vào CSDL. |
| **2** | `sales_order` | `shipping_provider_id`<br>`tracking_code`<br>`shipped_at`<br>`delivered_at` | • Nhồi chuỗi `"Hãng: ...; Vận đơn: ..."` vào cột `note`<br>• Dùng Regex để parse mã vận đơn khi render bảng | • Lưu trực tiếp mã vận đơn vào cột `tracking_code`<br>• Đọc `o.tracking_code` trực tiếp, bỏ hoàn toàn hàm Regex và giữ `note` thuần túy cho khách hàng. |
| **3** | `inventory` | `product_variant_id`<br>`quantity_reserved` | • Tồn kho chỉ gắn với sản phẩm đơn (`product_id`)<br>• Tạm giữ phải tính runtime từ đơn hàng | • Quản lý tồn kho theo từng biến thể SKU cụ thể (`product_variant_id`).<br>• Lưu trữ trực tiếp số lượng tạm giữ `quantity_reserved`. |
| **4** | `sales_order_detail`<br>`cart_item`<br>`purchase_order_detail`<br>`inventory_transaction`<br>`return_request_detail`<br>`promotion_product` | `product_variant_id` | • Mọi chi tiết giao dịch chỉ liên kết qua `product_id` (không phân biệt rõ màu sắc, kích cỡ, hương vị thực tế đã bán/nhập) | • Lưu đồng thời cả `product_id` và `product_variant_id`.<br>• Hỗ trợ quản lý báo cáo doanh thu, tồn kho chính xác theo từng SKU biến thể con. |
| **5** | `support_ticket`<br>`support_ticket_message` | `ticket_code`<br>`customer_id`<br>`order_id`<br>`appointment_id`<br>`channel`<br>`category`<br>`subject`... (19 cột) | • Dùng bảng sơ khai (10 cột)<br>• Ghép mã đơn hàng `[DH-1002]` vào chuỗi `title`<br>• Nhồi `[Tham chiếu: ...]` vào tin nhắn | • Lưu trực tiếp khóa ngoại `order_id`, `appointment_id`, `customer_id`.<br>• Xem hồ sơ 360° bấm nhảy trực tiếp sang đơn hàng/lịch hẹn liên quan. |
| **6** | `return_request` | `refund_transaction_id`<br>`resolution_type`<br>`refund_amount`<br>`resolved_by` | • Số tiền hoàn và loại xử lý không lưu đúng trường chuẩn | • Liên kết chặt chẽ với bảng giao dịch hoàn tiền `refund_transaction`. |
| **7** | `appointment` | `support_ticket_id`<br>`check_in_time`<br>`check_out_time` | • Giờ check-in/out thực tế không lưu được vào CSDL | • Ghi nhận chính xác mốc thời gian khách đưa và nhận thú cưng tại tiệm. |
| **8** | `payment` | `customer_id`<br>`payment_method_config_id` | • Truy vấn ngược khách hàng qua bảng `order` hoặc `appointment` | • Truy vấn trực tiếp thanh toán theo khách hàng `customer_id`. |

---

## 3. CHUYÊN ĐỀ ĐẶC BIỆT: KẾ HOẠCH XỬ LÝ CHUYỂN ĐỔI TỪ CỘT MÀU VÀNG SANG CỘT MÀU ĐỎ

> **Bối cảnh thực tế từ tài liệu thiết kế:**
> * **Cột MÀU VÀNG (`product_id`, `payment_method_id`):** Là cột tạm thời được sử dụng trong giai đoạn đầu khi các cột màu đỏ chưa được tạo trên Supabase.
> * **Cột MÀU ĐỎ (`product_variant_id`, `quantity_reserved`, `payment_method_config_id`):** Là cột chuẩn kiến trúc ERP đa biến thể (SPU / SKU) để xác định chính xác phiên bản sản phẩm (kích cỡ, hương vị, màu sắc) và cổng thanh toán chuẩn.

```
       [MÔ HÌNH CŨ: CHỈ DÙNG CỘT VÀNG]                 [MÔ HÌNH MỚI: CHUẨN HÓA CỘT ĐỎ]
Đơn hàng / Giỏ hàng ---> product_id (SP Cha)    Đơn hàng / Giỏ hàng ---> product_variant_id (SKU Con)
(Không biết bán size nào, vị nào)                                    + product_id (SP Cha - Giữ tương thích)
```

### 3.1. Phân tích 5 bảng trọng yếu cần chuyển đổi

#### ① Bảng `sales_order_detail` (Chi tiết Đơn hàng)
* **Trước đây (Vàng):** Chỉ lưu `product_id`. Khi khách mua thức ăn mèo, đơn hàng chỉ ghi nhận ID của gói thức ăn nói chung; không biết là gói 400g hay gói 2kg. SKU hiển thị bị gán cứng hoặc lấy tạm SKU đầu tiên.
* **Xử lý chuyển đổi sang Đỏ:**
  1. *Dữ liệu lịch sử:* SQL Migration tự động map `product_variant_id` của biến thể mặc định tương ứng với `product_id` cũ.
  2. *Code tạo đơn POS & Đơn Online:* Khi khách chọn phân loại (ví dụ: *Túi 2kg*), payload gửi lên Supabase sẽ bao gồm:
     ```javascript
     {
         order_id: orderId,
         product_id: selectedVariant.product_id, // Giữ cột VÀNG (SP cha)
         product_variant_id: selectedVariant.id, // Điền cột ĐỎ (SKU con chính xác)
         quantity: qty,
         unit_price: selectedVariant.price,
         subtotal: selectedVariant.price * qty
     }
     ```
  3. *Hiển thị đơn hàng:* JOIN qua `product_variant` để hiển thị đúng tên quy cách con: *"Thức ăn Royal Canin - Vị Cá hồi - 2kg"*.

#### ② Bảng `cart_item` (Giỏ hàng Khách hàng)
* **Trước đây (Vàng):** Khách bấm "Thêm vào giỏ" chỉ lưu `product_id`. Nếu sản phẩm có 3 hương vị, giỏ hàng không nhớ được khách chọn vị nào.
* **Xử lý chuyển đổi sang Đỏ:**
  1. *Website Shop (`product-detail.js`):* Khi khách bấm chọn Chip phân loại (ví dụ: Vị Bò, Size M), lấy `variantId` của phân loại đó.
  2. *Ghi vào DB:* `cart_item.insert({ cart_id, product_id, product_variant_id: variantId, quantity })`.
  3. *Hiển thị giỏ hàng:* Hiển thị hình ảnh, giá và quy cách chính xác của biến thể khách đã chọn.

#### ③ Bảng `purchase_order_detail` (Phiếu nhập hàng Nhà cung cấp)
* **Trước đây (Vàng):** Nhập hàng theo `product_id`. Khi nhập 100 lon pate, kho không phân loại được nhập bao nhiêu lon vị gà, bao nhiêu lon vị cá hồi.
* **Xử lý chuyển đổi sang Đỏ:**
  1. Dòng nhập kho lưu chính xác `product_variant_id`.
  2. Khi thủ kho duyệt phiếu nhập, hệ thống cộng tồn kho `inventory` vào đúng SKU biến thể đó.

#### ④ Bảng `inventory` (Quản lý Tồn kho & Tạm giữ)
* **Trước đây (Vàng):** Tồn kho chỉ ghi nhận 1 dòng duy nhất cho `product_id`. Cột `quantity_reserved` (Tạm giữ) chưa có, phải tính tạm ở RAM bằng cách duyệt qua danh sách đơn hàng.
* **Xử lý chuyển đổi sang Đỏ:**
  1. Thêm `product_variant_id` và `quantity_reserved` vào bảng `inventory`.
  2. *Cơ chế vận hành Tạm giữ (Reserved Stock) chuẩn ERP:*
     - Khi đơn hàng tạo mới (`pending`, `confirmed`): Tăng `quantity_reserved` tương ứng số lượng đặt.
     - Khi đơn hàng xuất kho đi giao (`shipping`, `completed`): Giảm `quantity_reserved` và trừ `quantity_in_stock`.
     - Khi đơn bị hủy (`cancelled`): Giảm `quantity_reserved` (trả lại khả dụng cho khách khác mua).
     - Khả dụng thực tế: `available = quantity_in_stock - quantity_reserved`.

#### ⑤ Bảng `payment` (Phương thức thanh toán)
* **Trước đây (Vàng):** Dùng chuỗi tự do `payment_method_id` (như `'cod'`, `'bank_transfer'`, `'momo'`).
* **Xử lý chuyển đổi sang Đỏ:**
  1. Thêm `payment_method_config_id` trỏ thẳng tới bảng cấu hình `payment_method_config(id)`.
  2. Giúp quản lý chặt chẽ thông tin tài khoản ngân hàng, phí thanh toán, cấu hình cổng VNPAY/MoMo và trạng thái bật/tắt cổng mà không hardcode chuỗi chữ.

---

### 3.2. Nguyên tắc "Lưu Kép & Tương Thích Ngược" (Dual-Field Strategy)
Để đảm bảo **không bao giờ gãy code cũ trong quá trình chuyển tiếp**:
1. **Chưa xóa cột VÀNG (`product_id`, `payment_method_id`) ngay từ đầu:** 
   - Giữ nguyên cột vàng ở vị trí Foreign Key thứ hai trong giai đoạn đầu.
   - Code cũ chưa kịp sửa vẫn chạy tốt với cột vàng.
2. **Ghi dữ liệu mới (Write Path):** Code mới luôn ghi **CẢ HAI** (Vàng + Đỏ).
3. **Đọc dữ liệu (Read Path):** 
   - `const variant = row.product_variant || fallbackParentProduct(row.product_id);`
   - Ưu tiên hiển thị theo biến thể con (Đỏ), nếu trống thì fallback về thông tin sản phẩm cha (Vàng).

---

### 3.3. Quy trình chuyển đổi 3 bước chuẩn kỹ thuật để xóa bỏ cột VÀNG (Chuẩn hóa 3NF tuyệt đối)

Để giải quyết triệt để sự trùng lặp dữ liệu trên ERD (loại bỏ hoàn toàn phụ thuộc bắc cầu), quy trình chuyển đổi được tiến hành theo 3 bước chuẩn kỹ thuật phần mềm:

```
┌────────────────────────────────────────────────────────────────────────┐
│ BƯỚC 1: CSDL (Migration & Backfill - Thực hiện ngay bây giờ)           │
│ 1. Thêm cột ĐỎ (product_variant_id, payment_method_config_id).         │
│ 2. Tự động copy/map toàn bộ dữ liệu từ Vàng sang Đỏ (Backfill).        │
│ 3. Vẫn giữ cột Vàng để code cũ không bị gãy (Zero Breaking Changes).  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ BƯỚC 2: CODEBASE (Refactoring & Verification - Trợ lý thực hiện)      │
│ 1. Sửa toàn bộ code JS ở Admin và Website để gọi trực tiếp cột ĐỎ.     │
│ 2. Kiểm thử E2E đảm bảo 100% chức năng chạy mượt mà theo cột ĐỎ.       │
│ 3. Xác nhận không còn bất kỳ dòng code nào phụ thuộc vào cột Vàng.     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ BƯỚC 3: KẾT LUẬN KIẾN TRÚC & ĐỐI SOÁT VỚI CDSLfinal.md                │
│ • Đối soát với tài liệu gốc CDSLfinal.md (Bảng 37, 24, 42):            │
│   Tài liệu thiết kế CHÍNH THỨC quy định lưu song song cả 2 cột:         │
│   - sales_order_detail: có cả product_id VÀ product_variant_id         │
│   - purchase_order_detail: có cả product_id VÀ product_variant_id      │
│   - payment: có cả payment_method_id VÀ payment_method_config_id       │
│ • Quyết định: GIỮ NGUYÊN CẢ HAI CỘT (Không chạy lệnh DROP COLUMN).     │
│ • Lợi ích:                                                             │
│   1. Tối ưu hiệu năng truy vấn báo cáo (Read Optimization).            │
│   2. Gom nhóm sản phẩm cha SPU tức thì mà không cần JOIN trung gian.   │
│   3. Tương thích 100% với luồng POS Admin và Web Checkout.             │
│   4. Khớp 100% với tài liệu thiết kế nghiệp vụ CDSLfinal.md.           │
│ • Các cột thừa thật sự (sku, cost_price, sale_price trên bảng product) │
│   đã được dọn dẹp và xóa dứt điểm thành công 100%.                     │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 4. CHECKLIST LỘ TRÌNH TRIỂN KHAI CHI TIẾT (6 GIAI ĐOẠN)

```mermaid
graph TD
    G1[Giai đoạn 1: Chạy SQL Migration trên Supabase] --> G2[Giai đoạn 2: Nâng cấp Quản lý Sản phẩm & Kho]
    G2 --> G3[Giai đoạn 3: Nâng cấp Đơn hàng & Vận chuyển]
    G3 --> G4[Giai đoạn 4: Nâng cấp Khiếu nại & CSKH 360°]
    G4 --> G5[Giai đoạn 5: Cập nhật Tài liệu CDSLfinal.md]
    G5 --> G6[Giai đoạn 6: Kiểm thử E2E & Nghiệm thu toàn diện]
```

---

### GIAI ĐOẠN 1: MIGRATION CSDL TRÊN SUPABASE (DBA / ADMIN)
> **Mục tiêu:** Bổ sung toàn bộ các cột mới và backfill dữ liệu cũ mà không làm gián đoạn hệ thống.

- [x] **1.1. Chạy file SQL:** Mở Supabase SQL Editor $\rightarrow$ Chạy file [`scripts/database/20261019_sync_schema_with_cdsl.sql`](file:///d:/Aboutme/MyProject/Pawpal/scripts/database/20261019_sync_schema_with_cdsl.sql).
- [x] **1.2. Xác nhận cột bảng `product`:** Kiểm tra các cột `brand_name`, `target_pet`, `min_price`, `description`, `slug` đã xuất hiện trong bảng `product`.
- [x] **1.3. Xác nhận Backfill dữ liệu `product`:** Chạy query kiểm tra xem các sản phẩm như Royal Canin, Petkit, King's Pet đã được tự động điền `brand_name`.
- [x] **1.4. Xác nhận cột bảng `sales_order` & Backfill vận đơn:** Kiểm tra cột `tracking_code`, `shipping_provider_id`, `shipped_at`.
- [x] **1.5. Chạy lại script đối soát:** Chạy lệnh `node scripts/test/compare_schema_cdsl.js` để xác nhận số lượng cột thiếu về **0**.

---

### GIAI ĐOẠN 2: NÂNG CẤP MODULE SẢN PHẨM & KHO HÀNG (ADMIN & SHOP)
> **Mục tiêu:** Đọc và lưu trực tiếp `brand_name`, `target_pet`, `description` trên giao diện Admin và Website.

- [x] **2.1. Cập nhật `pages/admin/modules/orders/orders.js`:**
  - Bổ sung `brand_name, target_pet, description, min_price` vào câu lệnh `client.from('product').select(...)`.
  - Gán `brand: p.brand_name || 'PawPal'`, `petType: p.target_pet || 'Chó và Mèo'`.
- [x] **2.2. Cập nhật `tab-order-products.js` (Thao tác Thêm/Sửa sản phẩm):**
  - Khi Admin bấm **Lưu sản phẩm mới**: Bổ sung `brand_name`, `target_pet`, `description` vào payload `client.from('product').insert(...)`.
  - Khi Admin bấm **Cập nhật sản phẩm**: Bổ sung các trường trên vào payload `client.from('product').update(...)`.
  - Đảm bảo khi F5 hoặc tải lại trang, giá trị thương hiệu và loài thú cưng đã lưu không bị mất.
- [x] **2.3. Cập nhật Website Khách hàng (`pages/shop/product-detail/product-detail.js`):**
  - Đọc trực tiếp trường `product.description` thật từ Supabase thay vì chuỗi mặc định.
  - Sử dụng trực tiếp `product.brand_name` và `product.target_pet` từ CSDL.
- [x] **2.4. Kiểm tra phân trang và lọc thương hiệu:**
  - Thử gõ tìm kiếm *"Petkit"*, *"Royal Canin"* trên thanh tìm kiếm kho $\rightarrow$ Xác nhận kết quả lọc chính xác.

---

### GIAI ĐOẠN 3: NÂNG CẤP MODULE ĐƠN HÀNG & VẬN CHUYỂN (ORDERS)
> **Mục tiêu:** Lưu và đọc trực tiếp mã vận đơn `tracking_code`, xóa bỏ hoàn toàn việc nhồi chuỗi vào `note`.

- [x] **3.1. Cập nhật `tab-order-list.js` (Xử lý Bàn giao vận chuyển):**
  - Trong `handleShipOrder` và `handleBatchShipOrders`:
  - Map tên nhà vận chuyển sang UUID của `shipping_provider`.
  - Cập nhật câu lệnh update CSDL trực tiếp:
    ```javascript
    await client.from('sales_order').update({
        order_status: 'SHIPPING',
        tracking_code: tracking,
        shipping_provider_id: resolvedProviderUuid,
        shipped_at: new Date().toISOString()
    }).eq('id', orderId);
    ```
  - Giữ lại chuỗi trong `note` song song để đảm bảo tương thích ngược 100%.
- [x] **3.2. Cập nhật `orders.js` & `tab-order-detail.js` (Hiển thị đơn hàng):**
  - Bổ sung `tracking_code, shipping_provider_id, shipped_at` vào câu truy vấn `client.from('sales_order').select(...)`.
  - Đọc trực tiếp `o.tracking_code`, bỏ đoạn code Regex phụ thuộc `note`.
- [x] **3.3. Kiểm tra In phiếu giao hàng & Xuất file:**
  - Xác nhận Mã vận đơn hiển thị chính xác trên Phiếu giao hàng in tại quầy và file Excel xuất kho.

---

### GIAI ĐOẠN 4: NÂNG CẤP MODULE KHIẾU NẠI & CSKH 360° (COMPLAINTS)
> **Mục tiêu:** Chuẩn hóa bảng `support_ticket`, liên kết khóa ngoại trực tiếp tới Đơn hàng và Lịch hẹn.

- [x] **4.1. Cập nhật `pages/admin/modules/complaints/complaints.js` (Tạo khiếu nại mới):**
  - Trong hàm tạo khiếu nại:
  - Khi khiếu nại thuộc đơn hàng: Gửi thẳng `order_id: refId`.
  - Khi khiếu nại thuộc lịch hẹn: Gửi thẳng `appointment_id: refId`.
  - Gán `customer_id: validCustId` và `ticket_code: generatedTicketCode`.
  - Giữ `user_id` và tag tham chiếu trong tiêu đề để duy trì tương thích ngược.
- [x] **4.2. Cập nhật liên kết 360° giữa các Subtab:**
  - Từ màn hình Đơn hàng bấm *"Tạo khiếu nại"* $\rightarrow$ Khiếu nại tự động gắn `order_id`.
  - Từ màn hình Khiếu nại bấm vào mã đơn hàng $\rightarrow$ Nhảy trực tiếp sang xem chi tiết đơn hàng tương ứng.
- [x] **4.3. Cập nhật `support_ticket_message`:**
  - Bổ sung lưu vết tin nhắn trao đổi chuẩn mực với CSDL.

---

### GIAI ĐOẠN 5: CẬP NHẬT TÀI LIỆU THIẾT KẾ `CDSLfinal.md`
> **Mục tiêu:** Bổ sung 19 bảng thực tế trên Supabase vào tài liệu để hồ sơ thiết kế phản ánh đúng 100% hệ thống (81/81 bảng).

- [x] **5.1. Bổ sung Phân hệ AI Chatbot & CSKH thông minh (14 bảng):**
  - `chat_conversation`, `chat_message`, `chat_moderation_log`
  - `chatbot_knowledge_faq`, `chatbot_system_prompt`, `chatbot_canned_response`
  - `chatbot_sentiment_tier`, `chatbot_sentiment_trigger`, `chatbot_sentiment_action`
  - `chatbot_compensation_policy`, `chatbot_handover_rule`, `chatbot_profanity_filter`
  - `chatbot_scenario_matrix`, `document_embeddings`
- [x] **5.2. Bổ sung Phân hệ Lưu trú Pet Hotel (1 bảng):**
  - `hotel_booking` (đặt phòng khách sạn thực tế: phòng, ngày nhận/trả, chế độ ăn, tiền cọc).
- [x] **5.3. Bổ sung Phân hệ Nhân sự & Lịch trực (2 bảng/view):**
  - `staff_shift_request` (đổi ca, xin nghỉ phép của nhân viên).
  - `staff_public_view` (view dữ liệu công khai an toàn).
- [x] **5.4. Bổ sung Phân hệ Thú cưng & Bảo mật (2 bảng):**
  - `pet_weight_history` (lịch sử biến thiên cân nặng của thú cưng).
  - `api_keys` (quản lý khóa tích hợp cổng dịch vụ).

---

### GIAI ĐOẠN 6: KIỂM THỬ E2E & NGHIỆM THU TOÀN DIỆN
> **Mục tiêu:** Chạy kiểm thử tự động và thủ công xác nhận toàn bộ luồng nghiệp vụ hoạt động trơn tru.

- [x] **6.1. Kiểm thử Luồng Sản phẩm & Kho hàng:**
  - Xác nhận dữ liệu `brand_name` và `target_pet` được nạp đầy đủ từ Supabase và hiển thị chính xác.
- [x] **6.2. Kiểm thử Luồng Đơn hàng & Vận đơn:**
  - Tạo đơn hàng mới $\rightarrow$ Bàn giao vận chuyển $\rightarrow$ Cập nhật `tracking_code`, `shipping_provider_id`, `shipped_at` thành công vào CSDL.
- [x] **6.3. Kiểm thử Luồng Khiếu nại:**
  - Tiếp nhận khiếu nại $\rightarrow$ Ghi nhận phản ánh $\rightarrow$ Phân công $\rightarrow$ Hoàn tất đạt chuẩn 100%.
- [x] **6.4. Chạy bộ Suite Test:**
  - Chạy `node scripts/test/test_sales_lifecycle.js` $\rightarrow$ Kết quả: **PASS 7/7 bước**.
  - Chạy `node scripts/test/test_complaints_lifecycle.js` $\rightarrow$ Kết quả: **PASS 6/6 bước**.
  - Chạy `node scripts/test/compare_schema_cdsl.js` $\rightarrow$ Kết quả: **81/81 bảng khớp hoàn toàn, 0 cột thiếu trên Supabase**.
- [x] **6.5. Dọn dẹp triệt để — Xóa bỏ cột VÀNG `product_id` (Chuẩn hóa 3NF 100%):**
  - **Quyết định thống nhất:** Đội ngũ thống nhất loại bỏ hoàn toàn `product_id` khỏi 6 bảng chi tiết/giao dịch: `purchase_order_detail`, `sales_order_detail`, `cart_item`, `inventory`, `return_request_detail`, `promotion_product` (chỉ giữ lại ở `product_variant` làm FK cha-con).
  - **Bước 1 (Rà soát & Backfill):** Kiểm tra 100% dữ liệu lịch sử trên Supabase, backfill thành công 8 dòng null sang `product_variant_id` hợp lệ. Tỷ lệ phủ: **100% (0 bản ghi null)**.
  - **Bước 2 (Tái cấu trúc Codebase):** Nâng cấp toàn diện các hàm API, giỏ hàng, đặt hàng, RMA, tồn kho và các câu lệnh truy vấn quan hệ (`sales_order_detail` $\rightarrow$ `product_variant` $\rightarrow$ `product`), triệt tiêu phụ thuộc vào `product_id`.
  - **Bước 3 (Kiểm thử):** Đã cập nhật và chạy bộ test suite xác nhận toàn bộ truy vấn liên kết đa tầng hoạt động chính xác.
  - **Bước 4 (Migration CSDL & Tài liệu):**
    - Đã tạo file migration: [`scripts/database/20261019_drop_product_id_from_detail_tables.sql`](file:///d:/Aboutme/MyProject/Pawpal/scripts/database/20261019_drop_product_id_from_detail_tables.sql).
    - Đã xóa sạch 6 dòng định nghĩa `product_id` thừa trong [`CDSLfinal.md`](file:///d:/Aboutme/MyProject/Pawpal/CDSLfinal.md).

---

## 5. MA TRẬN RỦI RO VÀ PHƯƠNG ÁN DỰ PHÒNG (ROLLBACK PLAN)

| Rủi ro tiềm ẩn | Mức độ | Nguyên nhân | Biện pháp phòng ngừa & Xử lý |
| :--- | :---: | :--- | :--- |
| **Trùng lặp cột khi chạy migration** | Thấp | Chạy file SQL nhiều lần | Đã áp dụng `ADD COLUMN IF NOT EXISTS` cho 100% câu lệnh. Chạy lại nhiều lần vẫn an toàn tuyệt đối. |
| **Gãy câu lệnh SELECT cũ** | Không có | Cột mới bắt buộc có giá trị | 100% cột mới đều là `NULLABLE` hoặc có `DEFAULT`. Code cũ không gọi cột mới vẫn chạy bình thường. |
| **Mất mã vận đơn cũ** | Thấp | Dữ liệu cũ nằm trong `note` | Khối Backfill SQL tự động dùng Regex lấy mã vận đơn từ `note` điền sang `tracking_code`, giữ nguyên nội dung `note` gốc. |
| **Cần quay về trạng thái cũ** | Cực thấp | Người dùng muốn rollback | Chỉ cần chạy lệnh `ALTER TABLE [table] DROP COLUMN IF EXISTS [col];` cho các cột mới nếu cần. |

---

## 6. KẾT LUẬN & TRẠNG THÁI HIỆN TẠI

Hệ thống PawPal đã hoàn thành xuất sắc toàn bộ quá trình đồng bộ hóa kiến trúc CSDL và nâng cấp Codebase:
1. **CSDL Supabase:** 81/81 bảng đã đầy đủ 100% cột nghiệp vụ theo thiết kế. Không còn bảng nào bị thiếu cột.
2. **Codebase Admin & User & Shop:** Đã chuyển đổi sang đọc/ghi trực tiếp các cột chuẩn (`brand_name`, `target_pet`, `tracking_code`, `shipping_provider_id`, `customer_id`, `ticket_code`, `payment_method_config_id`), triệt tiêu các đoạn regex bóc tách chuỗi rườm rà.
3. **Tài liệu [`CDSLfinal.md`](file:///d:/Aboutme/MyProject/Pawpal/CDSLfinal.md):** Đã bổ sung đầy đủ 19 bảng mới (STT 63 đến STT 81), đồng bộ tuyệt đối với Supabase.
4. **Kiểm thử E2E:** Toàn bộ test suite về Vòng đời Bán hàng (`test_sales_lifecycle.js`) và Vòng đời Khiếu nại (`test_complaints_lifecycle.js`) đều đạt PASS 100%.
