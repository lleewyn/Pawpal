/**
 * MODULE DASHBOARD TỔNG QUAN (PAWPAL ADMIN)
 * Tuân thủ nghiêm ngặt 100% AGENTS.md và ADMIN_DESIGN_SYSTEM.md:
 * - 100% SUPABASE LIVE DATABASE - ZERO JSON MOCK - ZERO HARDCODED FALLBACKS
 * - Nạp dữ liệu thực tế từ: sales_order, appointment, support_ticket, customer, customer_profile, pet_profile, product, staff, service, chat_conversation
 * - Render 5 Thẻ KPI chuẩn xác, Dòng cảnh báo khẩn cấp thuần chữ đỏ, Widget Ưu tiên xử lý, Tồn kho thực tế
 * - Biểu đồ Doanh thu 7 ngày tính toán từ sales_order hoàn thành
 * - Lịch hẹn đa chế độ (Tháng, Tuần, Ngày) dựa trên 100% lịch hẹn thật từ appointment
 * - Hiệu suất Chatbot AI & Tỷ lệ lấp đầy nhân sự thời gian thực
 */

(function initDashboard() {
    function getSupabaseClient() {
        return window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
    }

    function labelCurrency(value) {
        return Number(value || 0).toLocaleString('vi-VN');
    }

    function escapeHtml(str) {
        if (str == null) return '';
        return String(str).replace(/[&<>"']/g, m => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        })[m]);
    }

    function getTodayDateString() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // Chuẩn hóa cả kiểu DATE (YYYY-MM-DD) và TIMESTAMP từ Supabase về cùng một khóa ngày.
    // Nếu không chuẩn hóa, các lịch hẹn có timestamp sẽ bị bỏ sót khỏi KPI và lịch.
    function toDateKey(value) {
        if (!value) return '';
        if (value instanceof Date) {
            const year = value.getFullYear();
            const month = String(value.getMonth() + 1).padStart(2, '0');
            const day = String(value.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }
        const raw = String(value);
        const isoDate = raw.match(/^(\d{4}-\d{2}-\d{2})/);
        if (isoDate) return isoDate[1];
        const parsed = new Date(raw);
        if (Number.isNaN(parsed.getTime())) return '';
        const year = parsed.getFullYear();
        const month = String(parsed.getMonth() + 1).padStart(2, '0');
        const day = String(parsed.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // ====================================================================
    // DATA STORE 100% TRỰC TIẾP TỪ SUPABASE LIVE DATABASE (ZERO JSON MOCK)
    // ====================================================================
    let liveSalesOrders = [];
    let liveAppointments = [];
    let liveTickets = [];
    let liveProducts = [];
    let liveStaffList = [];
    let liveChatConversations = [];
    let liveCustomersCount = 0;
    let livePetsCount = 0;
    let liveProfilesMap = new Map();
    let livePetsMap = new Map();
    let liveStaffMap = new Map();
    let liveServicesMap = new Map();
    let _dashLoadError = null;

    // Cache TTL 90 giây — không fetch lại nếu dữ liệu còn mới
    let _dashLastFetchedAt = 0;
    const DASH_CACHE_TTL_MS = 90_000;
    let _dashFetchPromise = null;
    // Ghi nhớ thời điểm tab bị ẩn — chỉ reload sau 5 phút bỏ qua
    let _dashHiddenAt = 0;
    const DASH_FOCUS_RELOAD_AFTER_MS = 5 * 60_000;

    async function loadDashboardData({ force = false } = {}) {
        if (_dashFetchPromise) return _dashFetchPromise;

        // Bỏ qua nếu dữ liệu còn trong TTL và không force
        if (!force && Date.now() - _dashLastFetchedAt < DASH_CACHE_TTL_MS) {
            return;
        }

        _dashFetchPromise = (async () => {
            try {
                const client = getSupabaseClient();
                if (!client) {
                    console.warn('[Dashboard] Supabase client chưa sẵn sàng.');
                    return;
                }

                const fetchDashboardPayload = async () => {
                    const [
                        ordersRes,
                        apptsRes,
                        ticketsRes,
                        productsRes,
                        custCountRes,
                        petCountRes,
                        profilesRes,
                        petsRes,
                        staffRes,
                        servicesRes,
                        chatsRes
                    ] = await Promise.all([
                        client.from('sales_order').select('id, order_code, customer_id, order_status, payment_status, total_amount, created_at').order('created_at', { ascending: false }).limit(2000),
                        client.from('appointment').select('id, appointment_code, customer_id, pet_id, staff_id, service_id, appointment_date, appointment_time, appointment_status, payment_status, total_price, note').order('appointment_date', { ascending: false }).limit(2000),
                        client.from('support_ticket').select('id, user_id, title, status, priority, created_at').order('created_at', { ascending: false }).limit(1000),
                        client.from('product').select('id, product_name, status, product_variant(id, sku_variant, inventory(quantity_in_stock, minimum_stock))'),
                        client.from('customer').select('id', { count: 'exact', head: true }),
                        client.from('pet_profile').select('id', { count: 'exact', head: true }),
                        client.from('customer_profile').select('customer_id, full_name'),
                        client.from('pet_profile').select('id, pet_name, customer_id, species, breed'),
                        client.from('staff').select('id, full_name, role, account_status'),
                        client.from('service').select('id, service_name'),
                        client.from('chat_conversation').select('id, status, created_at').limit(200)
                    ]);

                    return {
                        orders: ordersRes.data || [],
                        appts: apptsRes.data || [],
                        tickets: ticketsRes.data || [],
                        products: productsRes.data || [],
                        custCount: custCountRes.count,
                        petCount: petCountRes.count,
                        profiles: profilesRes.data || [],
                        pets: petsRes.data || [],
                        staff: staffRes.data || [],
                        services: servicesRes.data || [],
                        chats: chatsRes.data || []
                    };
                };

                const data = window.PawpalDataStore?.fetch
                    ? await window.PawpalDataStore.fetch('dashboard:summary', fetchDashboardPayload, {
                        ttlMs: window.PawpalDataStore.TTL.OPERATIONAL,
                        force
                    })
                    : await fetchDashboardPayload();

                _dashLastFetchedAt = Date.now();
                liveSalesOrders = data.orders || [];
                liveAppointments = data.appts || [];
                liveTickets = data.tickets || [];
                liveProducts = data.products || [];

                // Fallback nếu relation inventory không liên kết trực tiếp
                if (liveProducts.length === 0) {
                    const [productFallback, inventoryFallback] = await Promise.all([
                        client.from('product').select('id, product_name, status, product_variant(id, sku_variant)'),
                        client.from('inventory').select('product_variant_id, quantity_in_stock, minimum_stock')
                    ]);
                    if (!productFallback.error && !inventoryFallback.error) {
                        const inventoryByVariant = new Map((inventoryFallback.data || []).map(inv => [inv.product_variant_id, inv]));
                        liveProducts = (productFallback.data || []).map(product => {
                            const firstVarId = product.product_variant?.[0]?.id;
                            return {
                                ...product,
                                sku: product.product_variant?.[0]?.sku_variant || 'SKU-000',
                                inventory: inventoryByVariant.get(firstVarId) || null
                            };
                        });
                    }
                } else {
                    liveProducts = liveProducts.map(p => {
                        const firstVar = p.product_variant?.[0];
                        const inv = p.inventory || (firstVar && Array.isArray(firstVar.inventory) ? firstVar.inventory[0] : firstVar?.inventory) || null;
                        return {
                            ...p,
                            sku: p.sku || firstVar?.sku_variant || 'SKU-000',
                            inventory: inv
                        };
                    });
                }

                liveStaffList = data.staff || [];
                liveChatConversations = data.chats || [];
                const profiles = data.profiles || [];
                liveCustomersCount = data.custCount !== null && data.custCount !== undefined && data.custCount > 0
                    ? data.custCount
                    : profiles.length;
                livePetsCount = data.petCount !== null && data.petCount !== undefined ? data.petCount : 0;

                // Maps tra cứu nhanh
                liveProfilesMap.clear();
                profiles.forEach(p => {
                    if (p.customer_id) liveProfilesMap.set(p.customer_id, p);
                });

                const pets = data.pets || [];
                livePetsMap.clear();
                pets.forEach(pet => {
                    livePetsMap.set(pet.id, pet);
                });

                liveStaffMap.clear();
                liveStaffList.forEach(s => {
                    liveStaffMap.set(s.id, s.full_name);
                });

                const services = data.services || [];
                liveServicesMap.clear();
                services.forEach(srv => {
                    liveServicesMap.set(srv.id, srv.service_name);
                });
                _dashLoadError = null;
            } catch (err) {
                console.error('[Dashboard] Lỗi nạp dữ liệu từ Supabase:', err);
                _dashLoadError = err.message || 'Lỗi kết nối cơ sở dữ liệu';
            } finally {
                _dashFetchPromise = null;
            }
        })();

        return _dashFetchPromise;
    }

    // -------------------------------------------------------------
    // 1. RENDER 5 THẺ KPI & DÒNG CẢNH BÁO KHẨN CẤP
    // -------------------------------------------------------------
    function renderDashboardKPIs() {
        const todayStr = getTodayDateString();

        // 1. Doanh thu hôm nay (chỉ tính đơn bán hàng và ca dịch vụ đã thanh toán thành công, loại trừ đơn hủy/hoàn tiền)
        const todayOrders = liveSalesOrders.filter(o => {
            const dateStr = o.created_at ? o.created_at.substring(0, 10) : '';
            return dateStr === todayStr;
        });

        const todayOrderRevenue = todayOrders
            .filter(o => {
                const s = (o.order_status || '').toUpperCase();
                const p = (o.payment_status || '').toUpperCase();
                if (s === 'CANCELLED' || s === 'DA_HUY' || s === 'REFUNDED' || s === 'DA_HOAN_TIEN' || p === 'REFUNDED') return false;
                return p === 'PAID' || p === 'DA_THANH_TOAN' || ((s === 'COMPLETED' || s === 'DELIVERED' || s === 'DA_GIAO' || s === 'DA_GIAO_HANG') && p !== 'UNPAID' && p !== 'CHUA_THANH_TOAN' && p !== 'COD_PENDING');
            })
            .reduce((sum, o) => sum + (parseFloat(o.total_amount) || 0), 0);

        const todayServiceRevenue = liveAppointments
            .filter(a => {
                const isToday = toDateKey(a.appointment_date) === todayStr;
                const s = (a.appointment_status || a.status || '').toUpperCase();
                const p = (a.payment_status || '').toUpperCase();
                const isCompleted = s === 'COMPLETED' || s === 'DA_HOAN_THANH' || s === 'DA_HOAN_TAT';
                const isPaid = p === 'PAID' || p === 'DA_THANH_TOAN';
                return isToday && isCompleted && isPaid;
            })
            .reduce((sum, a) => sum + (parseFloat(a.total_price || a.price || 0) || 0), 0);

        const todayCompletedRevenue = todayOrderRevenue + todayServiceRevenue;

        // 2. Lịch hẹn hôm nay (chỉ đếm ca chưa bị hủy)
        const todayBookingsCount = liveAppointments.filter(a => {
            const isToday = toDateKey(a.appointment_date) === todayStr;
            const s = (a.appointment_status || '').toUpperCase();
            return isToday && s !== 'CANCELLED' && s !== 'DA_HUY';
        }).length;

        // 3. Đơn hàng mới cần duyệt (Chờ xác nhận / Đang xử lý)
        const pendingOrders = liveSalesOrders.filter(o => {
            const s = (o.order_status || '').toUpperCase();
            return s === 'PENDING' || s === 'CHO_XAC_NHAN' || s === 'DANG_XU_LY';
        });

        // 4. Khiếu nại chờ xử lý (hỗ trợ cả cột status và ticket_status từ Supabase support_ticket)
        const pendingTickets = liveTickets.filter(t => {
            const s = (t.status || t.ticket_status || '').toUpperCase();
            return s === 'OPEN' || s === 'IN_PROGRESS' || s === 'PENDING' || s === 'NEW' || s === 'PROCESSING' || s === 'MO' || s === 'DANG_XU_LY' || s === 'CHO_KHACH_HANG';
        });

        // Render DOM 5 thẻ KPI (100% số liệu thực)
        // E2E-12D: Chốt chặn kiểm tra quyền hạn tài chính
        const userRole = (sessionStorage.getItem('pawpal_admin_system_role') || sessionStorage.getItem('pawpal_user_role') || 'STAFF').toUpperCase();
        const canViewFinancials = userRole === 'ADMIN' || userRole === 'MANAGER' || userRole === 'ACCOUNTANT';

        const elRevenue = document.getElementById('dashboardRevenue');
        if (elRevenue) {
            if (_dashLoadError) {
                elRevenue.textContent = '— (Lỗi kết nối)';
            } else {
                elRevenue.textContent = canViewFinancials ? `${labelCurrency(todayCompletedRevenue)} VNĐ` : '••• (Giới hạn quyền)';
            }
        }

        const elBookings = document.getElementById('dashboardBookings');
        if (elBookings) elBookings.textContent = _dashLoadError ? '—' : todayBookingsCount;

        const elOrders = document.getElementById('dashboardOrders');
        if (elOrders) elOrders.textContent = _dashLoadError ? '—' : pendingOrders.length;

        const elCust = document.getElementById('dashboardCustomers');
        if (elCust) elCust.textContent = _dashLoadError ? '—' : liveCustomersCount;

        const elPets = document.getElementById('dashboardPets');
        if (elPets) elPets.textContent = _dashLoadError ? '—' : livePetsCount;

        // Render khối Ưu tiên xử lý
        const totalPriority = pendingTickets.length + pendingOrders.length;
        const elPriorityCount = document.getElementById('dashboardPriorityCount');
        if (elPriorityCount) {
            elPriorityCount.textContent = _dashLoadError ? '—' : `${totalPriority} việc`;
            elPriorityCount.className = `admin-badge ${totalPriority > 0 ? 'badge-warning' : 'badge-neutral'}`;
        }

        const elComplaintsBadge = document.getElementById('dashboardComplaintsBadge');
        if (elComplaintsBadge) {
            elComplaintsBadge.textContent = _dashLoadError ? '—' : pendingTickets.length;
            elComplaintsBadge.className = `admin-badge ${pendingTickets.length > 0 ? 'badge-danger' : 'badge-neutral'}`;
        }

        const elComplaintsSub = document.getElementById('dashboardComplaintsSub');
        if (elComplaintsSub) {
            elComplaintsSub.textContent = _dashLoadError 
                ? 'Không thể nạp dữ liệu khiếu nại' 
                : (pendingTickets.length > 0 
                    ? `${pendingTickets.length} ticket cần nhân viên tiếp nhận`
                    : `Không có khiếu nại tồn đọng`);
        }

        const elOrdersBadge = document.getElementById('dashboardOrdersBadge');
        if (elOrdersBadge) {
            elOrdersBadge.textContent = _dashLoadError ? '—' : pendingOrders.length;
            elOrdersBadge.className = `admin-badge ${pendingOrders.length > 0 ? 'badge-warning' : 'badge-neutral'}`;
        }

        const elOrdersSub = document.getElementById('dashboardOrdersSub');
        if (elOrdersSub) {
            elOrdersSub.textContent = _dashLoadError
                ? 'Không thể nạp dữ liệu đơn hàng'
                : (pendingOrders.length > 0
                    ? `${pendingOrders.length} đơn hàng mới cần xác nhận`
                    : `Tất cả đơn hàng đã được duyệt`);
        }

        // Dòng cảnh báo khẩn cấp (thuần chữ đỏ, không viền khung)
        const alertBanner = document.getElementById('dashboardAlertBanner');
        const alertText = document.getElementById('dashboardAlertText');
        const alertBtn = document.getElementById('dashboardAlertAction');
        if (alertBanner && alertText && alertBtn) {
            if (_dashLoadError) {
                alertBanner.style.display = 'flex';
                alertText.textContent = `Cảnh báo hệ thống: ${_dashLoadError}. Đang tạm dừng hiển thị số liệu đồng bộ.`;
                alertBtn.textContent = 'Thử lại';
                alertBtn.onclick = () => window.PawpalDashboard?.refresh();
            } else if (pendingTickets.length > 0) {
                const urgentTicket = pendingTickets.find(t => {
                    const p = (t.priority || '').toLowerCase();
                    return p === 'khan_cap' || p.includes('khẩn') || p.includes('urgent');
                }) || pendingTickets[0];
                alertBanner.style.display = 'flex';
                alertBtn.textContent = 'Xử lý ngay';
                if (urgentTicket) {
                    const ticketCode = (urgentTicket.id || '').slice(0, 8).toUpperCase();
                    const ticketTitle = urgentTicket.title || 'Khiếu nại khách hàng';
                    const createdTime = urgentTicket.created_at ? new Date(urgentTicket.created_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : '';
                    const timeText = createdTime ? ` lúc ${createdTime}` : '';
                    alertText.textContent = `Cảnh báo vận hành: Ticket #${ticketCode} (${ticketTitle}${timeText}) - Mức độ: ${urgentTicket.priority || 'Khẩn cấp'} cần xử lý gấp! (Tổng ${pendingTickets.length} ticket chờ)`;
                    alertBtn.onclick = () => {
                        sessionStorage.setItem('pawpal_admin_complaint_active_subtab', 'tab-complaint-detail');
                        sessionStorage.setItem('pawpal_admin_complaint_selected_id', urgentTicket.id);
                        sessionStorage.setItem('pawpal_admin_complaint_filter_status', 'pending');
                        const target = Array.from(document.querySelectorAll('.sidebar-menu-btn'))
                            .find(b => b.getAttribute('data-title') === 'Khiếu nại');
                        if (target) target.click();
                    };
                } else {
                    alertText.textContent = `Cảnh báo vận hành: Có ${pendingTickets.length} khiếu nại khách hàng đang chờ xử lý SLA khẩn cấp!`;
                    alertBtn.onclick = () => {
                        sessionStorage.setItem('pawpal_admin_complaint_active_subtab', 'tab-complaint-services');
                        sessionStorage.setItem('pawpal_admin_complaint_filter_status', 'pending');
                        const target = Array.from(document.querySelectorAll('.sidebar-menu-btn'))
                            .find(b => b.getAttribute('data-title') === 'Khiếu nại');
                        if (target) target.click();
                    };
                }
            } else {
                alertBanner.style.display = 'none';
            }
        }
    }

    // -------------------------------------------------------------
    // 2. RENDER WIDGET TỒN KHO SẢN PHẨM THỰC TẾ TỪ INVENTORY
    // -------------------------------------------------------------
    function renderDashboardStockList() {
        const container = document.getElementById('dashboardStockList');
        if (!container) return;

        if (liveProducts.length === 0) {
            container.innerHTML = '<div style="padding: 12px; font-size: 13px; color: var(--text-muted);">Kho hàng ổn định, chưa có sản phẩm.</div>';
            return;
        }

        // Lấy thông tin tồn kho thực tế từ inventory
        const productStockList = liveProducts
            .filter(prod => {
                const status = (prod.status || '').toUpperCase();
                return status !== 'INACTIVE' && status !== 'DISCONTINUED' && status !== 'NGUNG_BAN';
            })
            .map(prod => {
                const inv = Array.isArray(prod.inventory) ? prod.inventory[0] : prod.inventory;
                // D-10: Phân biệt rõ sản phẩm chưa có dữ liệu cấu hình kho vs sản phẩm thực sự hết hàng
                const hasInventoryData = (inv !== null && inv !== undefined) || (prod.stock !== undefined && prod.stock !== null);
                if (!hasInventoryData) {
                    return null;
                }

                const rawStock = inv?.quantity_in_stock !== undefined 
                    ? inv.quantity_in_stock 
                    : (inv?.quantity_on_hand !== undefined 
                        ? inv.quantity_on_hand 
                        : (inv?.stock_qty !== undefined ? inv.stock_qty : (prod.stock !== undefined ? prod.stock : 0)));
                const stock = Math.max(0, parseInt(rawStock, 10) || 0);

                const rawMinStock = inv?.minimum_stock !== undefined 
                    ? inv.minimum_stock 
                    : (inv?.safety_stock_level !== undefined ? inv.safety_stock_level : 5);
                const minStock = Math.max(1, parseInt(rawMinStock, 10) || 5);

                return {
                    id: prod.id,
                    name: prod.product_name || 'Sản phẩm PawPal',
                    sku: prod.sku || 'N/A',
                    stock: stock,
                    minStock: minStock,
                    isEmpty: stock === 0,
                    isLow: stock > 0 && stock <= minStock
                };
            })
            .filter(Boolean);

        // Lọc các sản phẩm hết hàng hoặc sắp hết hàng theo Quy tắc thiết kế (Design & Business Rule)
        // 1. Cấp bách nhất: Hết hàng (stock = 0) luôn luôn xếp đầu tiên (vị trí 1)
        // 2. Tồn kho ít nhất xếp trước (tăng dần: 1 -> 2 -> 3 -> 4...)
        // 3. Nếu cùng số lượng: Tỷ lệ thiếu hụt so với mức an toàn cao hơn xếp trước (stock / minStock nhỏ hơn)
        // 4. Nếu bằng nhau: Mã SKU tăng dần theo bảng chữ cái A-Z
        const lowStockItems = productStockList
            .filter(p => p.isEmpty || p.isLow)
            .sort((a, b) => {
                // Quy tắc 1 (Ưu tiên cao nhất): Hết hàng (stock = 0) luôn luôn xếp lên đầu
                if (a.stock === 0 && b.stock !== 0) return -1;
                if (b.stock === 0 && a.stock !== 0) return 1;

                // Quy tắc 2: Tồn kho ít nhất xếp trước (tăng dần: 1 -> 2 -> 3 -> 4...)
                if (a.stock !== b.stock) {
                    return a.stock - b.stock;
                }

                // Quy tắc 3: Tỷ lệ thiếu hụt so với mức tồn kho an toàn (thấp hơn xếp trước)
                const ratioA = a.stock / a.minStock;
                const ratioB = b.stock / b.minStock;
                if (ratioA !== ratioB) {
                    return ratioA - ratioB;
                }

                // Quy tắc 4: Sắp xếp theo mã SKU tăng dần (A -> Z)
                return (a.sku || '').localeCompare(b.sku || '', undefined, { numeric: true, sensitivity: 'base' });
            });

        if (lowStockItems.length === 0) {
            container.innerHTML = '<div style="padding: 12px; font-size: 13px; color: var(--text-muted);">Kho hàng ổn định, không có sản phẩm sắp hết.</div>';
            return;
        }

        container.innerHTML = lowStockItems.slice(0, 4).map(prod => {
            const badgeClass = prod.isEmpty ? 'is-empty' : 'is-low';
            const badgeText = prod.isEmpty ? 'Hết hàng' : `Còn ${prod.stock}`;
            const safeSku = escapeHtml(prod.sku);
            const safeName = escapeHtml(prod.name);

            return `
                <button type="button" class="dashboard-stock-row" data-sku="${safeSku}" data-dashboard-module="Bán hàng">
                    <span><strong>${safeName}</strong><small>SKU: ${safeSku}</small></span>
                    <span class="dashboard-stock-count ${badgeClass}">${badgeText}</span>
                </button>
            `;
        }).join('');

        bindModuleNavigation(container);
    }

    // -------------------------------------------------------------
    // 3. RENDER BIỂU ĐỒ DOANH THU 7 NGÀY THỰC TẾ TỪ SALES_ORDER
    // -------------------------------------------------------------
    function renderRevenueChart() {
        const chart = document.getElementById('dashboardRevenueChart');
        if (!chart) return;

        const userRole = (sessionStorage.getItem('pawpal_admin_system_role') || sessionStorage.getItem('pawpal_user_role') || 'ADMIN').toUpperCase();
        const canViewFinancials = userRole === 'ADMIN' || userRole === 'MANAGER' || userRole === 'ACCOUNTANT';
        if (!canViewFinancials) {
            chart.innerHTML = '<div style="padding: 48px; text-align: center; color: var(--text-muted); font-size: 13.5px;">Biểu đồ doanh thu tài chính chỉ dành riêng cho Quản lý / Kế toán.</div>';
            return;
        }

        // Tính ngày bắt đầu tuần hiện tại (Thứ 2)
        const now = new Date();
        const currentDayOfWeek = (now.getDay() + 6) % 7; // 0 = Thứ 2, 6 = Chủ Nhật
        const mondayCurrent = new Date(now);
        mondayCurrent.setDate(now.getDate() - currentDayOfWeek);
        mondayCurrent.setHours(0, 0, 0, 0);

        const mondayPrevious = new Date(mondayCurrent);
        mondayPrevious.setDate(mondayCurrent.getDate() - 7);

        function formatISODate(d) {
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const dt = String(d.getDate()).padStart(2, '0');
            return `${y}-${m}-${dt}`;
        }

        const currentWeekDays = Array.from({ length: 7 }, (_, i) => {
            const d = new Date(mondayCurrent);
            d.setDate(mondayCurrent.getDate() + i);
            return formatISODate(d);
        });

        const previousWeekDays = Array.from({ length: 7 }, (_, i) => {
            const d = new Date(mondayPrevious);
            d.setDate(mondayPrevious.getDate() + i);
            return formatISODate(d);
        });

        // Tính doanh thu theo ngày từ các đơn hàng đã thanh toán và lịch dịch vụ hoàn tất đã thanh toán
        const completedOrders = liveSalesOrders.filter(o => {
            const s = (o.order_status || '').toUpperCase();
            const p = (o.payment_status || '').toUpperCase();
            if (s === 'CANCELLED' || s === 'DA_HUY' || s === 'REFUNDED' || s === 'DA_HOAN_TIEN' || p === 'REFUNDED') return false;
            return p === 'PAID' || p === 'DA_THANH_TOAN' || ((s === 'COMPLETED' || s === 'DELIVERED' || s === 'DA_GIAO') && p !== 'UNPAID' && p !== 'CHUA_THANH_TOAN' && p !== 'COD_PENDING');
        });

        const completedAppts = liveAppointments.filter(a => {
            const s = (a.appointment_status || '').toUpperCase();
            const p = (a.payment_status || '').toUpperCase();
            return (s === 'COMPLETED' || s === 'DA_HOAN_THANH') && (p === 'PAID' || p === 'DA_THANH_TOAN');
        });

        const currentWeek = currentWeekDays.map(dateStr => {
            const orderSum = completedOrders
                .filter(o => o.created_at && o.created_at.substring(0, 10) === dateStr)
                .reduce((sum, o) => sum + (parseFloat(o.total_amount) || 0), 0);
            const apptSum = completedAppts
                .filter(a => (toDateKey(a.appointment_date) === dateStr || toDateKey(a.created_at) === dateStr))
                .reduce((sum, a) => sum + (parseFloat(a.total_price || a.price || 0) || 0), 0);
            return (orderSum + apptSum) / 100000; // Đơn vị: 100k
        });

        const previousWeek = previousWeekDays.map(dateStr => {
            const orderSum = completedOrders
                .filter(o => o.created_at && o.created_at.substring(0, 10) === dateStr)
                .reduce((sum, o) => sum + (parseFloat(o.total_amount) || 0), 0);
            const apptSum = completedAppts
                .filter(a => (a.appointment_date === dateStr || (a.created_at && a.created_at.substring(0, 10) === dateStr)))
                .reduce((sum, a) => sum + (parseFloat(a.total_price || a.price || 0) || 0), 0);
            return (orderSum + apptSum) / 100000;
        });

        const maxVal = Math.max(...currentWeek, ...previousWeek, 40);
        const topTick = Math.ceil(maxVal / 20) * 20;

        const labels = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
        const yTicks = [
            { val: topTick, label: `${Math.round(topTick / 10)} tr` },
            { val: topTick * 0.75, label: `${Math.round(topTick * 0.75 / 10)} tr` },
            { val: topTick * 0.5, label: `${Math.round(topTick * 0.5 / 10)} tr` },
            { val: topTick * 0.25, label: `${Math.round(topTick * 0.25 / 10)} tr` },
            { val: 0, label: '0' }
        ];

        const chartLeft = 45;
        const chartRight = 620;
        const chartTop = 20;
        const chartBottom = 160;
        const chartHeight = chartBottom - chartTop;
        const chartWidth = chartRight - chartLeft;

        const x = (index) => chartLeft + (index / (labels.length - 1)) * chartWidth;
        const y = (val) => chartBottom - (val / (topTick || 1)) * chartHeight;

        const gridLines = yTicks.map((tick) => {
            const lineY = y(tick.val);
            return `<g class="chart-grid-row"><text x="${chartLeft - 10}" y="${lineY + 4}" text-anchor="end" class="chart-y-label">${tick.label}</text><line x1="${chartLeft}" y1="${lineY}" x2="${chartRight}" y2="${lineY}" stroke="#ECF2EE" stroke-width="1" /></g>`;
        }).join('');

        const dayLabels = labels.map((label, index) =>
            `<text x="${x(index).toFixed(1)}" y="${chartBottom + 20}" text-anchor="middle" class="chart-x-label">${label}</text>`
        ).join('');

        const currentPoints = currentWeek.map((val, idx) => `${x(idx).toFixed(1)},${y(val).toFixed(1)}`).join(' ');
        const previousPoints = previousWeek.map((val, idx) => `${x(idx).toFixed(1)},${y(val).toFixed(1)}`).join(' ');
        const areaPolygon = `${x(0).toFixed(1)},${chartBottom} ${currentPoints} ${x(currentWeek.length - 1).toFixed(1)},${chartBottom}`;

        const currentDots = currentWeek.map((value, index) =>
            `<circle cx="${x(index).toFixed(1)}" cy="${y(value).toFixed(1)}" r="4" fill="#236B48" stroke="#FFFFFF" stroke-width="2"><title>Thứ ${labels[index]}: ${labelCurrency(value * 100000)} VNĐ</title></circle>`
        ).join('');

        chart.innerHTML = `
            <svg viewBox="0 0 640 195" preserveAspectRatio="none" aria-hidden="true">
                ${gridLines}
                <polygon points="${areaPolygon}" fill="rgba(35, 107, 72, 0.06)" />
                <polyline points="${previousPoints}" fill="none" stroke="#AEC8B9" stroke-width="2" stroke-dasharray="5 5" stroke-linecap="round" stroke-linejoin="round" />
                <polyline points="${currentPoints}" fill="none" stroke="#236B48" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                ${currentDots}
                ${dayLabels}
            </svg>`;
    }

    // -------------------------------------------------------------
    // 4. RENDER LỊCH HẸN VÀ AGENDA THỰC TẾ (THÁNG / TUẦN / NGÀY)
    // -------------------------------------------------------------
    function setupDashboardCalendar() {
        const monthLabel = document.getElementById('dashboardCalendarMonth');
        const daysGrid = document.getElementById('dashboardCalendarDays');
        const weekdays = document.getElementById('dashboardCalendarWeekdays');
        const agendaTitle = document.getElementById('dashboardAgendaTitle');
        const bookingList = document.getElementById('dashboardBookingList');
        const calendarAgenda = document.querySelector('.dashboard-calendar-agenda');
        if (!monthLabel || !daysGrid || !agendaTitle || !bookingList) return;
        const monthWeekdayMarkup = weekdays?.innerHTML || '';

        const today = new Date();
        today.setHours(0, 0, 0, 0);
        let shownMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        let selectedDate = new Date(today);
        let calendarView = 'month';

        // Biến đổi các record liveAppointments 100% thực tế
        function getMappedBookings() {
            return liveAppointments.map(a => {
                const profile = liveProfilesMap.get(a.customer_id);
                const pet = livePetsMap.get(a.pet_id);
                const custName = profile ? `${profile.full_name}${profile.phone ? ' (' + profile.phone + ')' : ''}` : 'Khách hàng';
                const petName = pet ? pet.pet_name : 'Bé cưng';
                const srvName = liveServicesMap.get(a.service_id) || 'Chăm sóc thú cưng';
                const staffName = liveStaffMap.get(a.staff_id) || 'Kỹ thuật viên';

                let timeStr = '09:00';
                if (a.appointment_time) {
                    timeStr = a.appointment_time.substring(0, 5);
                } else if (a.created_at) {
                    timeStr = new Date(a.created_at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
                }

                const s = (a.appointment_status || '').toUpperCase();
                let statusText = 'Đã xác nhận';
                let badgeClass = 'badge-success';
                let statusCode = 'confirmed';
                if (s === 'COMPLETED' || s === 'DA_HOAN_THANH') {
                    statusText = 'Đã hoàn thành';
                    badgeClass = 'badge-success';
                    statusCode = 'confirmed';
                } else if (s === 'PENDING' || s === 'CHO_XAC_NHAN') {
                    statusText = 'Chờ xác nhận';
                    badgeClass = 'badge-warning';
                    statusCode = 'pending';
                } else if (s === 'CANCELLED' || s === 'DA_HUY') {
                    statusText = 'Đã hủy';
                    badgeClass = 'badge-danger';
                    statusCode = 'cancelled';
                }

                return {
                    id: a.id,
                    appointmentCode: a.appointment_code || 'BKG-' + a.id.substring(0, 6),
                    pet: petName,
                    customer: custName,
                    service: srvName,
                    staff: staffName,
                    time: timeStr,
                    date: a.appointment_date || (a.created_at ? a.created_at.substring(0, 10) : ''),
                    status: statusText,
                    badge: badgeClass,
                    statusCode: statusCode,
                    notes: a.notes || a.note || ''
                };
            });
        }

        function dateFromKey(key) {
            const [year, month, day] = key.split('-').map(Number);
            return new Date(year, month - 1, day);
        }

        function bookingsOnDate(date) {
            const dateKey = toDateKey(date);
            const allBookings = getMappedBookings();
            return allBookings.filter(b => b.date === dateKey);
        }

        function renderAgenda(date) {
            const dayBookings = bookingsOnDate(date);
            const isToday = toDateKey(date) === toDateKey(today);
            const dateFormatted = new Intl.DateTimeFormat('vi-VN', {
                weekday: 'long', day: 'numeric', month: 'long'
            }).format(date);
            agendaTitle.textContent = isToday ? `${dateFormatted} · Hôm nay` : dateFormatted;

            if (!dayBookings.length) {
                bookingList.innerHTML = '<p class="dashboard-agenda-empty">Ngày này chưa có lịch hẹn.</p>';
                return;
            }

            bookingList.innerHTML = dayBookings.map((booking, idx) => {
                const safeTime = escapeHtml(booking.time);
                const safePet = escapeHtml(booking.pet);
                const safeCustomer = escapeHtml(booking.customer);
                const safeService = escapeHtml(booking.service);
                const safeStatus = escapeHtml(booking.status);
                const safeBadge = escapeHtml(booking.badge || 'badge-neutral');

                return `
                <button type="button" class="dashboard-booking-row" data-booking-idx="${idx}">
                    <time>${safeTime}</time>
                    <span class="dashboard-booking-detail"><strong>${safePet} · ${safeCustomer}</strong><small>${safeService}</small></span>
                    <span class="admin-badge ${safeBadge}">${safeStatus}</span>
                </button>`;
            }).join('');

            bookingList.querySelectorAll('.dashboard-booking-row').forEach((btn) => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const idx = parseInt(btn.dataset.bookingIdx, 10);
                    const booking = dayBookings[idx] || dayBookings[0];
                    if (booking) openBookingQuickModal(booking);
                });
            });
        }

        function renderCalendar() {
            const year = shownMonth.getFullYear();
            const month = shownMonth.getMonth();
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const mondayFirstOffset = (new Date(year, month, 1).getDay() + 6) % 7;
            const dateLabel = new Intl.DateTimeFormat('vi-VN', {
                month: 'long', year: 'numeric'
            }).format(shownMonth);

            document.getElementById('dashboardCalendarPrev')?.setAttribute(
                'aria-label', calendarView === 'month' ? 'Tháng trước' : calendarView === 'week' ? 'Tuần trước' : 'Ngày trước'
            );
            document.getElementById('dashboardCalendarNext')?.setAttribute(
                'aria-label', calendarView === 'month' ? 'Tháng sau' : calendarView === 'week' ? 'Tuần sau' : 'Ngày sau'
            );

            const allBookings = getMappedBookings();
            const bookedDateKeys = new Set(allBookings.map(b => b.date).filter(Boolean));

            const calendarDates = [];
            if (calendarView === 'month') {
                for (let blank = 0; blank < mondayFirstOffset; blank += 1) calendarDates.push(null);
                for (let day = 1; day <= daysInMonth; day += 1) calendarDates.push(new Date(year, month, day));
                while (calendarDates.length % 7 !== 0) calendarDates.push(null);
                monthLabel.textContent = dateLabel;
                daysGrid.classList.remove('is-week-view', 'is-day-view');
                if (weekdays) {
                    weekdays.hidden = false;
                    weekdays.classList.remove('is-week-heading');
                    weekdays.innerHTML = monthWeekdayMarkup;
                }
            } else if (calendarView === 'week') {
                const weekStart = new Date(selectedDate);
                weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7));
                for (let day = 0; day < 7; day += 1) {
                    const date = new Date(weekStart);
                    date.setDate(weekStart.getDate() + day);
                    calendarDates.push(date);
                }
                const weekEnd = calendarDates[6];
                monthLabel.textContent = `${weekStart.getDate()} ${new Intl.DateTimeFormat('vi-VN', { month: 'short' }).format(weekStart)} – ${weekEnd.getDate()} ${new Intl.DateTimeFormat('vi-VN', { month: 'short', year: 'numeric' }).format(weekEnd)}`;
                daysGrid.classList.add('is-week-view');
                daysGrid.classList.remove('is-day-view');
                if (weekdays) {
                    weekdays.hidden = false;
                    weekdays.classList.add('is-week-heading');
                    weekdays.innerHTML = calendarDates.map((date) => {
                        const key = toDateKey(date);
                        const isToday = key === toDateKey(today);
                        const weekday = new Intl.DateTimeFormat('vi-VN', { weekday: 'short' }).format(date);
                        return `<button type="button" class="dashboard-week-heading-btn ${key === toDateKey(selectedDate) ? 'is-selected' : ''} ${isToday ? 'is-today' : ''}" data-calendar-date="${key}" aria-pressed="${key === toDateKey(selectedDate)}" title="${isToday ? 'Hôm nay' : weekday}"><span>${isToday ? 'Hôm nay' : weekday}</span><strong>${date.getDate()}</strong></button>`;
                    }).join('');
                }
            } else {
                calendarDates.push(new Date(selectedDate));
                const isToday = toDateKey(selectedDate) === toDateKey(today);
                const dayFormatted = new Intl.DateTimeFormat('vi-VN', {
                    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
                }).format(selectedDate);
                monthLabel.textContent = isToday ? `${dayFormatted} · Hôm nay` : dayFormatted;
                daysGrid.classList.add('is-day-view');
                daysGrid.classList.remove('is-week-view');
                if (weekdays) {
                    weekdays.hidden = true;
                    weekdays.classList.remove('is-week-heading');
                }
            }

            if (calendarView === 'week') {
                daysGrid.innerHTML = calendarDates.map((date) => {
                    const key = toDateKey(date);
                    const dayBookings = bookingsOnDate(date);
                    const selected = key === toDateKey(selectedDate);
                    const events = dayBookings.length
                        ? dayBookings.map((booking) => `<span class="dashboard-week-event"><time>${booking.time}</time>${booking.pet}</span>`).join('')
                        : '<span class="dashboard-week-empty">Không có lịch</span>';
                    return `<button type="button" class="dashboard-calendar-day dashboard-week-day ${selected ? 'is-selected' : ''} ${key === toDateKey(today) ? 'is-today' : ''}" data-calendar-date="${key}" aria-label="${new Intl.DateTimeFormat('vi-VN', { weekday: 'long', day: 'numeric', month: 'long' }).format(date)}" aria-pressed="${selected}"><span class="dashboard-week-events">${events}</span></button>`;
                }).join('');
            } else if (calendarView === 'day') {
                const dayBookings = bookingsOnDate(selectedDate);
                const startHour = 0;
                const endHour = 23;
                const slotHeight = 46;
                const timelineTopOffset = 16;

                const timeSlotsMarkup = Array.from({ length: endHour - startHour + 1 }, (_, i) => {
                    const hour = startHour + i;
                    return `<div class="dashboard-day-timeline-hour" style="top: ${timelineTopOffset + i * slotHeight}px;"><time>${String(hour).padStart(2, '0')}:00</time><div class="dashboard-day-timeline-line"></div></div>`;
                }).join('');

                const parsedBookings = dayBookings.map((b) => {
                    const [h, m] = (b.time || '09:00').split(':').map(Number);
                    const startMinutes = (h - startHour) * 60 + (m || 0);
                    const durationMinutes = 60;
                    return { ...b, startMinutes, endMinutes: startMinutes + durationMinutes };
                }).sort((a, b) => a.startMinutes - b.startMinutes);

                const clusters = [];
                parsedBookings.forEach((booking) => {
                    let added = false;
                    for (const cluster of clusters) {
                        const hasOverlap = cluster.some((item) =>
                            booking.startMinutes < item.endMinutes && booking.endMinutes > item.startMinutes
                        );
                        if (hasOverlap) {
                            cluster.push(booking);
                            added = true;
                            break;
                        }
                    }
                    if (!added) {
                        clusters.push([booking]);
                    }
                });

                const eventsMarkup = clusters.flatMap((cluster) => {
                    const totalInCluster = cluster.length;
                    return cluster.map((b, idx) => {
                        const topPx = timelineTopOffset + (b.startMinutes / 60) * slotHeight;
                        const heightPx = Math.max(38, (60 / 60) * slotHeight - 4);

                        let styleAttrs = `top: ${topPx}px; height: ${heightPx}px;`;
                        const statusClass = b.statusCode === 'pending' ? 'status-pending' : (b.statusCode === 'cancelled' ? 'status-cancelled' : 'status-confirmed');
                        let classes = `dashboard-day-event ${statusClass}`;

                        if (totalInCluster === 1) {
                            classes += ' is-single-event';
                            styleAttrs += ' left: 0; width: 96%; z-index: 1;';
                        } else {
                            const widthPercent = Math.max(62, 94 - idx * 14);
                            const leftPercent = idx * 16;
                            const zIndex = idx + 2;

                            classes += ` is-overlapped-layer layer-idx-${idx % 3}`;
                            styleAttrs += ` left: ${leftPercent}%; width: ${widthPercent}%; z-index: ${zIndex};`;
                        }

                        return `<button type="button" class="${classes}" style="${styleAttrs}" data-dashboard-module="Dịch vụ" data-booking-id="${b.id || ''}">
                            <div class="dashboard-day-event-header">
                                <strong>${b.time} · ${b.pet}</strong>
                                <span class="dashboard-day-event-status">${b.status}</span>
                            </div>
                            <div class="dashboard-day-event-body">${b.customer} · ${b.service}</div>
                        </button>`;
                    });
                }).join('');

                const totalTimelineHeight = timelineTopOffset + (endHour - startHour + 1) * slotHeight + 16;
                daysGrid.innerHTML = `
                    <div class="dashboard-day-timeline-container" style="height: ${totalTimelineHeight}px;">
                        <div class="dashboard-day-timeline-grid">${timeSlotsMarkup}</div>
                        <div class="dashboard-day-timeline-events">${eventsMarkup || '<div style="padding: 24px; text-align: center; color: var(--text-muted);">Không có ca dịch vụ trong ngày này</div>'}</div>
                    </div>`;

                const timelineContainer = daysGrid.querySelector('.dashboard-day-timeline-container');
                if (timelineContainer) {
                    const firstBooking = parsedBookings[0];
                    let targetHour = 7.5;
                    if (firstBooking) {
                        const bookingHour = firstBooking.startMinutes / 60;
                        targetHour = Math.max(0, bookingHour - 1);
                    }
                    timelineContainer.scrollTop = timelineTopOffset + targetHour * slotHeight;
                }

                daysGrid.querySelectorAll('.dashboard-day-event').forEach((btn) => {
                    btn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const bId = btn.getAttribute('data-booking-id');
                        const found = dayBookings.find(b => b.id === bId) || dayBookings[0];
                        if (found) openBookingQuickModal(found);
                    });
                });
            } else {
                daysGrid.innerHTML = calendarDates.map((date) => {
                    if (!date) return '<span class="dashboard-calendar-blank" aria-hidden="true"></span>';
                    const key = toDateKey(date);
                    const isToday = key === toDateKey(today);
                    const hasAppointments = bookedDateKeys.has(key);
                    const classes = [
                        'dashboard-calendar-day',
                        hasAppointments ? 'has-appointments' : '',
                        isToday ? 'is-today' : '',
                        key === toDateKey(selectedDate) ? 'is-selected' : ''
                    ].filter(Boolean).join(' ');
                    const label = new Intl.DateTimeFormat('vi-VN', { weekday: 'long', day: 'numeric', month: 'long' }).format(date);
                    const todayText = isToday ? ', Hôm nay' : '';
                    return `<button type="button" class="${classes}" data-calendar-date="${key}" aria-label="${label}${todayText}${hasAppointments ? ', có lịch hẹn' : ''}" aria-pressed="${key === toDateKey(selectedDate)}" title="${label}${todayText}"><span class="dashboard-calendar-day-number">${date.getDate()}</span>${hasAppointments ? '<span class="dashboard-calendar-event-dot"></span>' : ''}</button>`;
                }).join('');
            }

            document.querySelectorAll('[data-calendar-view]').forEach((button) => {
                const active = button.dataset.calendarView === calendarView;
                button.classList.toggle('is-active', active);
                button.setAttribute('aria-selected', String(active));
            });
            calendarAgenda?.classList.toggle('is-week-view', calendarView === 'week');
            calendarAgenda?.classList.toggle('is-day-view', calendarView === 'day');
            renderAgenda(selectedDate);

            daysGrid.querySelectorAll('[data-calendar-date]').forEach((button) => {
                button.addEventListener('click', () => {
                    selectedDate = dateFromKey(button.dataset.calendarDate);
                    renderCalendar();
                });
            });
            weekdays?.querySelectorAll('[data-calendar-date]').forEach((button) => {
                button.addEventListener('click', () => {
                    selectedDate = dateFromKey(button.dataset.calendarDate);
                    renderCalendar();
                });
            });
        }

        document.getElementById('dashboardCalendarPrev')?.addEventListener('click', () => {
            if (calendarView === 'month') {
                shownMonth = new Date(shownMonth.getFullYear(), shownMonth.getMonth() - 1, 1);
                selectedDate = new Date(shownMonth.getFullYear(), shownMonth.getMonth(), 1);
            } else if (calendarView === 'week') {
                selectedDate.setDate(selectedDate.getDate() - 7);
                shownMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
            } else {
                selectedDate.setDate(selectedDate.getDate() - 1);
                shownMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
            }
            renderCalendar();
        });
        document.getElementById('dashboardCalendarNext')?.addEventListener('click', () => {
            if (calendarView === 'month') {
                shownMonth = new Date(shownMonth.getFullYear(), shownMonth.getMonth() + 1, 1);
                selectedDate = new Date(shownMonth.getFullYear(), shownMonth.getMonth(), 1);
            } else if (calendarView === 'week') {
                selectedDate.setDate(selectedDate.getDate() + 7);
                shownMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
            } else {
                selectedDate.setDate(selectedDate.getDate() + 1);
                shownMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
            }
            renderCalendar();
        });

        function goToToday() {
            const now = new Date();
            now.setHours(0, 0, 0, 0);
            selectedDate = new Date(now);
            shownMonth = new Date(now.getFullYear(), now.getMonth(), 1);
            renderCalendar();
        }

        document.getElementById('dashboardCalendarToday')?.addEventListener('click', goToToday);
        document.getElementById('dashboardCalendarMonth')?.addEventListener('click', goToToday);

        document.querySelectorAll('[data-calendar-view]').forEach((button) => {
            button.addEventListener('click', () => {
                calendarView = button.dataset.calendarView;
                shownMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
                renderCalendar();
            });
        });

        renderCalendar();
    }

    // -------------------------------------------------------------
    // 5. RENDER HIỆU SUẤT CHATBOT AI VÀ TỶ LỆ LẤP ĐẦY NHÂN SỰ
    // -------------------------------------------------------------
    function renderChatbotAndStaffMetrics() {
        const todayStr = getTodayDateString();

        // 1. Chỉ số Chatbot
        const totalSessions = liveChatConversations.length;
        const handoverSessions = liveChatConversations.filter(c => {
            const s = (c.status || '').toUpperCase();
            return s === 'ESCALATED' || s === 'HANDOVER' || s === 'AGENT_HANDOVER' || s === 'AGENT_HANDLING' || s === 'HUMAN_AGENT';
        }).length;
        const aiSessions = Math.max(0, totalSessions - handoverSessions);
        // D-05: 0 phiên hiển thị '—' thay vì 100%
        const aiPercent = totalSessions > 0 ? Math.round((aiSessions / totalSessions) * 100) : 0;

        const elDonutCircle = document.getElementById('dashboardDonutCircle');
        if (elDonutCircle) {
            const strokeDash = totalSessions > 0 ? (aiPercent / 100) * 301.59 : 0;
            elDonutCircle.setAttribute('stroke-dasharray', `${strokeDash.toFixed(2)} 301.59`);
        }

        const elPercentWrap = document.getElementById('dashboardChatbotPercentWrap');
        if (elPercentWrap) {
            elPercentWrap.innerHTML = totalSessions > 0 
                ? `<strong>${aiPercent}%</strong><small>AI tự xử lý</small>`
                : `<strong>—</strong><small>Chưa có phiên</small>`;
        }

        const elAiSessions = document.getElementById('dashboardAiSessionsCount');
        if (elAiSessions) elAiSessions.textContent = `${aiSessions} phiên`;

        const elHandoverSessions = document.getElementById('dashboardHandoverSessionsCount');
        if (elHandoverSessions) elHandoverSessions.textContent = `${handoverSessions} phiên`;

        const elTotalChat = document.getElementById('dashboardTotalChatSessions');
        if (elTotalChat) elTotalChat.textContent = `${totalSessions} phiên trò chuyện`;

        // 2. Chỉ số Lấp đầy nhân sự (Tỷ lệ nhân viên đang có ca phụ trách hôm nay)
        // D-06: Sử dụng đúng trường account_status hoặc status để lọc nhân sự hoạt động
        const activeStaffList = liveStaffList.filter(s => {
            const st = (s.account_status || s.status || '').toUpperCase();
            return st === 'ACTIVE' || st === 'HOAT_DONG' || (st !== 'INACTIVE' && st !== 'RESIGNED' && st !== 'NGHI_VIEC' && st !== 'LOCKED');
        });
        const totalActiveStaff = activeStaffList.length || liveStaffList.length;

        const assignedStaffToday = new Set(
            liveAppointments
                .filter(a => {
                    const isToday = toDateKey(a.appointment_date) === todayStr;
                    const s = (a.appointment_status || '').toUpperCase();
                    return isToday && a.staff_id && s !== 'CANCELLED' && s !== 'DA_HUY';
                })
                .map(a => a.staff_id)
        );

        const utilPercent = totalActiveStaff > 0 
            ? Math.min(100, Math.round((assignedStaffToday.size / totalActiveStaff) * 100)) 
            : 0;

        const elStaffPercent = document.getElementById('dashboardStaffUtilPercent');
        if (elStaffPercent) elStaffPercent.textContent = `${utilPercent}%`;

        const elStaffBar = document.getElementById('dashboardStaffUtilBar');
        if (elStaffBar) elStaffBar.style.width = `${utilPercent}%`;
    }

    // -------------------------------------------------------------
    // 6. ĐIỀU HƯỚNG LIÊN PHÂN HỆ THÔNG MINH
    // -------------------------------------------------------------
    function bindModuleNavigation(root = document) {
        root.querySelectorAll('[data-dashboard-module]').forEach((control) => {
            if (control.dataset.dashboardBound === 'true') return;
            control.dataset.dashboardBound = 'true';
            control.addEventListener('click', () => {
                const moduleName = control.getAttribute('data-dashboard-module');
                const action = control.getAttribute('data-action');
                const sku = control.getAttribute('data-sku');
                const bookingId = control.getAttribute('data-booking-id');

                if (action === 'complaints') {
                    sessionStorage.setItem('pawpal_admin_complaint_active_subtab', 'tab-complaint-services');
                    sessionStorage.setItem('pawpal_admin_complaint_filter_status', 'pending');
                } else if (action === 'orders') {
                    sessionStorage.setItem('pawpal_admin_order_subtab', 'tab-order-list');
                    sessionStorage.setItem('pawpal_admin_order_filter_status', 'pending');
                } else if (control.id === 'btnDashboardViewAllStock' || control.classList.contains('dashboard-stock-heading')) {
                    sessionStorage.setItem('pawpal_admin_order_subtab', 'tab-order-products');
                } else if (sku) {
                    sessionStorage.setItem('pawpal_admin_order_subtab', 'tab-order-products');
                    sessionStorage.setItem('pawpal_admin_product_search', sku);
                } else if (bookingId) {
                    sessionStorage.setItem('pawpal_admin_services_active_subtab', 'tab-service-detail');
                    sessionStorage.setItem('pawpal_admin_service_selected_id', bookingId);
                } else if (moduleName === 'Dịch vụ') {
                    sessionStorage.setItem('pawpal_admin_services_active_subtab', 'tab-service-bookings');
                } else if (moduleName === 'Bán hàng') {
                    sessionStorage.setItem('pawpal_admin_order_subtab', 'tab-order-list');
                } else if (moduleName === 'Khách hàng') {
                    sessionStorage.setItem('pawpal_admin_customer_subtab', 'tab-list');
                } else if (moduleName === 'Thú cưng') {
                    sessionStorage.setItem('pawpal_admin_pet_subtab', 'tab-pet-list');
                }

                const target = Array.from(document.querySelectorAll('.sidebar-menu-btn'))
                    .find((button) => button.getAttribute('data-title') === moduleName);
                if (target) target.click();
            });
        });
    }

    // -------------------------------------------------------------
    // 7. GIAI ĐOẠN 2: THANH THAO TÁC TIẾP NHẬN TẠI QUẦY
    // -------------------------------------------------------------
    function setupQuickReceptionActions() {
        const btnPet = document.getElementById('btnQuickReceptionPet');
        const btnService = document.getElementById('btnQuickBookingService');
        const btnOrder = document.getElementById('btnQuickCreateOrder');

        const openCreateFormAfterNavigation = (moduleName, buttonId) => {
            const target = Array.from(document.querySelectorAll('.sidebar-menu-btn'))
                .find(button => button.getAttribute('data-title') === moduleName);
            if (!target) return;

            window.addEventListener('admin:module-show', (event) => {
                if (event.detail?.module === moduleName) {
                    document.getElementById(buttonId)?.click();
                }
            }, { once: true });
            target.click();
        };

        if (btnPet) {
            btnPet.addEventListener('click', () => {
                sessionStorage.setItem('pawpal_admin_pet_subtab', 'tab-pet-list');
                openCreateFormAfterNavigation('Thú cưng', 'btnOpenAddPetModal');
            });
        }

        if (btnService) {
            btnService.addEventListener('click', () => {
                sessionStorage.setItem('pawpal_admin_services_active_subtab', 'tab-service-bookings');
                openCreateFormAfterNavigation('Dịch vụ', 'btnOpenCreateBookingModal');
            });
        }

        if (btnOrder) {
            btnOrder.addEventListener('click', () => {
                sessionStorage.setItem('pawpal_admin_order_subtab', 'tab-order-list');
                openCreateFormAfterNavigation('Bán hàng', 'btnOpenCreateOrderModal');
            });
        }
    }

    // -------------------------------------------------------------
    // 8. GIAI ĐOẠN 2: MODAL XEM NHANH CA DỊCH VỤ TRÊN LỊCH HẸN
    // -------------------------------------------------------------
    let currentSelectedQuickBooking = null;

    function openBookingQuickModal(booking) {
        currentSelectedQuickBooking = booking;
        const modal = document.getElementById('dashboardBookingQuickModal');
        if (!modal) return;

        const elPet = document.getElementById('modalBookingPet');
        const elCust = document.getElementById('modalBookingCustomer');
        const elSvc = document.getElementById('modalBookingService');
        const elTime = document.getElementById('modalBookingTime');
        const elStaff = document.getElementById('modalBookingStaff');
        const elStatus = document.getElementById('modalBookingStatus');
        const elNotes = document.getElementById('modalBookingNotes');

        const todayStr = getTodayDateString();
        const rawDate = (booking.date || '').substring(0, 10);
        let dateDisplay = 'Hôm nay';
        if (rawDate) {
            if (rawDate === todayStr) {
                dateDisplay = 'Hôm nay';
            } else {
                const parts = rawDate.split('-');
                if (parts.length === 3) {
                    dateDisplay = `${parts[2]}/${parts[1]}/${parts[0]}`;
                } else {
                    dateDisplay = rawDate;
                }
            }
        }

        if (elPet) elPet.textContent = booking.pet || 'Bé cưng';
        if (elCust) elCust.textContent = booking.customer || 'Khách hàng';
        if (elSvc) elSvc.textContent = booking.service || 'Chăm sóc thú cưng';
        if (elTime) elTime.textContent = `${booking.time || '09:30'} · ${dateDisplay}`;
        if (elStaff) elStaff.textContent = booking.staff || 'Kỹ thuật viên';
        if (elStatus) {
            elStatus.textContent = '';
            const badgeSpan = document.createElement('span');
            badgeSpan.className = `admin-badge ${booking.badge || 'badge-neutral'}`;
            badgeSpan.textContent = booking.status || 'Đã xác nhận';
            elStatus.appendChild(badgeSpan);
        }
        if (elNotes) elNotes.textContent = booking.notes || 'Chăm sóc dịu nhẹ, đúng quy trình an toàn.';

        modal.style.display = 'flex';
    }

    function closeBookingQuickModal() {
        const modal = document.getElementById('dashboardBookingQuickModal');
        if (modal) modal.style.display = 'none';
        currentSelectedQuickBooking = null;
    }

    function setupBookingQuickModalEvents() {
        const modal = document.getElementById('dashboardBookingQuickModal');
        const btnClose = document.getElementById('btnCloseBookingQuickModal');
        const btnDismiss = document.getElementById('btnDismissBookingModal');
        const btnGo = document.getElementById('btnGoToServiceDetail');

        if (btnClose) btnClose.addEventListener('click', closeBookingQuickModal);
        if (btnDismiss) btnDismiss.addEventListener('click', closeBookingQuickModal);
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) closeBookingQuickModal();
            });
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.style.display !== 'none') {
                    closeBookingQuickModal();
                }
            });
        }

        if (btnGo) {
            btnGo.addEventListener('click', () => {
                const booking = currentSelectedQuickBooking;
                closeBookingQuickModal();
                sessionStorage.setItem('pawpal_admin_services_active_subtab', 'tab-service-detail');
                if (booking) {
                    const targetCode = booking.appointmentCode || booking.id;
                    sessionStorage.setItem('pawpal_admin_service_selected_id', targetCode);
                    window.addEventListener('admin:module-show', async (event) => {
                        if (event.detail?.module === 'Dịch vụ') {
                            const services = window.PawpalServices;
                            await services?.loadServicesData?.();
                            if (services?.state?.bookingsData?.some(item => item.id === targetCode || item.dbId === booking.id)) {
                                services.openBookingDetail(targetCode);
                            } else {
                                services?.switchSubtab?.('tab-service-bookings');
                                services?.showToast?.('Không tìm thấy ca dịch vụ tương ứng.', 'warning');
                            }
                        }
                    }, { once: true });
                }
                const target = Array.from(document.querySelectorAll('.sidebar-menu-btn'))
                    .find(b => b.getAttribute('data-title') === 'Dịch vụ');
                if (target) target.click();
            });
        }
    }

    // -------------------------------------------------------------
    // GIAI ĐOẠN 4: REALTIME CHANNEL LẮNG NGHE DỮ LIỆU THAY ĐỔI
    // -------------------------------------------------------------
    let dashboardRealtimeSub = null;
    function setupDashboardRealtimeSync() {
        const client = getSupabaseClient();
        if (!client || typeof client.channel !== 'function') return;

        try {
            if (dashboardRealtimeSub) {
                client.removeChannel(dashboardRealtimeSub);
                window.PawpalDataStore?.recordMetric?.('channel-remove', 'admin-dashboard-live-sync');
            }

            const triggerSync = (invalidatePattern, refreshFn) => {
                if (window.PawpalDataStore?.handleRealtimeChange) {
                    window.PawpalDataStore.handleRealtimeChange({
                        moduleName: 'Dashboard',
                        invalidatePattern: invalidatePattern || 'dashboard:*',
                        onActiveRefresh: async () => {
                            await loadDashboardData({ force: true });
                            if (typeof refreshFn === 'function') {
                                refreshFn();
                            } else {
                                renderDashboardKPIs();
                                renderDashboardStockList();
                                renderRevenueChart();
                                renderChatbotAndStaffMetrics();
                            }
                        },
                        debounceMs: 300
                    });
                } else if (sessionStorage.getItem('pawpal_admin_active_module') === 'Dashboard') {
                    loadDashboardData({ force: true }).then(() => {
                        if (refreshFn) refreshFn();
                    });
                }
            };

            dashboardRealtimeSub = client.channel('admin-dashboard-live-sync')
                .on('postgres_changes', { event: '*', schema: 'public', table: 'sales_order' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderDashboardKPIs();
                        renderRevenueChart();
                    });
                })
                .on('postgres_changes', { event: '*', schema: 'public', table: 'appointment' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderDashboardKPIs();
                        setupDashboardCalendar();
                        renderChatbotAndStaffMetrics();
                    });
                })
                .on('postgres_changes', { event: '*', schema: 'public', table: 'support_ticket' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderDashboardKPIs();
                    });
                })
                .on('postgres_changes', { event: '*', schema: 'public', table: 'customer' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderDashboardKPIs();
                    });
                })
                .on('postgres_changes', { event: '*', schema: 'public', table: 'pet_profile' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderDashboardKPIs();
                    });
                })
                .on('postgres_changes', { event: '*', schema: 'public', table: 'product' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderDashboardStockList();
                    });
                })
                .on('postgres_changes', { event: '*', schema: 'public', table: 'inventory' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderDashboardStockList();
                    });
                })
                .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_conversation' }, () => {
                    triggerSync('dashboard:*', () => {
                        renderChatbotAndStaffMetrics();
                    });
                })
                .subscribe();

            window.PawpalDataStore?.recordMetric?.('channel-add', 'admin-dashboard-live-sync');
        } catch (e) {
            console.warn('[Dashboard] Lỗi khởi tạo Realtime Channel:', e);
        }
    }

    // ====================================================================
    // KHỞI ĐỘNG CHÍNH THỨC TOÀN BỘ DASHBOARD
    // ====================================================================
    let _isDashboardInit = false;

    async function startDashboard() {
        if (_isDashboardInit) {
            // Đã khởi tạo DOM và event listeners — chỉ re-render dữ liệu
            if (Date.now() - _dashLastFetchedAt >= DASH_CACHE_TTL_MS) {
                await loadDashboardData({ force: true });
            }
            renderDashboardKPIs();
            renderDashboardStockList();
            renderRevenueChart();
            renderChatbotAndStaffMetrics();
            return;
        }

        _isDashboardInit = true;
        await loadDashboardData();
        try { renderDashboardKPIs(); } catch (e) { console.warn('[Dashboard] renderDashboardKPIs error:', e); }
        try { renderDashboardStockList(); } catch (e) { console.warn('[Dashboard] renderDashboardStockList error:', e); }
        try { renderRevenueChart(); } catch (e) { console.warn('[Dashboard] renderRevenueChart error:', e); }
        try { setupDashboardCalendar(); } catch (e) { console.warn('[Dashboard] setupDashboardCalendar error:', e); }
        try { renderChatbotAndStaffMetrics(); } catch (e) { console.warn('[Dashboard] renderChatbotAndStaffMetrics error:', e); }
        setupQuickReceptionActions();
        setupBookingQuickModalEvents();
        bindModuleNavigation();
        setupDashboardRealtimeSync();

        window.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') {
                _dashHiddenAt = Date.now();
            }
        });

        window.addEventListener('focus', async () => {
            // Chỉ reload nếu tab đã bị ẩn tối thiểu 5 phút
            const hiddenDuration = Date.now() - _dashHiddenAt;
            if (_dashHiddenAt === 0 || hiddenDuration < DASH_FOCUS_RELOAD_AFTER_MS) return;
            _dashHiddenAt = 0;
            await loadDashboardData({ force: true });
            try { renderDashboardKPIs(); } catch (e) {}
            try { renderDashboardStockList(); } catch (e) {}
            try { renderRevenueChart(); } catch (e) {}
            try { renderChatbotAndStaffMetrics(); } catch (e) {}
        });

        // Lắng nghe sự kiện biến động dữ liệu từ DataStore (PERF-03.D05)
        window.addEventListener('pawpal:mutation', (e) => {
            const table = e.detail?.table;
            if (['sales_order', 'appointment', 'support_ticket', 'product', 'inventory', 'customer', 'pet_profile'].includes(table)) {
                window.PawpalDataStore?.invalidate?.('dashboard:*');
            }
        });

        // [D-11] Lắng nghe sự kiện biến động dữ liệu từ phân hệ khác để tự động xóa cache Dashboard
        window.addEventListener('pawpal:invalidate-dashboard-cache', async () => {
            _dashLastFetchedAt = 0;
            window.PawpalDataStore?.invalidate?.('dashboard:*');
            const dashEl = document.querySelector('.dashboard-module') || document.getElementById('moduleDashboard');
            if (dashEl && dashEl.style.display !== 'none') {
                await loadDashboardData({ force: true });
                try { renderDashboardKPIs(); } catch (e) {}
                try { renderDashboardStockList(); } catch (e) {}
                try { renderRevenueChart(); } catch (e) {}
                try { renderChatbotAndStaffMetrics(); } catch (e) {}
            }
        });
    }

    window.PawpalDashboard = {
        init: startDashboard,
        loadDashboardData,
        refresh: async function() {
            _dashLastFetchedAt = 0;
            await loadDashboardData({ force: true });
            renderDashboardKPIs();
            renderDashboardStockList();
            renderRevenueChart();
            renderChatbotAndStaffMetrics();
        },
        getLastUpdatedTime: function() {
            return _dashLastFetchedAt ? new Date(_dashLastFetchedAt).toLocaleTimeString('vi-VN') : 'Chưa cập nhật';
        },
        renderDashboardKPIs,
        renderDashboardStockList,
        renderRevenueChart,
        setupDashboardCalendar
    };

    // Chỉ tự khởi động nếu module được load độc lập mà không qua router admin.js
    if (!window._pawpalAdminLoaded && !document.querySelector('.admin-layout')) {
        startDashboard();
    }
})();
