// tab-service-detail.js - Subtab Hồ sơ ca dịch vụ 360° Pawpal-er
(function() {
    'use strict';

    const PawpalServices = window.PawpalServices = window.PawpalServices || {};
    const escapeTripText = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    PawpalServices.subtabs = PawpalServices.subtabs || {};

    let currentEditingCarelogStepIdx = null;
    let editCarelogStepPhotosTemp = [];

    function openBookingDetail(bookingId) {
        PawpalServices.state.selectedBookingId = bookingId;
        sessionStorage.setItem('pawpal_admin_service_selected_id', bookingId);
        if (PawpalServices.switchSubtab) {
            PawpalServices.switchSubtab('tab-service-detail');
        }
    }

    function renderBookingDetail(bookingId) {
        const bookingsData = PawpalServices.state?.bookingsData || [];
        const booking = bookingsData.find(b => b.id === bookingId || b.dbId === bookingId);
        const section = document.getElementById('subtab-tab-service-detail');
        const card = section?.querySelector('.service-detail-card');
        const state = document.getElementById('serviceDetailState');
        if (!booking) {
            if (card) card.style.display = 'none';
            if (state) {
                state.style.display = 'block';
                state.textContent = PawpalServices.state.loadError
                    ? 'Không thể tải hồ sơ lịch hẹn. Vui lòng tải lại trang.'
                    : !PawpalServices.state.isLoaded ? 'Đang tải hồ sơ lịch hẹn…'
                    : !bookingId ? 'Chọn một lịch hẹn từ danh sách để xem hồ sơ.'
                    : 'Không tìm thấy lịch hẹn đã chọn hoặc bạn chưa có quyền xem.';
            }
            PawpalServices.updateBreadcrumb?.(null);
            return;
        }
        if (card) card.style.display = '';
        if (state) state.style.display = 'none';
        PawpalServices.updateBreadcrumb?.(booking.id);

        PawpalServices.state.selectedBookingId = booking.id;
        sessionStorage.setItem('pawpal_admin_service_selected_id', booking.id);

        const formatCurrency = PawpalServices.formatCurrency || (num => `${num} đ`);
        const getStatusBadge = PawpalServices.getStatusBadge || (st => `<span class="admin-badge">${st}</span>`);

        // Headline và Meta
        const codeEl = document.getElementById('detailBookingCode');
        const metaEl = document.getElementById('detailBookingMeta');
        if (codeEl) codeEl.textContent = booking.id;
        if (metaEl) {
            if (booking.category === 'Hotel') {
                metaEl.textContent = `Lưu trú: ${booking.checkInDate || booking.date} ➔ ${booking.checkOutDate || 'Chưa cập nhật'} (${booking.nights || 'Chưa cập nhật'} đêm) | Phòng: ${booking.roomCode || 'Chưa cập nhật'} | Cơ sở: ${booking.branch || 'PawPal Quận 1'}`;
            } else if (booking.category === 'Taxi') {
                const shortPickup = booking.pickupAddress ? (booking.pickupAddress.length > 22 ? booking.pickupAddress.substring(0, 22) + '...' : booking.pickupAddress) : 'Đón tận nơi';
                metaEl.textContent = `Giờ đón: ${booking.time} - ${booking.date} | ${booking.tripType || 'Chưa cập nhật'} | Lộ trình: ${shortPickup} ➔ ${booking.dropoffAddress || 'Chưa cập nhật'}`;
            } else {
                metaEl.textContent = `Thời gian hẹn: ${booking.time} - ${booking.date} | Cơ sở: ${booking.branch || 'PawPal Quận 1'}`;
            }
        }

        if (metaEl) {
            const formatRecordedAt = value => new Intl.DateTimeFormat('vi-VN', {timeZone:'Asia/Bangkok',dateStyle:'short',timeStyle:'short'}).format(new Date(value));
            if (booking.intakeRecord?.recordedAt) metaEl.textContent += ` | Tiếp nhận: ${formatRecordedAt(booking.intakeRecord.recordedAt)}`;
            if (booking.handoverRecord?.recordedAt) metaEl.textContent += ` | Bàn giao: ${formatRecordedAt(booking.handoverRecord.recordedAt)}`;
        }
        const belongingsSummary = document.getElementById('detailBelongingsText');
        if (belongingsSummary) belongingsSummary.textContent = booking.intakeRecord?.belongingsNote || booking.intakeRecord?.belongings?.join(', ') || 'Không có';

        // Cảnh báo an toàn Pet Alert
        const petAlertBanner = document.getElementById('detailPetAlertBanner');
        if (petAlertBanner) {
            if (booking.petAlert) {
                petAlertBanner.style.display = 'block';
                petAlertBanner.textContent = `CẢNH BÁO AN TOÀN CHO BÉ: ${booking.petAlert}`;
            } else {
                petAlertBanner.style.display = 'none';
            }
        }

        // Nút thao tác một chạm theo trạng thái
        const actionButtonsContainer = document.getElementById('detailBookingActionButtons');
        if (actionButtonsContainer) {
            actionButtonsContainer.innerHTML = '';
            if (booking.status === 'pending') {
                actionButtonsContainer.innerHTML = `
                    <button type="button" class="admin-btn admin-btn-primary btn-action-confirm" data-booking-id="${booking.id}">Xác nhận lịch</button>
                    <button type="button" class="admin-btn admin-btn-danger btn-action-cancel" data-booking-id="${booking.id}">Hủy lịch hẹn</button>
                `;
            } else if (booking.status === 'confirmed') {
                actionButtonsContainer.innerHTML = `
                    <button type="button" class="admin-btn admin-btn-primary btn-action-intake" data-booking-id="${booking.id}">Tiếp nhận bé</button>
                    <button type="button" class="admin-btn admin-btn-secondary btn-action-change" data-booking-id="${booking.id}">Đổi KTV</button>
                    <button type="button" class="admin-btn admin-btn-danger btn-action-cancel" data-booking-id="${booking.id}">Hủy lịch</button>
                `;
            } else if (booking.status === 'in_progress') {
                actionButtonsContainer.innerHTML = `
                    <button type="button" class="admin-btn admin-btn-primary btn-action-complete" data-booking-id="${booking.id}">Hoàn thành dịch vụ</button>
                    <button type="button" class="admin-btn admin-btn-secondary btn-action-change" data-booking-id="${booking.id}">Đổi KTV</button>
                    <button type="button" class="admin-btn admin-btn-secondary btn-action-complaint" data-booking-id="${booking.id}">Tạo khiếu nại</button>
                `;
            } else if (booking.status === 'completed') {
                actionButtonsContainer.innerHTML = `
                    <button type="button" class="admin-btn admin-btn-secondary btn-action-complaint" data-booking-id="${booking.id}">Tạo khiếu nại</button>
                `;
            }

            const btnConfirm = actionButtonsContainer.querySelector('.btn-action-confirm');
            const btnIntake = actionButtonsContainer.querySelector('.btn-action-intake');
            const btnComplete = actionButtonsContainer.querySelector('.btn-action-complete');
            const btnCancel = actionButtonsContainer.querySelector('.btn-action-cancel');
            const btnChange = actionButtonsContainer.querySelector('.btn-action-change');
            const btnComplaint = actionButtonsContainer.querySelector('.btn-action-complaint');

            if (btnConfirm) {
                btnConfirm.addEventListener('click', () => {
                    const confirmAction = async () => {
                        if (PawpalServices.subtabs.bookings?.updateBookingStatus) {
                            await PawpalServices.subtabs.bookings.updateBookingStatus(booking.id, 'confirmed');
                        }
                        renderBookingDetail(booking.id);
                    };

                    if (typeof PawpalServices.showConfirmModal === 'function') {
                        PawpalServices.showConfirmModal({
                            title: 'Xác nhận lịch hẹn dịch vụ',
                            message: `Bạn có chắc chắn muốn xác nhận tiếp nhận lịch hẹn ${booking.id} của bé ${booking.petName || 'cưng'} không?`,
                            acceptText: 'Xác nhận lịch',
                            onAccept: confirmAction
                        });
                    } else {
                        confirmAction();
                    }
                });
            }
            if (btnIntake) {
                btnIntake.addEventListener('click', () => {
                    if (PawpalServices.subtabs.bookings?.openIntakeModal) {
                        PawpalServices.subtabs.bookings.openIntakeModal(booking.id, 'intake');
                    }
                });
            }
            if (btnComplete) {
                btnComplete.addEventListener('click', () => {
                    if (PawpalServices.subtabs.bookings?.openCompleteBookingModal) {
                        PawpalServices.subtabs.bookings.openCompleteBookingModal(booking.id);
                    }
                });
            }
            if (btnCancel) {
                btnCancel.addEventListener('click', () => {
                    if (PawpalServices.subtabs.bookings?.openCancelModal) {
                        PawpalServices.subtabs.bookings.openCancelModal(booking.id);
                    }
                });
            }
            if (btnChange) {
                btnChange.addEventListener('click', () => {
                    if (PawpalServices.subtabs.bookings?.openChangeStaffModal) {
                        PawpalServices.subtabs.bookings.openChangeStaffModal(booking.id);
                    }
                });
            }
            if (btnComplaint) {
                btnComplaint.addEventListener('click', () => {
                    sessionStorage.setItem('pawpal_admin_complaint_from_booking', booking.id);
                    sessionStorage.setItem('pawpal_admin_active_module', 'Khiếu nại');
                    sessionStorage.setItem('pawpal_admin_complaint_active_subtab', 'tab-complaint-services');
                    window.location.hash = '#tab-complaint-services';
                    const complaintBtn = Array.from(document.querySelectorAll('.sidebar-menu-btn')).find(b => b.getAttribute('data-title') === 'Khiếu nại');
                    if (complaintBtn) {
                        complaintBtn.click();
                    } else if (window.PawpalAdmin?.loadModule) {
                        window.PawpalAdmin.loadModule('Khiếu nại');
                    }
                });
            }
        }

        // Gắn nút đổi KTV cạnh dòng thông tin KTV
        const btnQuickChangeStaff = document.getElementById('btnDetailQuickChangeStaff');
        if (btnQuickChangeStaff) {
            btnQuickChangeStaff.disabled = !['pending', 'confirmed', 'in_progress'].includes(booking.status);
            btnQuickChangeStaff.onclick = () => {
                if (PawpalServices.subtabs.bookings?.openChangeStaffModal) {
                    PawpalServices.subtabs.bookings.openChangeStaffModal(booking.id);
                }
            };
        }

        // Cập nhật thông tin dịch vụ
        const statusText = document.getElementById('detailBookingStatusText');
        const staffText = document.getElementById('detailBookingStaffText');
        const serviceText = document.getElementById('detailBookingServiceText');
        const durationText = document.getElementById('detailBookingDurationText');
        const categoryText = document.getElementById('detailBookingCategoryText');
        const addonsText = document.getElementById('detailBookingAddonsText');
        const customerNote = document.getElementById('detailBookingCustomerNote');

        if (statusText) statusText.innerHTML = getStatusBadge(booking.status);
        if (staffText) staffText.textContent = booking.staff || 'Chưa phân công';
        if (serviceText) serviceText.textContent = booking.serviceName;
        if (durationText) durationText.textContent = booking.duration;
        if (categoryText) categoryText.textContent = booking.categoryName;
        if (addonsText) addonsText.textContent = booking.addonPrice > 0 ? `Gói chăm sóc mở rộng (${formatCurrency(booking.addonPrice)})` : 'Không có';
        if (customerNote) customerNote.textContent = booking.customerNote || 'Không có';

        // Cập nhật Khối đặc thù theo loại dịch vụ (Hotel / Taxi / Spa)
        const specialFieldsContainer = document.getElementById('detailSpecialServiceFields');
        if (specialFieldsContainer) {
            if (booking.category === 'Hotel') {
                specialFieldsContainer.innerHTML = `
                    <div style="font-size: 13px; font-weight: 700; color: #236B48; margin-bottom: 8px;">Thông tin lưu trú Khách sạn thú cưng (Pet Hotel):</div>
                    <div class="info-grid-2col">
                        <div class="info-pair">
                            <span class="info-label">Thời gian lưu trú:</span>
                    <span class="info-value" style="font-weight: 600; color: #236B48;">${booking.checkInDate || booking.date} (${booking.checkInTime || '08:00'}) ➔ ${booking.checkOutDate || 'Chưa cập nhật'} (${booking.checkOutTime || 'Chưa cập nhật'})</span>
                        </div>
                        <div class="info-pair">
                            <span class="info-label">Tổng thời lượng:</span>
                            <span class="info-value"><span class="admin-badge badge-warning">${booking.nights || 3} đêm lưu trú</span></span>
                        </div>
                        <div class="info-pair">
                            <span class="info-label">Loại phòng và Chuồng:</span>
                            <span class="info-value" style="font-weight: 600;">${booking.roomType || 'Phòng Deluxe (Máy lạnh 24/7)'} (Mã: ${booking.roomCode || 'DLX-04'})</span>
                        </div>
                        <div class="info-pair">
                            <span class="info-label">Camera phòng 24/7:</span>
                            <span class="info-value" style="color: #0369A1; font-weight: 600;">${booking.cameraCode || 'CAM-HOTEL-04'} (Trực tuyến)</span>
                        </div>
                        <div class="info-pair" style="grid-column: span 2;">
                            <span class="info-label">Khẩu phần dinh dưỡng:</span>
                            <span class="info-value" style="font-weight: 500;">${booking.dietPlan || 'Pate tươi dinh dưỡng + Thịt bò luộc (2 bữa/ngày)'}</span>
                        </div>
                    </div>
                `;
            } else if (booking.category === 'Taxi') {
                const shortPickup = booking.pickupAddress || 'Chưa cập nhật';
                const shortDropoff = booking.dropoffAddress || 'Chưa cập nhật';
                specialFieldsContainer.innerHTML = `
                    <div style="font-size: 13px; font-weight: 700; color: #236B48; margin-bottom: 8px;">Thông tin điều phối Pet Taxi đưa đón:</div>
                    <div class="info-grid-2col">
                        <div class="info-pair" style="grid-column: span 2;">
                            <span class="info-label">Lộ trình đưa đón:</span>
                            <span class="info-value" style="font-weight: 600; color: #236B48;">${escapeTripText(shortPickup)} ➔ ${escapeTripText(shortDropoff)}</span>
                        </div>
                        <div class="info-pair">
                            <span class="info-label">Hình thức chuyến:</span>
                            <span class="info-value" style="font-weight: 600;">${escapeTripText(booking.tripType || 'Chưa cập nhật')}</span>
                        </div>
                        <div class="info-pair">
                            <span class="info-label">Cự ly ước tính:</span>
                            <span class="info-value" style="font-weight: 600;">${booking.distanceKm ? `${booking.distanceKm} km` : 'Chưa cập nhật'}</span>
                        </div>
                    </div>
                `;
            } else {
                specialFieldsContainer.innerHTML = '';
            }
        }

        // Cập nhật Thông tin khách hàng & thú cưng
        const custNameEl = document.getElementById('detailCustomerName');
        const custPhoneEl = document.getElementById('detailCustomerPhone');
        const petNameEl = document.getElementById('detailPetName');
        const petBreedEl = document.getElementById('detailPetBreed');
        const petWeightEl = document.getElementById('detailPetWeight');
        const petAllergyEl = document.getElementById('detailPetAllergy');

        if (custNameEl) custNameEl.textContent = booking.customerName;
        if (custPhoneEl) custPhoneEl.textContent = booking.phone;
        if (petNameEl) petNameEl.textContent = booking.petName;
        if (petBreedEl) petBreedEl.textContent = booking.petBreed || 'Chó';
        if (petWeightEl) petWeightEl.textContent = booking.petWeight || '5.0 kg';
        if (petAllergyEl) petAllergyEl.textContent = booking.petAlert || 'Không có';

        // Gắn link nhảy sang Khách hàng và Thú cưng
        const jumpCustBtn = document.getElementById('btnDetailJumpCustomer');
        if (jumpCustBtn) {
            jumpCustBtn.onclick = () => {
                sessionStorage.setItem('pawpal_admin_customer_id', booking.userId || 'CUST-001');
                sessionStorage.setItem('pawpal_admin_customer_subtab', 'tab-profile');
                window.location.hash = '#tab-profile';
                const custNav = document.querySelector('.admin-nav-item[data-module="Khách hàng"]');
                if (custNav) custNav.click();
            };
        }

        const jumpPetBtn = document.getElementById('btnDetailJumpPet');
        if (jumpPetBtn) {
            jumpPetBtn.onclick = () => {
                sessionStorage.setItem('pawpal_admin_pet_id', booking.petId || 'PET-001');
                sessionStorage.setItem('pawpal_admin_pet_name', booking.petName);
                sessionStorage.setItem('pawpal_admin_pet_subtab', 'tab-pet-profile');
                window.location.hash = '#tab-pet-profile';
                const petNav = document.querySelector('.admin-nav-item[data-module="Thú cưng"]');
                if (petNav) petNav.click();
            };
        }

        // Cập nhật Khối 2B: Biên bản tiếp nhận an toàn (Zero-Claim)
        const intakeEmptyNotice = document.getElementById('detailIntakeEmptyNotice');
        const intakeContentBox = document.getElementById('detailIntakeContentContainer');
        const btnEditIntake = document.getElementById('btnEditIntakeSafety');

        if (!booking.intakeRecord) {
            if (intakeEmptyNotice) intakeEmptyNotice.style.display = 'block';
            if (intakeContentBox) intakeContentBox.style.display = 'none';
        } else {
            if (intakeEmptyNotice) intakeEmptyNotice.style.display = 'none';
            if (intakeContentBox) intakeContentBox.style.display = 'block';

            const intake = booking.intakeRecord || {};
            const actualWeight = intake.actualWeight || parseFloat(booking.petWeight) || 4.2;
            const origWeight = parseFloat(booking.originalWeight || 4.2);
            const diffWeight = Math.round((actualWeight - origWeight) * 10) / 10;

            const actualWeightEl = document.getElementById('detailIntakeActualWeight');
            const evalWeightEl = document.getElementById('detailIntakeWeightEval');
            const skinCoatEl = document.getElementById('detailIntakeSkinCoat');
            const eyesEarsEl = document.getElementById('detailIntakeEyesEarsNose');
            const woundsEl = document.getElementById('detailIntakeWounds');
            const temperamentEl = document.getElementById('detailIntakeTemperament');
            const staffIntakeEl = document.getElementById('detailIntakeStaff');
            const belongingsEl = document.getElementById('detailIntakeBelongings');

            if (actualWeightEl) actualWeightEl.textContent = `${actualWeight} kg`;
            if (evalWeightEl) {
                if (diffWeight >= 0.5) {
                    evalWeightEl.innerHTML = `<span style="color: #D97706; font-weight: 600;">Vượt ${diffWeight} kg (+50k phụ phí)</span>`;
                } else if (diffWeight <= -0.5) {
                    evalWeightEl.innerHTML = `<span style="color: #2563EB;">Nhẹ hơn ${Math.abs(diffWeight)} kg so với đăng ký</span>`;
                } else {
                    evalWeightEl.innerHTML = `<span style="color: #16A34A; font-weight: 600;">Đúng khung giá đăng ký</span>`;
                }
            }
            if (skinCoatEl) skinCoatEl.textContent = intake.skinCoat || 'Sạch sẽ, không ve rận';
            if (eyesEarsEl) eyesEarsEl.textContent = intake.eyesEars || 'Bình thường';
            if (woundsEl) woundsEl.textContent = intake.wounds || 'Không có vết thương cũ';
            if (temperamentEl) temperamentEl.textContent = intake.temperament || 'Ngoan hiền';
            if (staffIntakeEl) staffIntakeEl.textContent = `${booking.staff || 'Ngọc Anh'} (Tiếp nhận tại quầy)`;

            const bNote = intake.belongingsNote || '';
            const bItems = Array.isArray(intake.belongings) && intake.belongings.length > 0 ? intake.belongings.join(', ') : '';
            if (belongingsEl) belongingsEl.textContent = bNote || bItems || 'Không có';

            // Ảnh đối chứng Zero-Claim
            const proofGrid = document.getElementById('detailIntakeProofGrid');
            if (proofGrid) {
                const photos = Array.isArray(intake.proofPhotos) && intake.proofPhotos.length > 0
                    ? intake.proofPhotos
                    : [];
                proofGrid.innerHTML = photos.map(url => `
                    <div class="intake-proof-item" style="display: inline-block; margin-right: 8px;">
                        <img src="${url}" alt="Ảnh đối chứng" style="width: 60px; height: 60px; object-fit: cover; border-radius: var(--admin-radius); border: 1px solid var(--border-neutral); cursor: pointer;">
                    </div>
                `).join('');
                proofGrid.querySelectorAll('img').forEach((img, idx) => {
                    img.addEventListener('click', () => {
                        if (openCarelogPhotoPreview) openCarelogPhotoPreview(img.src, `Ảnh đối chứng tiếp nhận ${idx + 1}`);
                    });
                });
            }
        }

        if (btnEditIntake) {
            btnEditIntake.onclick = () => {
                if (PawpalServices.subtabs.bookings?.openIntakeModal) {
                    PawpalServices.subtabs.bookings.openIntakeModal(booking.id, 'edit');
                }
            };
        }

        const btnPrintIntake = document.getElementById('btnPrintIntakeWaiver');
        if (btnPrintIntake) {
            btnPrintIntake.onclick = () => {
                openIntakeWaiverModal(booking);
            };
        }

        const btnNotifyPickup = document.getElementById('btnNotifyCustomerPickup');
        if (btnNotifyPickup) {
            btnNotifyPickup.onclick = () => {
                openNotifyPickupModal(booking);
            };
        }

        const btnSettleToPos = document.getElementById('btnSettleToPos');
        if (btnSettleToPos) {
            btnSettleToPos.onclick = () => {
                sessionStorage.setItem('pawpal_admin_pos_booking_id', booking.id);
                sessionStorage.setItem('pawpal_admin_pos_customer_id', booking.customerId || '');
                sessionStorage.setItem('pawpal_admin_pos_booking_amount', booking.totalPrice || booking.price || 0);
                PawpalServices.showToast?.('Đang chuyển thông tin ca sang quầy thu ngân POS...', 'info');
                const posBtn = Array.from(document.querySelectorAll('.sidebar-menu-btn')).find(b => b.getAttribute('data-title') === 'Bán hàng');
                if (posBtn) {
                    posBtn.click();
                } else if (window.PawpalAdmin?.loadModule) {
                    window.PawpalAdmin.loadModule('Bán hàng');
                }
            };
        }

        const btnShareCarelog = document.getElementById('btnShareCarelogLink');
        if (btnShareCarelog) {
            btnShareCarelog.onclick = () => {
                const shareUrl = `${window.location.origin}/pages/portal/carelog.html?id=${encodeURIComponent(booking.id)}`;
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(shareUrl).then(() => {
                        PawpalServices.showToast?.('Đã sao chép liên kết nhật ký chăm sóc vào bộ nhớ tạm!');
                    }).catch(() => {
                        prompt('Sao chép liên kết nhật ký chăm sóc:', shareUrl);
                    });
                } else {
                    prompt('Sao chép liên kết nhật ký chăm sóc:', shareUrl);
                }
            };
        }

        // Cập nhật Khối tài chính và Bảng kê chi phí
        renderDetailFinancials(booking);

        // Timeline tiến trình 4 giai đoạn
        renderDetailTimeline(booking);

        // Care-Log nhật ký từng bước dịch vụ
        const logStaff = document.getElementById('newLogStepStaff');
        if (logStaff) {
            const selected = logStaff.value;
            logStaff.replaceChildren(new Option('-- Chọn KTV thực hiện --',''), ...(PawpalServices.state.liveStaffList||[]).map(staff=>new Option(staff.full_name,staff.id)));
            logStaff.value = selected;
        }
        const quickLog = document.getElementById('carelogQuickAddBox');
        if (quickLog) quickLog.style.display = booking.status==='in_progress' ? '' : 'none';
        renderDetailCareLogs(booking);
    }

    function renderDetailFinancials(booking) {
        const formatCurrency = PawpalServices.formatCurrency || (num => `${num.toLocaleString('vi-VN')} đ`);
        const basePrice = Number(booking.price ?? booking.basePrice ?? 0);

        // Dịch vụ đi cùng (Accompanying Services)
        const accompanyingList = booking.accompanyingServices || [];
        const accompanyingTotal = accompanyingList.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
        const accompanyingListEl = document.getElementById('detailAccompanyingServicesList');
        if (accompanyingListEl) {
            accompanyingListEl.innerHTML = accompanyingList.map((item, idx) => `
                <div class="summary-row" style="display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 13px;">
                    <div>
                        <span style="font-weight: 500; color: #236B48;">+ ${escapeTripText(item.name)}</span>
                        ${item.staff ? `<span style="font-size: 11.5px; color: var(--text-muted); margin-left: 6px;">(KTV: ${escapeTripText(item.staff)})</span>` : ''}
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-weight: 600; color: var(--text-main);">${formatCurrency(item.price)}</span>
                        <button type="button" class="btn-del-accompanying" data-idx="${idx}" style="background: none; border: none; color: #DC2626; cursor: pointer; font-size: 12px; padding: 0 4px;" title="Xóa">✕</button>
                    </div>
                </div>
            `).join('');

            accompanyingListEl.querySelectorAll('.btn-del-accompanying').forEach(btn => {
                btn.addEventListener('click', async () => {
                    btn.disabled = true;
                    try { await PawpalServices.saveCharges(booking,(booking.charges||[]).filter(c=>c.id!==accompanyingList[Number(btn.dataset.idx)]?.id)); }
                    catch(err) { PawpalServices.showToast('Không thể xóa dịch vụ: '+err.message,'danger'); btn.disabled=false; }
                });
            });
        }

        // Phụ phí (Surcharges)
        const surcharges = booking.surcharges || [];
        const surchargeTotal = surcharges.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
        const surchargeListEl = document.getElementById('detailSurchargeBreakdownList');
        if (surchargeListEl) {
            surchargeListEl.innerHTML = surcharges.map((s, idx) => `
                <div class="summary-row" style="display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 13px;">
                    <div>
                        <span style="font-weight: 500; color: #D97706;">+ ${escapeTripText(s.name)}</span>
                        ${s.reason ? `<div style="font-size: 11px; color: var(--text-muted);">${escapeTripText(s.reason)}</div>` : ''}
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-weight: 600; color: var(--text-main);">${formatCurrency(s.amount)}</span>
                        <button type="button" class="btn-del-surcharge-item" data-idx="${idx}" style="background: none; border: none; color: #DC2626; cursor: pointer; font-size: 12px; padding: 0 4px;" title="Xóa">✕</button>
                    </div>
                </div>
            `).join('');

            surchargeListEl.querySelectorAll('.btn-del-surcharge-item').forEach(btn => {
                btn.addEventListener('click', async () => {
                    btn.disabled = true;
                    try { await PawpalServices.saveCharges(booking,(booking.charges||[]).filter(c=>c.id!==surcharges[Number(btn.dataset.idx)]?.id)); }
                    catch(err) { PawpalServices.showToast('Không thể xóa phụ phí: '+err.message,'danger'); btn.disabled=false; }
                });
            });
        }

        const voucherDiscount = 0;
        const total = basePrice + accompanyingTotal + surchargeTotal - voucherDiscount;
        booking.total = total;

        const baseEl = document.getElementById('detailCostBase') || document.getElementById('detailPriceBase');
        const discEl = document.getElementById('detailCostDiscount') || document.getElementById('detailPriceVoucher');
        const totalEl = document.getElementById('detailCostTotal') || document.getElementById('detailPriceTotal');
        const payStatusEl = document.getElementById('detailPaymentStatus');

        if (baseEl) baseEl.textContent = formatCurrency(basePrice);
        if (discEl) discEl.textContent = voucherDiscount > 0 ? `-${formatCurrency(voucherDiscount)}` : '-0 đ';
        if (totalEl) totalEl.textContent = formatCurrency(total);
        if (payStatusEl) payStatusEl.textContent = booking.paymentStatus || 'Chưa thanh toán (Thanh toán tại quầy)';
    }

    function renderDetailTimeline(booking) {
        const timelineContainer = document.getElementById('detailTimelineContainer');
        if (!timelineContainer) return;

        const timelineData = booking.timeline || [];

        timelineContainer.innerHTML = timelineData.map((step, idx) => `
            <div class="timeline-step-item ${step.done ? 'step-done' : ''}">
                <div class="step-marker">${step.done ? '✓' : (idx + 1)}</div>
                <div class="step-info">
                    <div class="step-title">${step.title} <span class="step-time">${step.time || ''}</span></div>
                    <div class="step-desc">${step.desc || ''}</div>
                </div>
            </div>
        `).join('');
    }

    let editCarelogPhotosTemp = [];

    // Mở Modal 6A: Xem ảnh phóng to (Lightbox)
    function openCarelogPhotoPreview(imgUrl, caption = '') {
        const modal = document.getElementById('modalCarelogPhotoPreview');
        const img = document.getElementById('previewPhotoModalImg');
        const captionEl = document.getElementById('previewPhotoModalCaption');
        if (!modal || !img) return;
        img.src = imgUrl;
        if (captionEl) captionEl.textContent = caption || 'Ảnh quy trình chăm sóc thực tế tại PawPal';
        modal.classList.add('active');
    }

    // Mở Modal 6B: Chỉnh sửa bước quy trình chăm sóc
    function openEditCarelogStepModal(stepIdx) {
        const bookingId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
        const bookingsData = PawpalServices.state?.bookingsData || [];
        const booking = bookingsData.find(b => b.id === bookingId || b.dbId === bookingId);
        if (!booking) return;

        const modal = document.getElementById('modalEditCarelogStep');
        if (!modal) return;

        const logs = booking.carelogs || booking.careLogs || [];
        const step = logs[stepIdx];
        if (!step) return;

        const metaEl = document.getElementById('editCarelogModalMeta');
        if (metaEl) metaEl.textContent = `Mã ca: ${booking.id} • Bé: ${booking.petName || 'Bé cưng'}`;

        const idxHidden = document.getElementById('editCarelogStepIndexHidden');
        if (idxHidden) idxHidden.value = stepIdx;

        const titleInp = document.getElementById('editCarelogStepTitle');
        if (titleInp) titleInp.value = step.step_name || '';

        const staffSelect = document.getElementById('editCarelogStepStaff');
        if (staffSelect) {
            const staffList = PawpalServices.state?.liveStaffList || [];
            if (staffList.length > 0 && staffSelect.options.length <= 1) {
                staffList.forEach(s => {
                    const opt = document.createElement('option');
                    opt.value = s.full_name;
                    opt.textContent = s.full_name;
                    staffSelect.appendChild(opt);
                });
            }
            staffSelect.value = step.ktv || booking.staff || '';
        }

        const timeInp = document.getElementById('editCarelogStepTime');
        if (timeInp) {
            timeInp.value = step.recorded_at ? new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Bangkok',hour:'2-digit',minute:'2-digit'}).format(new Date(step.recorded_at)) : (new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }));
        }

        const descInp = document.getElementById('editCarelogStepDesc');
        if (descInp) descInp.value = step.note || '';

        const doneCheck = document.getElementById('editCarelogStepDone');
        if (doneCheck) { doneCheck.checked = true; doneCheck.disabled = true; }

        editCarelogPhotosTemp = Array.isArray(step.images) ? [...step.images] : [];
        renderEditCarelogPhotosPreview();

        modal.setAttribute('data-step-idx', stepIdx);
        modal.classList.add('active');
    }

    function renderEditCarelogPhotosPreview() {
        const previewContainer = document.getElementById('editCarelogPhotosPreviewList');
        if (!previewContainer) return;
        previewContainer.innerHTML = '';
        editCarelogPhotosTemp.forEach((url, i) => {
            const item = document.createElement('div');
            item.className = 'intake-proof-item';
            item.style.position = 'relative';
            item.innerHTML = `
                <img src="${url}" alt="Ảnh bước" style="width: 60px; height: 60px; object-fit: cover; border-radius: var(--admin-radius); border: 1px solid var(--border-neutral); cursor: pointer;">
                <span class="btn-del-proof" style="position: absolute; top: -5px; right: -5px; background: #DC2626; color: #fff; width: 16px; height: 16px; border-radius: 50%; font-size: 10px; display: flex; align-items: center; justify-content: center; cursor: pointer;">✕</span>
            `;
            item.querySelector('img').addEventListener('click', () => openCarelogPhotoPreview(url, 'Ảnh bước chăm sóc'));
            item.querySelector('.btn-del-proof').addEventListener('click', () => {
                editCarelogPhotosTemp.splice(i, 1);
                renderEditCarelogPhotosPreview();
            });
            previewContainer.appendChild(item);
        });
    }

    function renderDetailCareLogs(booking) {
        const carelogsContainer = document.getElementById('detailCarelogList') || document.getElementById('detailCareLogsContainer');
        if (!carelogsContainer) return;

        if (!booking._careLogsLoaded && PawpalServices.fetchBookingCareLogs && booking.dbId) {
            carelogsContainer.innerHTML = '<div style="color:var(--text-muted);padding:12px 0;">Đang nạp nhật ký chăm sóc…</div>';
            PawpalServices.fetchBookingCareLogs(booking.dbId).then(logs => {
                booking.careLogs = logs;
                booking.carelogs = logs;
                booking._careLogsLoaded = true;
                if (PawpalServices.state?.selectedBookingId === booking.id) {
                    renderDetailCareLogs(booking);
                }
            }).catch(err => {
                console.warn('[PawpalServices] Lỗi nạp nhật ký ca:', err);
                booking._careLogsLoaded = true;
                renderDetailCareLogs(booking);
            });
            return;
        }

        let logs = booking.carelogs || booking.careLogs || [];
        if (!logs.length) {
            carelogsContainer.innerHTML = '<div style="color:var(--text-muted);padding:12px 0;">Chưa có nhật ký chăm sóc cho ca dịch vụ này.</div>';
            return;
        }

        carelogsContainer.innerHTML = logs.map((log, idx) => `
            <div class="carelog-step-card" data-step-idx="${idx}" style="cursor: pointer; padding: 10px 12px; background: #fff; border: 1px solid var(--border-neutral); border-radius: var(--admin-radius); margin-bottom: 8px;">
                <div class="carelog-step-header" style="display: flex; justify-content: space-between; align-items: center;">
                    <div class="carelog-step-title" style="font-weight: 600; color: #236B48; font-size: 13px;">
                        <span class="step-number">${idx + 1}.</span> ${escapeTripText(log.step_name || log.description || 'Bước thực hiện')}
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span class="admin-badge ${log.completed ? 'badge-success' : 'badge-neutral'}">Đã ghi</span>
                        <span style="font-size: 11.5px; color: #236B48; font-weight: 500;">Sửa</span>
                    </div>
                </div>
                <div class="carelog-step-body" style="margin-top: 4px;">
                    <div class="carelog-meta-row" style="font-size: 11.5px; color: var(--text-muted); display: flex; gap: 12px;">
                        <span>KTV: <strong>${escapeTripText(log.ktv || 'Chưa cập nhật')}</strong></span>
                        <span>Thời gian: ${log.recorded_at ? new Intl.DateTimeFormat('vi-VN',{timeZone:'Asia/Bangkok',hour:'2-digit',minute:'2-digit'}).format(new Date(log.recorded_at)) : '—'}</span>
                    </div>
                    ${log.note ? `<div style="font-size: 12px; color: var(--text-main); margin-top: 4px;">${escapeTripText(log.note)}</div>` : ''}
                    ${(log.images && log.images.length > 0) ? `
                        <div class="carelog-step-images" style="display: flex; gap: 6px; margin-top: 6px;">
                            ${log.images.map(img => `
                                <img src="${img}" alt="Ảnh bước" class="carelog-thumb-clickable" data-img-src="${img}" style="width: 48px; height: 48px; object-fit: cover; border-radius: var(--admin-radius); border: 1px solid var(--border-neutral); cursor: pointer;">
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
            </div>
        `).join('');

        // Gắn sự kiện nhấp vào ảnh thumbnail để mở Modal 6A (Lightbox)
        carelogsContainer.querySelectorAll('.carelog-thumb-clickable').forEach(img => {
            img.addEventListener('click', (e) => {
                e.stopPropagation();
                const src = img.getAttribute('data-img-src');
                openCarelogPhotoPreview(src, 'Ảnh quy trình chăm sóc thực tế tại tiệm');
            });
        });

        // Gắn sự kiện nhấp vào thẻ bước để mở Modal 6B (Chỉnh sửa bước)
        carelogsContainer.querySelectorAll('.carelog-step-card').forEach(card => {
            card.addEventListener('click', () => {
                const stepIdx = parseInt(card.getAttribute('data-step-idx'), 10);
                if (!isNaN(stepIdx)) {
                    openEditCarelogStepModal(stepIdx);
                }
            });
        });
    }

    function initDetailSubtab() {
        document.getElementById('btnTriggerCarelogImageUpload')?.addEventListener('click', () => PawpalServices.showToast('Chưa cấu hình kho ảnh Supabase; chưa thể lưu ảnh nhật ký.','warning'));
        const logButton = document.getElementById('btnSubmitCarelogStep');
        if (logButton) logButton.addEventListener('click', async () => {
            if (logButton.disabled) return;
            const booking = (PawpalServices.state.bookingsData||[]).find(b=>b.id===PawpalServices.state.selectedBookingId);
            const title = document.getElementById('newLogStepTitle').value.trim();
            const note = document.getElementById('newLogStepNote').value.trim();
            const staffId = document.getElementById('newLogStepStaff').value;
            const staff = (PawpalServices.state.liveStaffList||[]).find(s=>s.id===staffId);
            if (!title || !staff) { PawpalServices.showToast('Vui lòng nhập tên bước và chọn nhân viên thực hiện.','warning'); return; }
            if (!booking || booking.status!=='in_progress') { PawpalServices.showToast('Chỉ ghi nhật ký khi ca đang thực hiện.','warning'); return; }
            logButton.disabled=true;
            try {
                if (document.getElementById('carelogImageFileInput').files.length) throw new Error('Ảnh nhật ký chưa được tải lên máy chủ; vui lòng bỏ ảnh trước khi lưu.');
                const db = window.getSupabaseClient();
                const {data:actions,error:readError} = await db.from('care_action').select('*').eq('service_category',booking.serviceCategory).eq('action_name',title).eq('is_active',true);
                if(readError) throw readError;
                if(actions.length>1) throw new Error('Có nhiều mốc chăm sóc trùng tên, cần rà soát danh mục.');
                let action = actions[0];
                if(!action) {
                    const {data,error} = await db.from('care_action').insert({action_name:title,service_category:booking.serviceCategory,display_order:0,estimated_duration:0,is_active:true}).select('id').single();
                    if(error) throw error;
                    action=data;
                }
                const {data,error} = await db.from('care_log').insert({appointment_id:booking.dbId,pet_id:booking.petDbId,care_action_id:action.id,description:[note,`Nhân viên: ${staff.full_name} (${staff.id})`].filter(Boolean).join('\n'),recorded_at:new Date().toISOString()}).select('id,appointment_id,pet_id').single();
                if(error) throw error;
                if(!data?.id || data.appointment_id!==booking.dbId || data.pet_id!==booking.petDbId) throw new Error('Không xác minh được nhật ký đã lưu.');
                await PawpalServices.loadServicesData({force:true});
                renderBookingDetail(booking.id);
                document.getElementById('newLogStepTitle').value='';
                document.getElementById('newLogStepNote').value='';
                PawpalServices.showToast('Đã lưu nhật ký chăm sóc.');
            } catch(err) { PawpalServices.showToast('Không thể ghi nhật ký: '+err.message,'danger'); }
            finally { logButton.disabled=false; }
        });
        const initialBookingId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
        renderBookingDetail(initialBookingId);

        // Nút mở Modal 5 (Thêm phụ phí)
        const btnAddSurcharge = document.getElementById('btnOpenAddSurchargeModal');
        if (btnAddSurcharge) {
            btnAddSurcharge.addEventListener('click', () => {
                const bId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
                if (PawpalServices.subtabs?.bookings?.openSurchargeModal) {
                    PawpalServices.subtabs.bookings.openSurchargeModal(bId);
                } else {
                    const modal = document.getElementById('modalAddSurcharge');
                    if (modal) modal.classList.add('active');
                }
            });
        }

        // ====================================================================
        // MODAL 6B: LẮNG NGHE SỰ KIỆN CHỈNH SỬA BƯỚC QUY TRÌNH CHĂM SÓC
        // ====================================================================
        const btnSubmitEditCarelog = document.getElementById('btnSubmitEditCarelogStep');
        if (btnSubmitEditCarelog) {
            btnSubmitEditCarelog.addEventListener('click', async () => {
                const modal = document.getElementById('modalEditCarelogStep');
                const stepIdx = parseInt(document.getElementById('editCarelogStepIndexHidden')?.value, 10);
                const title = document.getElementById('editCarelogStepTitle')?.value.trim();
                const staff = document.getElementById('editCarelogStepStaff')?.value;
                const time = document.getElementById('editCarelogStepTime')?.value.trim();
                const desc = document.getElementById('editCarelogStepDesc')?.value.trim();
                const done = document.getElementById('editCarelogStepDone')?.checked;

                if (!title) {
                    PawpalServices.showToast('Vui lòng nhập tên bước chăm sóc!', 'warning');
                    document.getElementById('editCarelogStepTitle')?.focus();
                    return;
                }

                const bookingId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
                const bookingsData = PawpalServices.state?.bookingsData || [];
                const booking = bookingsData.find(b => b.id === bookingId || b.dbId === bookingId);
                if (booking && !isNaN(stepIdx)) {
                    const logs = booking.carelogs || booking.careLogs || [];
                    const step = logs[stepIdx];
                    if (!step?.id || btnSubmitEditCarelog.disabled) return;
                    btnSubmitEditCarelog.disabled = true;
                    try {
                        const db = window.getSupabaseClient();
                        const performers = (PawpalServices.state.liveStaffList||[]).filter(s=>s.full_name===staff);
                        if (performers.length!==1 || !time) throw new Error('Vui lòng chọn đúng một nhân viên và giờ ghi nhận.');
                        if (editCarelogPhotosTemp.some(url=>url.startsWith('blob:'))) throw new Error('Chưa cấu hình kho ảnh; ảnh tạm chưa được lưu.');
                        if (editCarelogPhotosTemp.length !== (step.images||[]).length) throw new Error('Thay đổi ảnh cần hoàn thiện kho ảnh trước.');
                        const {data:actions,error:actionError}=await db.from('care_action').select('id').eq('service_category',booking.serviceCategory).eq('action_name',title).eq('is_active',true);
                        if(actionError) throw actionError;
                        if(actions.length>1) throw new Error('Mốc chăm sóc trùng tên, vui lòng rà soát danh mục.');
                        let action=actions[0];
                        if(!action) {
                            const {data,error}=await db.from('care_action').insert({action_name:title,service_category:booking.serviceCategory,display_order:0,estimated_duration:0,is_active:true}).select('id').single();
                            if(error) throw error;
                            action=data;
                        }
                        const day = new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(step.recorded_at));
                        const recordedAt = new Date(`${day}T${time}:00+07:00`).toISOString();
                        let query=db.from('care_log').update({care_action_id:action.id,description:[desc,`Nhân viên: ${staff} (${performers[0].id})`].filter(Boolean).join('\n'),recorded_at:recordedAt}).eq('id',step.id).eq('appointment_id',booking.dbId);
                        if(step.updated_at) query=query.eq('updated_at',step.updated_at);
                        const {data,error}=await query.select('id,care_action_id,recorded_at').single();
                        if(error) throw error;
                        if(!data?.id || data.care_action_id!==action.id || Date.parse(data.recorded_at)!==Date.parse(recordedAt)) throw new Error('Không xác minh được nhật ký đã cập nhật.');
                        await PawpalServices.loadServicesData({force:true});
                        renderBookingDetail(booking.id);
                        PawpalServices.showToast('Đã lưu thay đổi nhật ký chăm sóc.');
                    } catch(err) { PawpalServices.showToast('Không thể sửa nhật ký: '+err.message,'danger'); return; }
                    finally { btnSubmitEditCarelog.disabled=false; }
                    if (modal) modal.classList.remove('active');
                }
            });
        }

        // Nút Xóa bước chăm sóc
        const btnDeleteCarelog = document.getElementById('btnDeleteCarelogStep');
        if (btnDeleteCarelog) {
            btnDeleteCarelog.addEventListener('click', async () => {
                const modal = document.getElementById('modalEditCarelogStep');
                const stepIdx = parseInt(document.getElementById('editCarelogStepIndexHidden')?.value, 10);
                const bookingId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
                const bookingsData = PawpalServices.state?.bookingsData || [];
                const booking = bookingsData.find(b => b.id === bookingId || b.dbId === bookingId);
                if (booking && !isNaN(stepIdx)) {
                    const logs = booking.carelogs || booking.careLogs || [];
                    const step=logs[stepIdx];
                    if(!step?.id || btnDeleteCarelog.disabled) return;
                    if(!window.confirm('Xóa vĩnh viễn nhật ký này? Thao tác không thể hoàn tác.')) return;
                    btnDeleteCarelog.disabled=true;
                    try {
                        const db=window.getSupabaseClient();
                        if(step.care_log_media?.length) throw new Error('Nhật ký có media; cần xử lý media trước khi xóa.');
                        let query=db.from('care_log').delete().eq('id',step.id).eq('appointment_id',booking.dbId);
                        if(step.updated_at) query=query.eq('updated_at',step.updated_at);
                        const {data,error}=await query.select('id').single();
                        if(error) throw error;
                        if(data?.id!==step.id) throw new Error('Không xác minh được nhật ký đã xóa.');
                        await PawpalServices.loadServicesData({force:true});
                        renderBookingDetail(booking.id);
                        PawpalServices.showToast('Đã xóa nhật ký chăm sóc.');
                    } catch(err) { PawpalServices.showToast('Không thể xóa nhật ký: '+err.message,'danger'); return; }
                    finally { btnDeleteCarelog.disabled=false; }
                    if (modal) modal.classList.remove('active');
                }
            });
        }

        // Nút thêm ảnh vào bước
        const btnAddPhoto = document.getElementById('btnEditCarelogAddPhoto');
        const photoFileInp = document.getElementById('editCarelogFileInput');
        if (btnAddPhoto && photoFileInp) {
            btnAddPhoto.addEventListener('click', () => PawpalServices.showToast('Chưa cấu hình kho ảnh Supabase; chưa thể lưu ảnh nhật ký.','warning'));
            photoFileInp.addEventListener('change', (e) => {
                const files = Array.from(e.target.files || []);
                files.forEach(file => {
                    const url = URL.createObjectURL(file);
                    editCarelogPhotosTemp.push(url);
                });
                renderEditCarelogPhotosPreview();
            });
        }

        // ====================================================================
        // MODAL 7: THÊM DỊCH VỤ ĐI CÙNG VÀO CA
        // ====================================================================
        const btnOpenAccompanyingModal = document.getElementById('btnOpenAddAccompanyingServiceModal');
        const modalAccompanying = document.getElementById('modalAddAccompanyingService');
        const accompanyingCategorySelect = document.getElementById('accompanyingCategorySelect');
        const accompanyingItemSelect = document.getElementById('accompanyingServiceItemSelect');
        const accompanyingPriceInput = document.getElementById('accompanyingPriceInput');
        const accompanyingStaffSelect = document.getElementById('accompanyingStaffSelect');
        const accompanyingNoteInput = document.getElementById('accompanyingNoteInput');
        const btnSubmitAccompanying = document.getElementById('btnSubmitAddAccompanying');

        function updateAccompanyingServiceItems() {
            if (!accompanyingItemSelect) return;
            const cat = accompanyingCategorySelect ? accompanyingCategorySelect.value : 'ALL';
            const filtered = (PawpalServices.state.servicesData || []).filter(item => item.status === 'Đang phục vụ' && (cat === 'ALL' || item.group === cat)).map(item=>({ name:item.name, price: '', id:item.dbId }));

            accompanyingItemSelect.innerHTML = '<option value="">-- Chọn gói dịch vụ đi cùng --</option>' + 
                filtered.map(item => `
                    <option value="${escapeTripText(item.name)}" data-price="${item.price}">${escapeTripText(item.name)}</option>
                `).join('');

            if (accompanyingPriceInput) accompanyingPriceInput.value = '';
        }

        if (btnOpenAccompanyingModal && modalAccompanying) {
            btnOpenAccompanyingModal.addEventListener('click', () => {
                if (accompanyingCategorySelect) accompanyingCategorySelect.value = 'ALL';
                updateAccompanyingServiceItems();

                // Nạp KTV
                if (accompanyingStaffSelect) {
                    const staffList = PawpalServices.state?.liveStaffList || [];
                    accompanyingStaffSelect.innerHTML = '<option value="">-- Chọn KTV thực hiện --</option>' + 
                        staffList.map(s => `<option value="${s.full_name}">${s.full_name}</option>`).join('');
                }

                if (accompanyingPriceInput) accompanyingPriceInput.value = '';
                if (accompanyingNoteInput) accompanyingNoteInput.value = '';

                modalAccompanying.classList.add('active');
            });
        }

        if (accompanyingCategorySelect) {
            accompanyingCategorySelect.addEventListener('change', updateAccompanyingServiceItems);
        }

        if (accompanyingItemSelect) {
            accompanyingItemSelect.addEventListener('change', () => {
                const selectedOpt = accompanyingItemSelect.options[accompanyingItemSelect.selectedIndex];
                const price = selectedOpt ? selectedOpt.getAttribute('data-price') : '';
                if (accompanyingPriceInput) {
                    accompanyingPriceInput.value = price || '';
                }
            });
        }

        if (btnSubmitAccompanying) {
            btnSubmitAccompanying.addEventListener('click', async () => {
                const name = accompanyingItemSelect?.value;
                const price = parseFloat(accompanyingPriceInput?.value || 0);
                const staff = accompanyingStaffSelect?.value;
                const note = accompanyingNoteInput?.value.trim();

                if (!name) {
                    PawpalServices.showToast('Vui lòng chọn gói dịch vụ đi cùng!', 'warning');
                    accompanyingItemSelect?.focus();
                    return;
                }
                if (!price || price <= 0) {
                    PawpalServices.showToast('Vui lòng nhập giá dịch vụ hợp lệ!', 'warning');
                    accompanyingPriceInput?.focus();
                    return;
                }

                const bookingId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
                const bookingsData = PawpalServices.state?.bookingsData || [];
                const booking = bookingsData.find(b => b.id === bookingId || b.dbId === bookingId);
                if (booking) {
                    if (btnSubmitAccompanying.disabled) return;
                    btnSubmitAccompanying.disabled = true;
                    try {
                        const services = (PawpalServices.state.servicesData||[]).filter(s=>s.name===name && s.status==='Đang phục vụ');
                        if (services.length!==1) throw new Error('Vui lòng chọn đúng một dịch vụ đang phục vụ.');
                        await PawpalServices.saveCharges(booking,[...(booking.charges||[]),{id:crypto.randomUUID(),kind:'service',name,amount:price,reason:note,staff,serviceId:services[0].dbId}]);
                        PawpalServices.showToast('Đã lưu dịch vụ đi cùng.');
                    } catch(err) { PawpalServices.showToast('Không thể lưu dịch vụ đi cùng: '+err.message,'danger'); return; }
                    finally { btnSubmitAccompanying.disabled=false; }

                    if (modalAccompanying) modalAccompanying.classList.remove('active');
                }
            });
        }

        // Sự kiện mở Modal 12: In phiếu tiếp nhận an toàn
        const btnPrintIntakeStatic = document.getElementById('btnPrintIntakeWaiver');
        if (btnPrintIntakeStatic) {
            btnPrintIntakeStatic.addEventListener('click', () => {
                const bId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
                const bList = PawpalServices.state?.bookingsData || [];
                const b = bList.find(item => item.id === bId || item.dbId === bId) || bList[0];
                openIntakeWaiverModal(b);
            });
        }

        // Sự kiện mở Modal 13: Báo khách đón bé
        const btnNotifyPickupStatic = document.getElementById('btnNotifyCustomerPickup');
        if (btnNotifyPickupStatic) {
            btnNotifyPickupStatic.addEventListener('click', () => {
                const bId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
                const bList = PawpalServices.state?.bookingsData || [];
                const b = bList.find(item => item.id === bId || item.dbId === bId) || bList[0];
                openNotifyPickupModal(b);
            });
        }
    }

    function openIntakeWaiverModal(booking) {
        if (!booking) {
            const currentId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
            const bookingsList = PawpalServices.state?.bookingsData || [];
            booking = bookingsList.find(b => b.id === currentId || b.dbId === currentId) || bookingsList[0];
        }
        if (!booking) return;

        const modal = document.getElementById('modalPrintIntakeWaiver');
        if (!modal) return;

        const formatCurrency = PawpalServices.formatCurrency || (num => `${Number(num).toLocaleString('vi-VN')} đ`);
        const intake = booking.intakeRecord || {};
        const actualWeight = intake.actualWeight || parseFloat(booking.petWeight) || 4.2;
        const basePrice = Number(booking.price ?? booking.basePrice ?? 0);
        const total = booking.total || basePrice;

        // Điền Header phiếu in
        const codeEl = document.getElementById('waiverBookingCode');
        const dateEl = document.getElementById('waiverPrintDate');
        if (codeEl) codeEl.textContent = booking.id || 'BKG-1001';
        if (dateEl) {
            dateEl.textContent = `Ngày ${booking.date || '25/06/2026'} ${booking.time || '14:00'}`;
        }

        // Phần 1: Khách hàng & Thú cưng
        const custNameEl = document.getElementById('waiverCustName');
        const custPhoneEl = document.getElementById('waiverCustPhone');
        const petNameEl = document.getElementById('waiverPetName');
        const petBreedEl = document.getElementById('waiverPetBreed');
        const petWeightEl = document.getElementById('waiverPetWeight');
        const petAgeEl = document.getElementById('waiverPetAge');

        const customerDisplayName = booking.customerName || booking.customer || 'Chủ nuôi';
        const serviceDisplayName = booking.serviceName || booking.service || 'Dịch vụ chăm sóc';
        const staffDisplayName = booking.staff || 'Chưa phân công';

        if (custNameEl) custNameEl.textContent = customerDisplayName;
        if (custPhoneEl) custPhoneEl.textContent = booking.phone || '—';
        if (petNameEl) petNameEl.textContent = booking.petName || 'Bé cưng';
        if (petBreedEl) petBreedEl.textContent = booking.petBreed || 'Thú cưng';
        if (petWeightEl) petWeightEl.textContent = booking.petWeight || booking.originalWeight || 'Chưa cập nhật';
        if (petAgeEl) petAgeEl.textContent = booking.petAge || 'Chưa cập nhật';

        // Phần 2: Ngoại quan tiếp nhận (Zero-Claim)
        const actualWeightEl = document.getElementById('waiverActualWeight');
        const weightEvalEl = document.getElementById('waiverWeightEval');
        const skinCoatEl = document.getElementById('waiverSkinCoat');
        const eyesEarsEl = document.getElementById('waiverEyesEars');
        const woundsEl = document.getElementById('waiverWounds');
        const temperamentEl = document.getElementById('waiverTemperament');
        const belongingsEl = document.getElementById('waiverBelongings');

        if (actualWeightEl) actualWeightEl.textContent = actualWeight ? `${actualWeight} kg` : 'Chưa cân';
        if (weightEvalEl) weightEvalEl.textContent = intake.weightEvaluation || 'Đúng khung giá chuẩn';
        if (skinCoatEl) skinCoatEl.textContent = intake.skinCoat || 'Chưa ghi nhận bất thường';
        if (eyesEarsEl) eyesEarsEl.textContent = intake.eyesEars || 'Bình thường';
        if (woundsEl) woundsEl.textContent = intake.wounds || 'Không có vết thương cũ';
        if (temperamentEl) temperamentEl.textContent = intake.temperament || 'Ngoan hiền';
        
        const bNote = intake.belongingsNote || '';
        const bItems = Array.isArray(intake.belongings) && intake.belongings.length > 0 ? intake.belongings.join(', ') : '';
        if (belongingsEl) belongingsEl.textContent = bNote || bItems || 'Không có tư trang gửi lại';

        // Phần 3: Gói dịch vụ & Chi phí
        const svcNameEl = document.getElementById('waiverServiceName');
        const priceBaseEl = document.getElementById('waiverPriceBase');
        const staffNameEl = document.getElementById('waiverStaffName');
        const durationEl = document.getElementById('waiverDuration');
        const priceTotalEl = document.getElementById('waiverPriceTotal');
        const extraItemsBlock = document.getElementById('waiverExtraItemsBlock');
        const extraItemsText = document.getElementById('waiverExtraItemsText');

        if (svcNameEl) svcNameEl.textContent = serviceDisplayName;
        if (priceBaseEl) priceBaseEl.textContent = formatCurrency(basePrice);
        if (staffNameEl) staffNameEl.textContent = staffDisplayName;
        if (durationEl) durationEl.textContent = booking.duration || '60 phút';
        if (priceTotalEl) priceTotalEl.textContent = formatCurrency(total);

        const accompanying = (booking.accompanyingServices || []).map(s => s.name);
        const surcharges = (booking.surcharges || []).map(s => s.name);
        const allExtras = [...accompanying, ...surcharges];
        if (extraItemsBlock && extraItemsText) {
            if (allExtras.length > 0) {
                extraItemsBlock.style.display = 'block';
                extraItemsText.textContent = allExtras.join(', ');
            } else {
                extraItemsBlock.style.display = 'none';
            }
        }

        // Chữ ký
        const staffSignEl = document.getElementById('waiverStaffSignName');
        const custSignEl = document.getElementById('waiverCustSignName');
        if (staffSignEl) staffSignEl.textContent = staffDisplayName !== 'Chưa phân công' ? `KTV. ${staffDisplayName}` : 'KTV tiếp nhận';
        if (custSignEl) custSignEl.textContent = customerDisplayName;

        // Nút in phiếu
        const btnPrintAction = document.getElementById('btnPrintIntakeWaiverAction');
        if (btnPrintAction) {
            btnPrintAction.onclick = () => {
                window.print();
            };
        }

        modal.classList.add('active');
        modal.style.display = 'flex';
        const card = modal.querySelector('.admin-modal-card');
        if (card) card.scrollTop = 0;
    }

    function openNotifyPickupModal(booking) {
        if (!booking) {
            const currentId = sessionStorage.getItem('pawpal_admin_service_selected_id') || null;
            const bookingsList = PawpalServices.state?.bookingsData || [];
            booking = bookingsList.find(b => b.id === currentId || b.dbId === currentId) || bookingsList[0];
        }
        if (!booking) return;

        const modal = document.getElementById('modalNotifyPickup');
        if (!modal) return;

        const formatCurrency = PawpalServices.formatCurrency || (num => `${Number(num).toLocaleString('vi-VN')} đ`);
        const metaEl = document.getElementById('notifyPickupMeta');
        const svcNameEl = document.getElementById('notifyPickupServiceName');
        const costEl = document.getElementById('notifyPickupTotalCost');
        const staffEl = document.getElementById('notifyPickupStaffName');
        const belongingsEl = document.getElementById('notifyPickupBelongings');
        const textareaEl = document.getElementById('notifyPickupMessageText');

        const custName = booking.customerName || booking.customer || 'Quý khách';
        const custPhone = booking.phone || '';
        const petName = booking.petName || 'Bé cưng';
        const svcName = booking.serviceName || booking.service || 'Dịch vụ chăm sóc';
        const totalCost = formatCurrency(booking.total || booking.price || 0);
        const staffName = booking.staff || 'KTV PawPal';
        const intake = booking.intakeRecord || {};
        const belongingsNote = intake.belongingsNote || (Array.isArray(intake.belongings) && intake.belongings.length > 0 ? intake.belongings.join(', ') : 'Không có tư trang gửi lại');

        if (metaEl) {
            metaEl.textContent = `Mã ca ${booking.id || 'BKG-1001'} • Bé ${petName} • Chủ nuôi ${custName} ${custPhone ? `(${custPhone})` : ''}`;
        }
        if (svcNameEl) svcNameEl.textContent = svcName;
        if (costEl) costEl.textContent = totalCost;
        if (staffEl) staffEl.textContent = staffName;
        if (belongingsEl) belongingsEl.textContent = belongingsNote;

        function generateMessage() {
            return `Dạ PawPal xin chào Anh/Chị ${custName}!
Bé ${petName} đã hoàn thành xong dịch vụ ${svcName} thật thơm tho và xinh đẹp rồi ạ! ✨

• Kỹ thuật viên phụ trách: ${staffName}
• Tổng chi phí ca: ${totalCost}
• Tư trang nhận lại: ${belongingsNote}

PawPal kính mời Anh/Chị ghé tiệm để đón bé về sum vầy cùng gia đình nhé ạ. Cảm ơn Anh/Chị! 🐾`;
        }

        if (textareaEl) {
            textareaEl.value = generateMessage();
        }

        const btnReset = document.getElementById('btnResetNotifyTemplate');
        if (btnReset && textareaEl) {
            btnReset.onclick = () => {
                textareaEl.value = generateMessage();
                PawpalServices.showToast('Đã khôi phục mẫu tin nhắn chuẩn!');
            };
        }

        const btnSend = document.getElementById('btnSendNotifyPickup');
        if (btnSend) {
            btnSend.onclick = async () => {
                btnSend.disabled = true;
                const channel = document.querySelector('input[name="pickupChannel"]:checked')?.value || 'Zalo';
                const messageText = textareaEl?.value || '';

                try {
                    const client = PawpalServices.getSupabaseClient ? PawpalServices.getSupabaseClient() : window.SupabaseClient;
                    if (client) {
                        const { error: notifErr } = await client.from('notification').insert({
                            customer_id: booking.customerId || booking.userId || null,
                            notification_type: 'lich_hen_da_thay_doi',
                            title: `Mời đón bé ${petName} tại Pawpal`,
                            content: messageText,
                            appointment_id: booking.rawId || booking.id || null,
                            related_entity_type: 'appointment',
                            is_read: false,
                            sent_at: new Date().toISOString()
                        });
                        if (notifErr) {
                            console.warn('Lỗi ghi thông báo đón bé vào hệ thống:', notifErr);
                            PawpalServices.showToast('Không thể lưu thông báo đón bé vào hệ thống. Vui lòng thử lại!', 'danger');
                            return;
                        }
                    }
                    PawpalServices.showToast(`Đã lưu thông báo mời đón bé ${petName} vào hệ thống!`, 'success');
                    modal.classList.remove('active');
                    modal.style.display = 'none';
                } catch (e) {
                    console.error('Lỗi gửi thông báo đón bé:', e);
                    PawpalServices.showToast('Không thể gửi thông báo lúc này. Vui lòng liên hệ trực tiếp chủ nuôi.', 'danger');
                } finally {
                    btnSend.disabled = false;
                }
            };
        }

        modal.classList.add('active');
        modal.style.display = 'flex';
        const card = modal.querySelector('.admin-modal-card');
        if (card) card.scrollTop = 0;
    }

    PawpalServices.subtabs.detail = {
        init: initDetailSubtab,
        openBookingDetail,
        renderBookingDetail,
        openIntakeWaiverModal,
        openNotifyPickupModal
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDetailSubtab);
    } else {
        initDetailSubtab();
    }
})();
