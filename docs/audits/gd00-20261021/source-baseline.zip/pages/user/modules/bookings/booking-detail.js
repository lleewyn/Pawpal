
import { API } from '/scripts/api/api.js';
import { statusLabels, formatDate, formatPrice } from './bookings.js';


function mapBookingStatus(status) {
    if (!status) return 'pending';
    const s = String(status).toLowerCase().trim();
    const mapping = {
        'dang_giu_cho':   'pending',
        'cho_xac_nhan':   'pending',
        'da_xac_nhan':    'confirmed',
        'da_check_in':    'confirmed',
        'dang_thuc_hien': 'in-progress',
        'da_hoan_tat':    'completed',
        'da_huy':         'cancelled',
        'da_het_han':     'cancelled',
        'vang_mat':       'cancelled',
        'pending':        'pending',
        'confirmed':      'confirmed',
        'completed':      'completed',
        'cancelled':      'cancelled',
        'no_show':        'cancelled'
    };
    return mapping[s] || 'pending';
}

function getBookingPrice(priceMatrix, petSpecies) {
    if (!priceMatrix?.length) return 0;
    const match = priceMatrix.find(p => p.pet_species === petSpecies);
    return (match || priceMatrix[0])?.unit_price || 0;
}

async function cancelBookingOnSupabase(booking) {
    const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
    if (!db || !booking?._supabaseId) throw new Error('Không xác định được lịch hẹn để hủy.');
    const { error } = await db.from('appointment')
        .update({ appointment_status: 'da_huy' })
        .eq('id', booking._supabaseId);
    if (error) throw error;
    console.log('[BookingDetail] Cancel synced to Supabase');
}

async function rescheduleBookingOnSupabase(booking) {
    const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
    if (!db || !booking?._supabaseId) throw new Error('Không xác định được lịch hẹn để đổi lịch.');
    const serviceCategory = String(booking?.serviceCategory || booking?.category || booking?.service_type || '').toLowerCase();
    const { error } = await db.from('appointment')
        .update({
            appointment_date:   booking.date,
            appointment_time:   serviceCategory === 'hotel' ? null : (booking.timeStart || booking.time) + ':00',
            appointment_status: 'cho_xac_nhan',
            change_count:       booking.changeCount || 0,
        })
        .eq('id', booking._supabaseId);
    if (error) throw error;
    console.log('[BookingDetail] Reschedule synced to Supabase');
}

let currentBooking = null;
let currentPet = null;
let currentCareLog = null;
let bannerTimeout = null;
let currentServiceReviewRating = 0;

function getBookingIdFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    let id = urlParams.get('id') || urlParams.get('bookingId');
    if (id) return id;

    const hash = window.location.hash || '';
    const qIndex = hash.indexOf('?');
    if (qIndex !== -1) {
        const hashParams = new URLSearchParams(hash.substring(qIndex + 1));
        id = hashParams.get('id') || hashParams.get('bookingId');
        if (id) return id;
    }

    return null;
}

function showBookingLoadError(message) {
    const container = document.querySelector('.booking-detail-module-container');
    if (!container) return;
    container.innerHTML = '<div class="text-center py-5" role="status"><p class="text-muted"></p><a href="#bookings">Quay lại danh sách lịch hẹn</a></div>';
    container.querySelector('p').textContent = message;
}

let isInitRunning = false;

export async function init() {
    if (isInitRunning) return;
    isInitRunning = true;
    const loadingContainer = document.querySelector('.booking-detail-module-container');
    try {
        const bookingId = getBookingIdFromUrl();

        if (!bookingId) {
            showBookingLoadError('Không tìm thấy mã lịch hẹn.');
            return;
        }

        await loadBookingDetail(bookingId);
    } catch (error) {
        console.error('[BookingDetail] Không thể tải lịch hẹn:', error);
        showBookingLoadError('Không thể tải chi tiết lịch hẹn. Vui lòng tải lại trang.');
    } finally {
        requestAnimationFrame(() => requestAnimationFrame(() => {
            loadingContainer?.classList.remove('booking-detail-loading');
            loadingContainer?.setAttribute('aria-busy', 'false');
            setTimeout(() => loadingContainer?.querySelector('.booking-detail-skeleton')?.remove(), 260);
        }));
        isInitRunning = false;
    }
}

export const initBookingDetail = init;
window.initBookingDetail = init;

async function loadBookingDetail(bookingId) {
    await API.initData();

    const currentUser = (window.getCurrentUser && window.getCurrentUser()) || JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');

    const remoteBookings = currentUser ? await API.getUserBookings(currentUser) : [];

    currentBooking = (remoteBookings || []).find((b) => String(b.id || b._id || b._supabaseId) === String(bookingId) || b.code === bookingId || b.appointment_code === bookingId);

    if (!currentBooking) {
        showBookingLoadError('Không tìm thấy lịch hẹn này.');
        return;
    }

    if (typeof window.setUserSubBreadcrumb === 'function') {
        window.setUserSubBreadcrumb(currentBooking.code || currentBooking.id || 'Chi tiết', 'bookings');
    }

    const userPets = currentUser ? await API.getUserPets(currentUser.id) : [];
    currentPet = userPets.find((pet) => String(pet._id || pet.id) === String(currentBooking.petId)) || null;
    const careLogs = await API.getCareLogs();
    currentCareLog = currentBooking.petId ? (careLogs[currentBooking.petId] || null) : null;

    const careLogButton = document.getElementById('btnViewCareLog');
    if (careLogButton) {
        careLogButton.onclick = () => {
            const petId = currentBooking.petId || currentPet?._id || currentPet?.id;
            if (!petId) {
                showToast('Không tìm thấy mã bé cưng để mở nhật ký chăm sóc.', 'error');
                return;
            }
            const sessionId = currentBooking.id || '';
            const query = `id=${encodeURIComponent(petId)}${sessionId ? `&sessionId=${encodeURIComponent(sessionId)}` : ''}`;
            window.scrollTo(0, 0);
            window.location.hash = `#diary?${query}`;
        };
    }

    renderBookingDetail(currentBooking);
    await renderServiceReviewSection(currentBooking);
    checkBookingModifiability(currentBooking);

    if (window.setUserSubBreadcrumb && currentBooking) {
        window.setUserSubBreadcrumb('#' + (currentBooking.code || currentBooking.id), 'booking-detail');
    }

    awardBookingLoyaltyPoints(currentBooking, currentUser);

    if (window.location.hash === '#service-review' || window.location.hash.includes('section=service-review')) {
        setTimeout(() => {
            const target = document.getElementById('serviceReviewSection')
                        || document.querySelector('.service-review-section');
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }, 200);
    }
}

function renderBookingDetail(booking) {
    const normalizedStatus = resolveBookingStatus(booking);
    const petName = booking.petName || currentPet?.name || booking.petInfo?.petName || booking.petId || 'Bé cưng';
    const petBreed = booking.petBreed || booking.petInfo?.breed || '';
    const petWeight = booking.petWeight || booking.petInfo?.weight || '';
    const serviceName = booking.service || booking.serviceName || booking.selectedService?.name || 'Dịch vụ PawPal';
    const servicePackage = booking.package ? ` - ${booking.package}` : '';

    const headerBadge = document.getElementById('headerStatusBadge');
    if (headerBadge) {
        headerBadge.className = `admin-badge badge-${normalizedStatus}`;
        headerBadge.textContent = statusLabels[normalizedStatus] || normalizedStatus;
    }

    const statusInfo = document.getElementById('statusInfo');
    if (statusInfo) {
        statusInfo.innerHTML = `<span class="admin-badge badge-${normalizedStatus}">${statusLabels[normalizedStatus] || normalizedStatus}</span>`;
    }

    const codeEl = document.getElementById('bookingCode');
    if (codeEl) codeEl.textContent = booking.id;

    const bannerCode = document.getElementById('bannerBookingCode');
    if (bannerCode) bannerCode.textContent = booking.id;

    const petInfoEl = document.getElementById('petInfo');
    if (petInfoEl) petInfoEl.textContent = `${petName}${petBreed || petWeight ? ` (${[petBreed, petWeight].filter(Boolean).join(', ')})` : ''}`;

    const serviceInfoEl = document.getElementById('serviceInfo');
    if (serviceInfoEl) serviceInfoEl.textContent = `${serviceName}${servicePackage}`;

    let dateTimeText = formatDate(booking.date || booking.schedule?.date);
    if (booking.timeStart) {
        dateTimeText += ` | ${booking.timeStart}${booking.timeEnd ? ` - ${booking.timeEnd}` : ''}`;
    } else if (booking.time) {
        dateTimeText += ` | ${booking.time}`;
    } else if (booking.schedule?.slot) {
        dateTimeText += ` | ${booking.schedule.slot}`;
    } else if (booking.dateEnd) {
        dateTimeText = `${dateTimeText} - ${formatDate(booking.dateEnd)}`;
    }

    const dateTimeEl = document.getElementById('dateTimeInfo');
    if (dateTimeEl) dateTimeEl.textContent = dateTimeText;

    const staffEl = document.getElementById('staffInfo');
    if (staffEl) staffEl.textContent = booking.staff || 'Chưa phân công';

    const priceEl = document.getElementById('priceInfo');
    if (priceEl) priceEl.textContent = formatPrice(booking.price || 0);

    const noteRow = document.getElementById('noteRow');
    const noteInfo = document.getElementById('noteInfo');
    if (booking.note && noteRow && noteInfo) {
        noteRow.classList.remove('d-none');
        noteInfo.textContent = booking.note;
    } else if (noteRow) {
        noteRow.classList.add('d-none');
    }

    const careLogSection = document.getElementById('careLogActionSection');
    if (careLogSection) {
        const hasCareLog = currentCareLog && (
            currentCareLog.currentSession ||
            (Array.isArray(currentCareLog.history) && currentCareLog.history.length > 0)
        );
        careLogSection.classList.toggle('d-none', !(normalizedStatus === 'completed' && hasCareLog));
    }

    const complaintSection = document.getElementById('serviceComplaintSection');
    const complaintLink = document.getElementById('btnServiceComplaintDetail');
    if (complaintSection && complaintLink) {
        const isCompleted = normalizedStatus === 'completed';
        complaintSection.classList.toggle('d-none', !isCompleted);
        if (isCompleted) {
            complaintLink.href = `#support-create?type=service&bookingId=${encodeURIComponent(booking.id)}`;
            complaintLink.onclick = () => window.scrollTo(0, 0);
        }
    }
}

async function loadServiceReviewFromSupabase(booking) {
    const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
    const apptId = booking?._supabaseId || booking?.id;
    if (!db || !apptId) return null;
    try {
        const { data, error } = await db
            .from('review')
            .select('id, rating, review_content, created_at, shop_reply')
            .eq('appointment_id', apptId)
            .in('review_type', ['dich_vu', 'SERVICE'])
            .maybeSingle();
        if (error) {
            console.warn('[BookingDetail] Lỗi kiểm tra đánh giá từ Supabase:', error);
            return null;
        }
        return data ? {
            id: data.id,
            rating: Number(data.rating),
            comment: data.review_content || '',
            replyText: data.shop_reply || '',
            createdAt: data.created_at
        } : null;
    } catch (e) {
        console.warn('[BookingDetail] Exception khi nạp đánh giá từ Supabase:', e);
        return null;
    }
}

async function renderServiceReviewSection(booking) {
    const section = document.getElementById('serviceReviewSection');
    if (!section) return;

    const normalizedStatus = resolveBookingStatus(booking);
    section.classList.toggle('d-none', normalizedStatus !== 'completed');
    if (normalizedStatus !== 'completed') return;

    const statusEl = document.getElementById('serviceReviewStatus');
    const hintEl = document.getElementById('serviceReviewHint');
    const textarea = document.getElementById('serviceReviewComment');
    const submitBtn = document.getElementById('btnSubmitServiceReview');

    const reviewKey = getServiceReviewKey(booking);
    const localReview = loadServiceReview(reviewKey);

    function applyReviewToUI(rev) {
        if (!rev) return;
        currentServiceReviewRating = Number(rev.rating || 0);
        if (statusEl) statusEl.textContent = 'Đã đánh giá';
        if (hintEl) hintEl.textContent = `Bạn đã đánh giá ${rev.rating}/5 sao.`;
        if (textarea) {
            textarea.value = rev.comment || rev.review_content || '';
            textarea.disabled = true;
        }
        syncServiceStarUI(currentServiceReviewRating);
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Đã gửi đánh giá';
        }
    }

    if (localReview) {
        applyReviewToUI(localReview);
    } else {
        currentServiceReviewRating = 0;
        if (statusEl) statusEl.textContent = 'Chưa đánh giá';
        if (hintEl) hintEl.textContent = 'Hãy chọn mức độ hài lòng của bạn.';
        if (textarea) {
            textarea.value = '';
            textarea.disabled = false;
        }
        syncServiceStarUI(0);
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Gửi đánh giá';
            submitBtn.onclick = handleSubmitServiceReview;
        }
    }

    // Kiểm tra đồng bộ từ Supabase
    const remoteRev = await loadServiceReviewFromSupabase(booking);
    if (remoteRev) {
        localStorage.setItem(reviewKey, JSON.stringify({
            bookingId: booking.id,
            service: booking.service || booking.serviceName || 'Dịch vụ PawPal',
            rating: remoteRev.rating,
            comment: remoteRev.comment,
            createdAt: remoteRev.createdAt
        }));
        applyReviewToUI(remoteRev);
    }

    const starButtons = document.querySelectorAll('#serviceStarRow .service-star-btn');
    starButtons.forEach((btn) => {
        btn.onclick = () => {
            if (textarea?.disabled) return;
            currentServiceReviewRating = Number(btn.dataset.rating || 0);
            syncServiceStarUI(currentServiceReviewRating);
        };
    });
}

function syncServiceStarUI(rating) {
    document.querySelectorAll('#serviceStarRow .service-star-btn').forEach((btn) => {
        const value = Number(btn.dataset.rating || 0);
        btn.classList.toggle('active', value <= rating && rating > 0);
    });
}

async function handleSubmitServiceReview() {
    if (!currentBooking) return;

    if (!currentServiceReviewRating) {
        showToast('Vui lòng chọn số sao đánh giá.', 'error');
        return;
    }

    const apptId = currentBooking._supabaseId || currentBooking.id;
    const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
    const commentEl = document.getElementById('serviceReviewComment');
    const commentText = commentEl ? commentEl.value.trim() : '';
    const submitBtn = document.getElementById('btnSubmitServiceReview');

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Đang gửi đánh giá...';
    }

    try {
        let savedDbReview = null;
        if (db && apptId) {
            const { data: appt, error: apptErr } = await db
                .from('appointment')
                .select('id, customer_id, service_id, appointment_status')
                .eq('id', apptId)
                .maybeSingle();

            if (apptErr) throw apptErr;

            if (appt) {
                const currentUser = (window.getCurrentUser && window.getCurrentUser()) || JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
                const customerId = appt.customer_id || currentUser?.id;
                const serviceId = appt.service_id || currentBooking.serviceId || currentBooking.serviceDbId;

                const { data: inserted, error: insErr } = await db
                    .from('review')
                    .insert([{
                        appointment_id: appt.id,
                        customer_id: customerId,
                        service_id: serviceId,
                        review_type: 'dich_vu',
                        rating: currentServiceReviewRating,
                        review_content: commentText,
                        review_status: 'da_duyet'
                    }])
                    .select()
                    .single();

                if (insErr) {
                    if (insErr.code === '23505' || insErr.message?.includes('duplicate') || insErr.message?.includes('unique')) {
                        console.warn('[BookingDetail] Lịch hẹn này đã có đánh giá trong hệ thống.');
                    } else {
                        throw insErr;
                    }
                } else {
                    savedDbReview = inserted;
                }
            }
        }

        const reviewKey = getServiceReviewKey(currentBooking);
        const review = {
            id: savedDbReview?.id || `rev-local-${Date.now()}`,
            bookingId: currentBooking.id,
            service: currentBooking.service || currentBooking.serviceName || currentBooking.selectedService?.name || 'Dịch vụ PawPal',
            rating: currentServiceReviewRating,
            comment: commentText,
            createdAt: new Date().toISOString()
        };
        localStorage.setItem(reviewKey, JSON.stringify(review));

        const statusEl = document.getElementById('serviceReviewStatus');
        const hintEl = document.getElementById('serviceReviewHint');
        if (statusEl) statusEl.textContent = 'Đã đánh giá';
        if (hintEl) hintEl.textContent = `Bạn đã đánh giá ${currentServiceReviewRating}/5 sao.`;
        if (commentEl) commentEl.disabled = true;

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Đã gửi đánh giá';
        }

        showServiceReviewToast('Cảm ơn bạn đã gửi đánh giá cho dịch vụ này.');
    } catch (err) {
        console.error('[BookingDetail] Lỗi lưu đánh giá:', err);
        showToast('Không thể gửi đánh giá: ' + (err.message || 'Lỗi kết nối'), 'error');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Gửi đánh giá';
        }
    }
}

function showServiceReviewToast(message) {
    let container = document.getElementById('service-review-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'service-review-toast-container';
        container.style.cssText = 'position:fixed;top:92px;right:20px;z-index:99999;display:flex;flex-direction:column;gap:10px;max-width:360px;';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.textContent = message;
    toast.style.cssText = 'background:#2d7d46;color:#fff;padding:12px 16px;border-radius:12px;box-shadow:0 8px 22px rgba(0,0,0,.15);font-size:0.92rem;';
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 2800);
}

function checkBookingModifiability(booking) {
    const btnChange = document.getElementById('btnChangeSchedule');
    const btnCancel = document.getElementById('btnCancelBooking');

    if (!btnChange || !btnCancel) return;

    const scheduledAt = getBookingScheduledAt(booking);
    const currentStatus = resolveBookingStatus(booking);

    // 1. Nghiệp vụ Thay đổi lịch hẹn (Quy trình 3.1.5):
    // Chỉ kích hoạt khi ca hẹn ở trạng thái "Đã xác nhận" (confirmed)
    const isConfirmed = currentStatus === 'confirmed';
    const changeCount = Number(booking.changeCount || 0);
    const changeLimitReached = changeCount >= 2;

    if (!isConfirmed || changeLimitReached || !scheduledAt) {
        btnChange.classList.add('d-none');
    } else {
        btnChange.classList.remove('d-none');
        const now = new Date();
        const diffMinutes = (scheduledAt - now) / (1000 * 60);

        if (diffMinutes < 120) {
            btnChange.disabled = true;
            btnChange.classList.add('disabled');
            btnChange.setAttribute('title', 'Đã quá thời gian tự thay đổi lịch tự động (< 2 tiếng). Vui lòng gọi Hotline để được hỗ trợ.');
        } else {
            btnChange.disabled = false;
            btnChange.classList.remove('disabled');
            btnChange.removeAttribute('title');
        }
    }

    // 2. Nghiệp vụ Hủy lịch hẹn:
    // Tuyệt đối không cho phép hủy khi: Đang thực hiện (in-progress), Đã tiếp nhận (accepted), Hoàn thành (completed), Đã hủy (cancelled)
    const nonCancellable = ['in-progress', 'accepted', 'completed', 'cancelled'];
    const canAttemptCancel = ['pending', 'confirmed'].includes(currentStatus) && !nonCancellable.includes(currentStatus);

    if (!canAttemptCancel || !scheduledAt) {
        btnCancel.classList.add('d-none');
    } else {
        btnCancel.classList.remove('d-none');
        const now = new Date();
        const diffMinutes = (scheduledAt - now) / (1000 * 60);

        if (diffMinutes < 120) {
            btnCancel.disabled = true;
            btnCancel.classList.add('disabled');
            btnCancel.setAttribute('title', 'Đã quá thời gian tự hủy lịch tự động (< 2 tiếng). Vui lòng gọi Hotline để được hỗ trợ.');
        } else {
            btnCancel.disabled = false;
            btnCancel.classList.remove('disabled');
            btnCancel.removeAttribute('title');
        }
    }
}

function handleChangeSchedule() {
    const btnChange = document.getElementById('btnChangeSchedule');
    const scheduledAt = getBookingScheduledAt(currentBooking);
    const now = new Date();
    const diffMinutes = scheduledAt ? (scheduledAt - now) / (1000 * 60) : 0;

    if (diffMinutes < 120 || (btnChange && btnChange.disabled)) {
        showErrorBanner();
        return;
    }

    const currentUser = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
    if (currentUser && currentUser.is_temporary) {
        showGuestOTPModal(currentUser, () => showChangeScheduleModal(currentUser));
        return;
    }

    showChangeScheduleModal(null);
}

async function loadRealScheduleOptions() {
    const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
    const defaultSlots = ['08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
    const randomOption = { id: 'random', name: 'Phân bổ ngẫu nhiên', desc: 'PawPal tự động chọn nhân viên trống lịch' };
    if (!db) return { slots: defaultSlots, staffs: [randomOption] };

    try {
        const [{ data: staffData, error: staffErr }, { data: scheduleData, error: scheduleErr }] = await Promise.all([
            db.from('staff').select('id, full_name, specialization, status, service_locked').order('full_name', { ascending: true }),
            db.from('staff_schedule').select('start_time, end_time')
        ]);
        if (staffErr) throw staffErr;
        if (scheduleErr) throw scheduleErr;

        const activeStaff = (staffData || [])
            .filter((s) => s.status === 'ACTIVE' && !s.service_locked)
            .map((s) => ({ id: s.id, name: s.full_name, desc: s.specialization || 'Chuyên viên PawPal' }));

        const generatedSlots = new Set(defaultSlots);
        (scheduleData || []).forEach((row) => {
            if (!row.start_time || !row.end_time) return;
            const startHour = parseInt(row.start_time.split(':')[0], 10);
            const endHour = parseInt(row.end_time.split(':')[0], 10);
            for (let i = startHour; i <= endHour; i++) generatedSlots.add(`${String(i).padStart(2, '0')}:00`);
        });

        return { slots: Array.from(generatedSlots).sort(), staffs: [randomOption, ...activeStaff] };
    } catch (err) {
        console.warn('[BookingDetail] Could not load schedule options from Supabase:', err.message);
        return { slots: defaultSlots, staffs: [randomOption] };
    }
}

async function showChangeScheduleModal(user = null) {
    const modalId = 'changeScheduleModal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const isHotelBooking = String(currentBooking?.serviceCategory || currentBooking?.category || currentBooking?.service_type || '').toLowerCase() === 'hotel';
    const { slots, staffs } = await loadRealScheduleOptions();

    const slotsHtml = slots.map(s =>
        `<button class="slot-time-btn" data-time="${s}" disabled style="opacity:0.4;cursor:not-allowed;">${s}</button>`
    ).join('');

    const staffHtml = staffs.map(s => {
        const initials = s.name === 'Phân bổ ngẫu nhiên' ? 'NG' : s.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
        return `
            <div class="staff-card" data-name="${s.name}" tabindex="-1" role="button"
                style="display:flex;align-items:center;gap:10px;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:10px;cursor:not-allowed;opacity:0.4;transition:all .2s;pointer-events:none;">
                <div style="width:36px;height:36px;border-radius:50%;background:var(--color-primary-light,#e8f5e9);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;color:var(--color-primary-dark,#2e7d32);flex-shrink:0;">${initials}</div>
                <div>
                    <div style="font-weight:700;font-size:0.88rem;color:var(--color-primary-dark,#2e7d32);">${s.name}</div>
                    <div style="font-size:0.75rem;color:#64748b;">${s.desc}</div>
                </div>
            </div>`;
    }).join('');

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const minDate = tomorrow.toISOString().split('T')[0];

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal fade';
    modalEl.tabIndex = -1;
    modalEl.innerHTML = `
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${isHotelBooking ? 'Đổi ngày lưu trú' : 'Chọn lịch mới'}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted small mb-3">${isHotelBooking ? 'Pet Hotel chỉ cần đổi ngày, không cần chọn giờ hay nhân viên.' : 'Chọn ngày trước, sau đó chọn giờ và nhân viên.'}</p>

                    <div class="mb-1 fw-semibold" style="font-size:0.88rem;">Chọn ngày</div>
                    <input type="date" id="changeDatePicker" class="form-control mb-4" min="${minDate}" style="max-width:220px;">

                    ${isHotelBooking ? '' : `
                    <div class="mb-1 fw-semibold" style="font-size:0.88rem;">Chọn giờ</div>
                    <div class="slot-time-grid mb-3" id="changeSlotGrid">${slotsHtml}</div>
                    <div id="holdBanner" class="d-none mb-3" style="font-size:0.82rem;padding:8px 12px;background:#fff8e1;border:1px solid #ffe082;border-radius:8px;color:#7a5c00;">
                        <strong>Giữ chỗ tạm thời:</strong> Giờ <strong id="holdSlotLabel"></strong> được giữ riêng cho bạn trong <strong id="holdCountdown"></strong>
                    </div>

                    <div class="mb-1 fw-semibold" style="font-size:0.88rem;">Chọn nhân viên</div>
                    <div id="changeStaffList" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-bottom:12px;">${staffHtml}</div>

                    <div class="slot-selected-info mt-2 d-none" id="slotSelectedInfo" style="font-size:0.85rem;color:var(--color-primary-dark,#2e7d32);display:flex;align-items:center;gap:6px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                        Đã chọn: <strong id="slotSelectedText"></strong>
                    </div>
                    `}

                    <div class="mt-3">
                        <label class="form-label fw-semibold" style="font-size:0.88rem;">Ghi chú <span class="text-muted fw-normal">(tuỳ chọn)</span></label>
                        <textarea class="form-control" id="changeNotes" rows="2" placeholder="Ví dụ: tôi cần chuyển sang buổi chiều..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-green-outline" data-bs-dismiss="modal">Huỷ</button>
                    <button type="button" class="btn-cta" id="confirmChangeBtn" disabled>Xác nhận thay đổi</button>
                </div>
            </div>
        </div>`;
    document.body.appendChild(modalEl);

    const modal = new bootstrap.Modal(modalEl);
    modal.show();

    let selectedDate = '';
    let selectedTime = null;
    let selectedStaff = isHotelBooking ? 'Bảo mẫu khách sạn' : null;
    let holdInterval = null;

    function clearHoldTimer() {
        if (holdInterval) { clearInterval(holdInterval); holdInterval = null; }
        document.getElementById('holdBanner')?.classList.add('d-none');
    }

    function startHoldTimer(slot) {
        if (isHotelBooking) return;
        clearHoldTimer();
        let remaining = 15 * 60;
        const banner   = document.getElementById('holdBanner');
        const label    = document.getElementById('holdSlotLabel');
        const countdown = document.getElementById('holdCountdown');
        label.textContent = slot;
        banner.classList.remove('d-none');

        function tick() {
            const m = Math.floor(remaining / 60).toString().padStart(2, '0');
            const s = (remaining % 60).toString().padStart(2, '0');
            countdown.textContent = `${m}:${s}`;
            if (remaining <= 0) {
                clearHoldTimer();
                selectedTime = null;
                modalEl.querySelectorAll('.slot-time-btn').forEach(b => b.classList.remove('active'));
                banner.innerHTML = `<strong>Hết thời gian giữ chỗ!</strong> Vui lòng chọn lại giờ.`;
                banner.style.background = '#fff3cd';
                banner.style.borderColor = '#ffeeba';
                banner.classList.remove('d-none');
                refresh();
            }
            remaining--;
        }
        tick();
        holdInterval = setInterval(tick, 1000);
    }

    modalEl.addEventListener('hidden.bs.modal', () => clearHoldTimer());

    function enableTimeAndStaff() {
        if (isHotelBooking) return;
        modalEl.querySelectorAll('.slot-time-btn').forEach(b => {
            b.disabled = false;
            b.style.opacity = '';
            b.style.cursor = '';
        });
        modalEl.querySelectorAll('.staff-card').forEach(c => {
            c.style.opacity = '';
            c.style.cursor = '';
            c.style.pointerEvents = '';
            c.tabIndex = 0;
        });
    }

    function refresh() {
        const infoEl    = document.getElementById('slotSelectedInfo');
        const textEl    = document.getElementById('slotSelectedText');
        const confirmBtn = document.getElementById('confirmChangeBtn');
        if (selectedDate && (isHotelBooking || (selectedTime && selectedStaff))) {
            const d = new Date(selectedDate + 'T00:00:00');
            const dateLabel = d.toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' });
            textEl.textContent = isHotelBooking ? `${dateLabel}` : `${dateLabel} lúc ${selectedTime} • ${selectedStaff}`;
            infoEl?.classList.remove('d-none');
            confirmBtn.disabled = false;
        } else {
            infoEl?.classList.add('d-none');
            confirmBtn.disabled = true;
        }
    }

    document.getElementById('changeDatePicker').addEventListener('change', (e) => {
        selectedDate = e.target.value;
        if (!isHotelBooking) {
            selectedTime = null;
            clearHoldTimer();
            modalEl.querySelectorAll('.slot-time-btn').forEach(b => b.classList.remove('active'));
            enableTimeAndStaff();
        }
        refresh();
    });

    if (!isHotelBooking) {
        modalEl.querySelectorAll('.slot-time-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (!selectedDate) return;
                modalEl.querySelectorAll('.slot-time-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                selectedTime = btn.dataset.time;
                startHoldTimer(selectedTime);
                refresh();
            });
        });

        modalEl.querySelectorAll('.staff-card').forEach(card => {
            card.addEventListener('click', () => {
                if (!selectedDate) return;
                modalEl.querySelectorAll('.staff-card').forEach(c => {
                    c.style.borderColor = '#e2e8f0';
                    c.style.background = '';
                });
                card.style.borderColor = 'var(--color-primary, #4caf50)';
                card.style.background = 'var(--color-primary-light, #e8f5e9)';
                selectedStaff = card.dataset.name;
                refresh();
            });
        });
    }

    document.getElementById('confirmChangeBtn').addEventListener('click', async (event) => {
        if (!selectedDate || (!isHotelBooking && (!selectedTime || !selectedStaff))) return;
        const confirmBtn = event.currentTarget;
        if (confirmBtn.disabled) return;
        clearHoldTimer();
        confirmBtn.disabled = true;

        const notes = document.getElementById('changeNotes').value.trim();
        const updatedBooking = { ...currentBooking, date: selectedDate };
        if (isHotelBooking) {
            updatedBooking.time = '';
            updatedBooking.timeStart = '';
            updatedBooking.timeEnd = '';
            updatedBooking.staff = 'Bảo mẫu khách sạn';
        } else {
            updatedBooking.time = selectedTime;
            updatedBooking.timeStart = selectedTime;
            updatedBooking.timeEnd = '';
            updatedBooking.staff = selectedStaff;
        }
        updatedBooking.changeCount = (currentBooking.changeCount || 0) + 1;
        if (notes) updatedBooking.note = `Yêu cầu đổi lịch: ${notes}`;

        try {
            await rescheduleBookingOnSupabase(updatedBooking);
            currentBooking = updatedBooking;
            showToast('Đã thay đổi lịch hẹn thành công!', 'success');
            renderBookingDetail(currentBooking);
            checkBookingModifiability(currentBooking);
            bootstrap.Modal.getInstance(modalEl)?.hide();

            if (user) {
                setTimeout(() => showUpsellPasswordModal(user), 800);
            }
        } catch (err) {
            console.error('[BookingDetail] Đổi lịch thất bại:', err);
            showToast('Không thể đổi lịch hẹn lúc này. Vui lòng thử lại.', 'error');
            confirmBtn.disabled = false;
        }
    });
}

function handleCancelBooking() {
    const scheduledAt = getBookingScheduledAt(currentBooking);
    const now = new Date();
    const diffMinutes = scheduledAt ? (scheduledAt - now) / (1000 * 60) : 999;

    if (diffMinutes < 120) {
        showToast('Chỉ được phép tự hủy lịch hẹn trước giờ bắt đầu tối thiểu 2 tiếng. Ca hẹn sắp diễn ra, vui lòng liên hệ Hotline 1900 1234 để được hỗ trợ.', 'danger');
        return;
    }

    const currentUser = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
    if (currentUser && Number(currentUser.cancelCount || 0) >= 3) {
        showToast('Tài khoản của bạn đã vượt quá ngưỡng hủy lịch cho phép (> 3 lần). Chức năng đặt và quản lý lịch trực tuyến của bạn đã bị tạm khóa. Vui lòng gọi Hotline 1900 1234.', 'danger');
        return;
    }

    if (currentUser && currentUser.is_temporary) {
        showCancelConfirmModal(() => {
            showGuestOTPModal(currentUser, () => {
                confirmCancelBooking(() => showUpsellPasswordModal(currentUser));
            });
        });
        return;
    }

    showCancelConfirmModal(() => {
        confirmCancelBooking(null);
    });
}

function showCancelConfirmModal(onConfirm) {
    const cancelModal = new bootstrap.Modal(document.getElementById('cancelModal'));
    document.getElementById('modalBookingCode').textContent = currentBooking.id;
    cancelModal.show();
    document.getElementById('confirmCancelBtn').onclick = function () {
        cancelModal.hide();
        onConfirm();
    };
}

function showGuestOTPModal(user, onSuccess) {
    const modalId = 'guestOtpModal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal fade';
    modalEl.tabIndex = -1;
    modalEl.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Xác thực số điện thoại</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted mb-3">Mã OTP đã được gửi đến số <strong>${user.phone}</strong>.</p>
                    <div class="mb-2">
                        <label class="form-label fw-semibold">Mã OTP <span class="text-muted small fw-normal">(Mã test: 555666)</span></label>
                        <input type="text" id="otpInput" class="form-control text-center fw-bold fs-4"
                            maxlength="6" placeholder="_ _ _ _ _ _" autocomplete="one-time-code">
                        <div class="text-danger small mt-1 d-none" id="otpError">Mã OTP không đúng, vui lòng thử lại.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-green-outline" data-bs-dismiss="modal">Hủy</button>
                    <button type="button" class="btn-cta" id="confirmOtpBtn">Xác nhận</button>
                </div>
            </div>
        </div>`;
    document.body.appendChild(modalEl);

    const modal = new bootstrap.Modal(modalEl);
    modal.show();
    showToast('Mã OTP test: 555666', 'success');

    document.getElementById('confirmOtpBtn').addEventListener('click', () => {
        const val = document.getElementById('otpInput').value.trim();
        if (val === '555666') {
            modal.hide();
            onSuccess();
        } else {
            document.getElementById('otpError').classList.remove('d-none');
        }
    });
}

async function confirmCancelBooking(onDone) {
    const currentUser = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');

    try {
        await cancelBookingOnSupabase(currentBooking);
    } catch (err) {
        console.error('[BookingDetail] Hủy lịch thất bại:', err);
        showToast('Không thể hủy lịch hẹn lúc này. Vui lòng thử lại.', 'error');
        return;
    }

    if (currentUser) {
        currentUser.cancelCount = (Number(currentUser.cancelCount) || 0) + 1;
        if (currentUser.cancelCount > 3) {
            currentUser.booking_locked = true;
        }
        localStorage.setItem('pawpal_current_user', JSON.stringify(currentUser));

        try {
            const users = JSON.parse(localStorage.getItem('pawpal_users') || '[]');
            const uIdx = users.findIndex(u => u.id === currentUser.id || u.phone === currentUser.phone);
            if (uIdx !== -1) {
                users[uIdx].cancelCount = currentUser.cancelCount;
                users[uIdx].booking_locked = currentUser.booking_locked;
                localStorage.setItem('pawpal_users', JSON.stringify(users));
            }
        } catch (_) {}
    }

    try {
        const bookings = JSON.parse(localStorage.getItem('pawpal_bookings') || '[]');
        const idx = bookings.findIndex(b => String(b.id || b._id) === String(currentBooking.id || currentBooking._id));
        if (idx !== -1) {
            bookings[idx].cancelCount = (bookings[idx].cancelCount || 0) + 1;
            bookings[idx].status = 'cancelled';
            localStorage.setItem('pawpal_bookings', JSON.stringify(bookings));
        }
    } catch (_) {}

    currentBooking.status = 'cancelled';

    // Ghi thông báo xác nhận hủy lịch thật vào bảng notification cho khách hàng
    try {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (db && currentUser?.id) {
            const { error: notifErr } = await db.from('notification').insert({
                customer_id: currentUser.id,
                notification_type: 'lich_hen_da_thay_doi',
                title: 'Xác nhận hủy lịch hẹn',
                content: `Lịch hẹn #${currentBooking.id || currentBooking.code} của bé ${currentBooking.petName || 'cưng'} đã được hủy thành công.`,
                appointment_id: currentBooking.rawId || currentBooking.id || null,
                related_entity_type: 'appointment',
                is_read: false,
                sent_at: new Date().toISOString()
            });
            if (notifErr) {
                console.warn('[BookingDetail] Lỗi ghi thông báo hủy lịch:', notifErr.message);
            }
        }
    } catch (notifErr) {
        console.warn('[BookingDetail] Không thể ghi thông báo hủy lịch vào Supabase:', notifErr.message);
    }

    // Gửi thông báo đến Admin
    try {
        const adminNotifs = JSON.parse(localStorage.getItem('pawpal_admin_notifications') || '[]');
        adminNotifs.unshift({
            id: `admin-notif-${Date.now()}`,
            type: 'booking_cancelled',
            title: 'Khách hàng hủy lịch hẹn',
            content: `Khách hàng ${currentUser?.name || currentBooking.ownerName || 'vãng lai'} (${currentUser?.phone || currentBooking.ownerPhone}) vừa hủy ca hẹn #${currentBooking.id || currentBooking.code}.`,
            createdAt: new Date().toISOString(),
            read: false
        });
        localStorage.setItem('pawpal_admin_notifications', JSON.stringify(adminNotifs));
    } catch (_) {}

    showToast('Đã hủy lịch hẹn thành công', 'success');

    if (onDone) {
        setTimeout(onDone, 800);
    } else {
        setTimeout(() => { window.location.hash = '#bookings'; }, 1500);
    }
}

function showUpsellPasswordModal(user) {
    const modalId = 'upsellPasswordModal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal fade';
    modalEl.tabIndex = -1;
    modalEl.setAttribute('data-bs-backdrop', 'static'); // không đóng khi click ngoài
    modalEl.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center py-4 px-4">
                    <div class="mb-3" style="font-size:2.5rem">🐾</div>
                    <h5 class="fw-bold mb-2" style="color:var(--color-primary-dark)">Lịch hẹn đã được hủy!</h5>
                    <p class="text-muted mb-4">Thiết lập mật khẩu để quản lý lịch hẹn, tích điểm Paw Points và nhận nhiều ưu đãi độc quyền dành cho thành viên.</p>
                    <div class="d-flex flex-column gap-2">
                        <button class="btn-cta w-100" id="upsellSetupBtn">Thiết lập mật khẩu ngay</button>
                        <button class="btn-green-outline w-100" id="upsellSkipBtn">Bỏ qua, quay về tra cứu</button>
                    </div>
                </div>
            </div>
        </div>`;
    document.body.appendChild(modalEl);

    const modal = new bootstrap.Modal(modalEl);
    modal.show();

    document.getElementById('upsellSetupBtn').addEventListener('click', () => {
        const tokens = JSON.parse(localStorage.getItem('pawpal_temp_tokens') || '[]');
        let tokenObj = tokens.find(t => t.phone === user.phone);
        if (!tokenObj) {
            tokenObj = {
                token: `token-temp-${Math.floor(100000 + Math.random() * 900000)}`,
                phone: user.phone,
                createdAt: Date.now()
            };
            tokens.push(tokenObj);
            localStorage.setItem('pawpal_temp_tokens', JSON.stringify(tokens));
        }
        window.location.href = `/pages/public/login/login.html#setup-password?token=${tokenObj.token}`;
    });

    document.getElementById('upsellSkipBtn').addEventListener('click', () => {
        modal.hide();
        window.location.href = '/pages/public/return-guest/return-guest.html';
    });
}

function showErrorBanner() {
    const banner = document.getElementById('errorBanner');
    if (bannerTimeout) clearTimeout(bannerTimeout);
    banner.classList.remove('d-none', 'hiding');
    bannerTimeout = setTimeout(closeErrorBanner, 7000);
}

function closeErrorBanner() {
    const banner = document.getElementById('errorBanner');
    banner.classList.add('hiding');
    setTimeout(() => banner.classList.add('d-none'), 300);
}

function showToast(message, type = 'info') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:99999;display:flex;flex-direction:column;gap:8px;';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast-custom toast-${type}`;
    toast.innerHTML = `<div class="toast-content"><span class="toast-message">${message}</span></div>`;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function awardBookingLoyaltyPoints(booking, user) {
    if (!booking || !user || user.is_temporary) return;

    const normalizedStatus = resolveBookingStatus(booking);
    if (normalizedStatus !== 'completed') return;
    if (booking.pointsAwarded) return;

    const price = Number(booking.price || 0);
    if (price <= 0) return;

    const pointsEarned = Math.floor(price / 10000);
    if (pointsEarned <= 0) return;

    const users = JSON.parse(localStorage.getItem('pawpal_users') || '[]');
    const idx = users.findIndex(u => u.phone === user.phone);
    if (idx !== -1) {
        users[idx].points = (users[idx].points || 0) + pointsEarned;
        users[idx].spend  = (users[idx].spend  || 0) + price;
        users[idx].lastTransactionAt = new Date().toISOString();

        user.points = users[idx].points;
        user.spend  = users[idx].spend;
        user.lastTransactionAt = users[idx].lastTransactionAt;
        localStorage.setItem('pawpal_current_user', JSON.stringify(user));
        localStorage.setItem('pawpal_users', JSON.stringify(users));
    }

    booking.pointsAwarded = true;
    booking.pointsEarned  = pointsEarned;
    const bookings = JSON.parse(localStorage.getItem('pawpal_bookings') || '[]');
    const bi = bookings.findIndex(b => b.id === booking.id);
    if (bi !== -1) {
        bookings[bi] = { ...bookings[bi], pointsAwarded: true, pointsEarned };
        localStorage.setItem('pawpal_bookings', JSON.stringify(bookings));
    }

    showToast(`Bạn vừa tích được +${pointsEarned} Paw Points cho dịch vụ này!`, 'success');
    console.log(`[Loyalty] +${pointsEarned} Paw Points cho booking ${booking.id} (${price.toLocaleString('vi-VN')}đ)`);
}

window.handleChangeSchedule = handleChangeSchedule;
window.handleCancelBooking = handleCancelBooking;
window.closeErrorBanner = closeErrorBanner;

function resolveBookingStatus(booking) {
    const rawStatus = booking?.status || 'upcoming';
    if (['cancelled', 'completed', 'in-progress', 'accepted', 'pending'].includes(rawStatus)) {
        return rawStatus;
    }

    const isHotel = String(booking?.serviceCategory || booking?.category || booking?.service_type || '').toLowerCase() === 'hotel' || String(booking?.service || booking?.serviceName || '').toLowerCase().includes('hotel');
    
    if (isHotel && booking.dateEnd) {
        const endDate = new Date(`${booking.dateEnd}T12:00:00`);
        const now = Date.now();
        if (!Number.isNaN(endDate.getTime())) {
            if (now > endDate.getTime() + 4 * 3600000) return 'completed';
            const startDate = new Date(`${booking.date}T12:00:00`);
            if (now >= startDate.getTime()) return 'in-progress';
            return 'confirmed';
        }
    }

    const scheduledAt = getBookingScheduledAt(booking);
    if (!scheduledAt) {
        return rawStatus === 'confirmed' ? 'accepted' : 'confirmed';
    }

    const now = Date.now();
    const hoursPast = (now - scheduledAt.getTime()) / (1000 * 60 * 60);

    if (hoursPast >= 4) return 'completed';
    if (hoursPast >= 1) return 'in-progress';
    if (hoursPast >= 0) return 'accepted';
    return 'confirmed';
}

function getBookingScheduledAt(booking) {
    if (!booking?.date) return null;
    const isHotel = String(booking?.serviceCategory || booking?.category || booking?.service_type || '').toLowerCase() === 'hotel' || String(booking?.service || booking?.serviceName || '').toLowerCase().includes('hotel');
    const time = booking.timeStart || booking.time || (isHotel ? '12:00' : '09:00');
    const scheduled = new Date(`${booking.date}T${time}:00`);
    return Number.isNaN(scheduled.getTime()) ? null : scheduled;
}

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        const banner = document.getElementById('errorBanner');
        if (banner && !banner.classList.contains('d-none')) closeErrorBanner();
    }
});

