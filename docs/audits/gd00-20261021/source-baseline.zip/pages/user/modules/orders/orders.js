import { normalizeOrderStatus, getStatusLabel } from '/scripts/shared/order-status.mjs';

import { API } from '/scripts/api/api.js';
import { watchCustomerTables } from '/scripts/shared/customer-realtime.mjs';
import './return-handler.js';
import './review-handler.js';

const ordersState = {
    allOrders: [],
    filteredOrders: [],
    currentTab: 'all',
    currentPage: 1,
    ordersPerPage: 10,
    searchQuery: '',
    returns: [],
    reviews: []
};

let ordersLoadVersion = 0;
let stopOrdersRealtime;
export function dispose() {
    ++ordersLoadVersion;
    stopOrdersRealtime?.();
    clearInterval(pendingOrdersTicker);
}

async function loadOrders() {
    const loadVersion = ++ordersLoadVersion;
    try {
        const currentUser = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
        
        if (!currentUser) {
            showEmptyState('Vui lòng đăng nhập để xem đơn hàng.');
            return;
        }

        if (!window.SupabaseClient) {
            await new Promise(r => setTimeout(r, 300));
        }

        const remoteOrders = await API.getUserOrders(currentUser.id);
        if (loadVersion !== ordersLoadVersion) return;
        // Live data is authoritative; never merge browser copies over server state.
        const mergedList = remoteOrders.map(order => {
            const products = Array.isArray(order.products) && order.products.length > 0
                ? order.products
                : (Array.isArray(order.items) && order.items.length > 0 ? order.items : []);
            
            const normalizedProducts = products.map(p => ({
                id: p.id || p.productId || '',
                name: p.name || p.title || 'Sản phẩm',
                image: p.image || p.img || '/assets/images/publics/feed.jpg',
                quantity: Number(p.quantity ?? p.qty) || 1,
                price: Number(p.price ?? p.unitPrice) || 0,
                total: Number(p.total) || ((Number(p.price) || 0) * (Number(p.quantity) || 1))
            }));

            const grandTotal = Number(
                order.pricing?.grandTotal ?? order.pricing?.total ?? order.total ?? 0
            );

            return {
                ...order,
                id: order.id || order.orderId || `ORD-${Date.now()}`,
                products: normalizedProducts,
                pricing: {
                    ...(order.pricing || {}),
                    total: grandTotal,
                    grandTotal: grandTotal
                },
                paymentMethod: (order.paymentMethod || order.payment?.method || 'cod').toLowerCase(),
                paymentStatus: String(order.paymentStatus || order.payment?.status || (order.paymentMethod === 'cod' ? 'pending_payment' : 'pending')).toLowerCase(),
                status: order.status || 'pending',
                createdAt: order.createdAt || new Date().toISOString()
            };
        });

        ordersState.allOrders = mergedList;
        ordersState.filteredOrders = ordersState.allOrders;

        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (db) {
            try {
                const [returnsRes, reviewsRes] = await Promise.all([
                    db.from('return_request').select('sales_order_id').eq('customer_id', currentUser.id),
                    db.from('review').select('sales_order_id').eq('customer_id', currentUser.id)
                ]);
                if (loadVersion !== ordersLoadVersion) return;
                if (returnsRes.data) ordersState.returns = returnsRes.data.map(r => r.sales_order_id);
                if (reviewsRes.data) ordersState.reviews = reviewsRes.data.map(r => r.sales_order_id);
            } catch(e) {
                console.error('Error fetching returns/reviews', e);
            }
        }

        checkAndExpirePendingOrders();
        if (loadVersion !== ordersLoadVersion) return;
        updateStats();
        updateTabCounts();
        applyFilters();
        startPendingOrdersTicker();
    } catch (error) {
        if (loadVersion !== ordersLoadVersion) return;
        console.error('Lỗi load đơn hàng:', error);
        showEmptyState('Không thể tải đơn hàng. Vui lòng thử lại sau.');
    }
}

function checkAndExpirePendingOrders() {
    let hasChanges = false;
    const now = Date.now();

    ordersState.allOrders.forEach((order) => {
        const isOnline = ['vnpay', 'momo', 'zalopay', 'vietqr'].includes((order.paymentMethod || order.payment?.method || '').toLowerCase());
        const isPaid = order.paymentStatus === 'paid' || order.payment?.status === 'paid';
        const isPending = order.status === 'pending_payment' || order.status === 'pending' || order.status === 'placed';

        if (isPending && !isPaid && isOnline && order.paymentExpiry) {
            const expiryTime = new Date(order.paymentExpiry).getTime();
            if (now >= expiryTime) {
                order.status = 'cancelled';
                order.paymentStatus = 'expired';
                order.cancelReason = 'Quá thời hạn thanh toán trực tuyến (15 phút)';
                if (!Array.isArray(order.timeline)) order.timeline = [];
                order.timeline.push({
                    status: 'cancelled',
                    title: 'Tự động hủy đơn hàng',
                    description: 'Đơn hàng tự động hủy do quá thời hạn thanh toán 15 phút',
                    timestamp: new Date().toISOString()
                });
                hasChanges = true;
            }
        }
    });

    if (hasChanges) {
        try {
            const allLocalOrders = JSON.parse(localStorage.getItem('pawpal_orders') || '[]');
            ordersState.allOrders.forEach((updatedOrder) => {
                const idx = allLocalOrders.findIndex(o => String(o.id) === String(updatedOrder.id));
                if (idx !== -1) {
                    allLocalOrders[idx] = { ...allLocalOrders[idx], ...updatedOrder };
                }
            });
            localStorage.setItem('pawpal_orders', JSON.stringify(allLocalOrders));
        } catch (e) {
            console.error('Error saving expired orders to localStorage', e);
        }
    }

    return hasChanges;
}

let pendingOrdersTicker = null;
function startPendingOrdersTicker() {
    if (pendingOrdersTicker) clearInterval(pendingOrdersTicker);
    pendingOrdersTicker = setInterval(() => {
        const timerChips = document.querySelectorAll('.order-pending-countdown');
        if (!timerChips || timerChips.length === 0) return;

        let needsRefresh = false;
        const now = Date.now();

        timerChips.forEach((chip) => {
            const expiryStr = chip.getAttribute('data-expiry');
            if (!expiryStr) return;
            const diff = new Date(expiryStr).getTime() - now;
            const clockEl = chip.querySelector('.countdown-clock');

            if (diff <= 0) {
                if (clockEl) clockEl.textContent = '00:00 (Hết hạn)';
                needsRefresh = true;
            } else {
                const totalSeconds = Math.floor(diff / 1000);
                const minutes = Math.floor(totalSeconds / 60);
                const seconds = totalSeconds % 60;
                if (clockEl) {
                    clockEl.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
                }
            }
        });

        if (needsRefresh) {
            const hasExpired = checkAndExpirePendingOrders();
            if (hasExpired) {
                updateStats();
                updateTabCounts();
                applyFilters();
            }
        }
    }, 1000);
}

function updateStats() {
    const processingStatuses = ['pending', 'preparing', 'shipping', 'delivered'];
    const processingCount = ordersState.allOrders.filter((order) => processingStatuses.includes(normalizeOrderStatus(order.status))).length;
    const completedCount = ordersState.allOrders.filter((order) => normalizeOrderStatus(order.status) === 'completed').length;
    const totalSpent = ordersState.allOrders
        .filter((order) => order.paymentStatus === 'paid' && !['cancelled', 'returned'].includes(normalizeOrderStatus(order.status)))
        .reduce((sum, order) => {
            const amount = toNumber(order.pricing?.total)
                        || toNumber(order.pricing?.grandTotal);
            return sum + amount;
        }, 0);

    document.getElementById('processing-count').textContent = processingCount;
    document.getElementById('completed-count').textContent = completedCount;
    document.getElementById('total-spent').textContent = formatCurrency(totalSpent);
}

function updateTabCounts() {
    const statuses = ['all', 'pending', 'preparing', 'shipping', 'delivered', 'completed', 'cancelled', 'returned'];

    statuses.forEach((status) => {
        const count = status === 'all'
            ? ordersState.allOrders.length
            : ordersState.allOrders.filter((order) => normalizeOrderStatus(order.status) === status).length;

        const countElement = document.getElementById(`count-${status}`);
        if (countElement) countElement.textContent = `(${count})`;
    });
}

function filterByStatus(status) {
    ordersState.currentTab = status;
    ordersState.currentPage = 1;
    applyFilters();
}

function searchOrders(query) {
    const normalizedQuery = String(query ?? '').trim();
    ordersState.searchQuery = normalizedQuery.toLowerCase();
    const searchInput = document.getElementById('order-search');
    if (searchInput) searchInput.value = normalizedQuery;
    ordersState.currentPage = 1;
    applyFilters();
}

function applyFilters() {
    let filtered = ordersState.allOrders;

    if (ordersState.currentTab !== 'all') {
        filtered = filtered.filter((order) => normalizeOrderStatus(order.status) === ordersState.currentTab);
    }

    if (ordersState.searchQuery) {
        filtered = filtered.filter((order) => {
            const matchId = String(order.id || '').toLowerCase().includes(ordersState.searchQuery);
            const prods = Array.isArray(order.products) ? order.products : [];
            const matchProducts = prods.some((product) => String(product.name || '').toLowerCase().includes(ordersState.searchQuery));
            return matchId || matchProducts;
        });
    }

    filtered.sort((a, b) => {
        const dateA = new Date(a.createdAt || 0);
        const dateB = new Date(b.createdAt || 0);
        return dateB - dateA;
    });

    ordersState.filteredOrders = filtered;
    renderOrders();
}

function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    const cleaned = String(text).replace(/\s*&\s*/g, ' và ');
    const div = document.createElement('div');
    div.textContent = cleaned;
    return div.innerHTML;
}

function renderOrders() {
    const container = document.getElementById('orders-list');

    if (ordersState.filteredOrders.length === 0) {
        showEmptyState('Không tìm thấy đơn hàng nào');
        return;
    }

    const startIndex = (ordersState.currentPage - 1) * ordersState.ordersPerPage;
    const endIndex = startIndex + ordersState.ordersPerPage;
    const ordersToShow = ordersState.filteredOrders.slice(startIndex, endIndex);

    container.innerHTML = ordersToShow.map((order) => createOrderCard(order)).join('');
    renderPagination();
}

function createOrderCard(order) {
    const orderId = order.id || order._id || '';
    const prods = Array.isArray(order.products) ? order.products : (Array.isArray(order.items) ? order.items : []);
    const firstProduct = prods.length > 0
        ? prods[0]
        : { name: 'Sản phẩm PawPal', image: '/assets/images/publics/feed.jpg', sku: '', quantity: 1, price: 0, total: 0 };
    const remainingCount = Math.max(0, prods.length - 1);
    const normalizedStatus = normalizeOrderStatus(order.status);

    const isPaid = order.paymentStatus === 'paid' || order.payment?.status === 'paid';
    const ONLINE_METHODS = ['vnpay', 'momo', 'zalopay', 'vietqr'];
    const payMethod = (order.paymentMethod || order.payment?.method || '').toLowerCase();
    const isOnline  = ONLINE_METHODS.includes(payMethod);

    const displayStatusLabel = getStatusLabel(normalizedStatus);
    const displayStatusClass = `status-${normalizedStatus}`;

    const isDelivered = normalizedStatus === 'delivered';
    const isCompleted = normalizedStatus === 'completed';
    const isReturned = normalizedStatus === 'returned';
    const productCount = Array.isArray(order.products)
        ? order.products.reduce((sum, product) => sum + (Number(product.quantity) || 1), 0)
        : 0;
    const paymentLabel = getPaymentMethodLabel(order.paymentMethod).replace(/\s*&\s*/g, ' và ');
    const orderAlreadyReviewed = (isDelivered || isCompleted) && ordersState.reviews.includes(String(orderId));

    const alreadyReturned = isReturned || ordersState.returns.includes(String(orderId));

    let actionButtonsHtml = '';

    // 1. Phản ánh / Khiếu nại đơn hàng (Tại Đã giao hoặc Hoàn thành)
    if (isDelivered || isCompleted) {
        actionButtonsHtml += `
            <a class="btn-order-action btn-action-complaint" href="#support-create?type=order&orderId=${encodeURIComponent(orderId)}" onclick="event.stopPropagation()" title="Gửi phản ánh hoặc khiếu nại về đơn hàng này">
                Phản ánh đơn
            </a>
        `;
    }

    // 2. Hủy đơn hàng (Chỉ cho phép khi đơn ở trạng thái Chờ xác nhận)
    if (normalizedStatus === 'pending') {
        actionButtonsHtml += `
            <button type="button" class="btn-order-action btn-action-cancel" onclick="event.stopPropagation(); cancelOrder('${escapeHtml(orderId)}')">
                Hủy đơn
            </button>
        `;
    }

    // 3. Đổi trả hàng:
    // - Nếu đã có yêu cầu / trạng thái trả hàng: hiển thị Chi tiết đổi trả
    // - Khách chỉ được tạo yêu cầu đổi/trả mới khi ở trạng thái Đã giao (trong thời hạn 7 ngày)
    if (alreadyReturned) {
        actionButtonsHtml += `
            <a href="#return-detail?orderId=${encodeURIComponent(orderId)}" class="btn-order-action btn-action-modify" onclick="event.stopPropagation()">
                Chi tiết đổi trả
            </a>
        `;
    } else if (isDelivered) {
        const deliveredEntry = Array.isArray(order.timeline)
            ? order.timeline.slice().reverse().find((timelineItem) => timelineItem.status === 'delivered')
            : null;
        const deliveredAt = deliveredEntry ? new Date(deliveredEntry.timestamp) : new Date(order.updatedAt || order.createdAt || 0);
        const daysPassed = (Date.now() - deliveredAt.getTime()) / (1000 * 60 * 60 * 24);
        const withinReturnWindow = daysPassed <= 7;

        if (withinReturnWindow && !orderAlreadyReviewed) {
            actionButtonsHtml += `
                <button type="button" class="btn-order-action btn-action-modify" onclick="event.stopPropagation(); openRMADrawer('${escapeHtml(orderId)}')">
                    Yêu cầu đổi trả
                </button>
            `;
        }
    }

    // 4. Đổi phương thức thanh toán (khi đơn Chờ xác nhận chưa thanh toán online)
    const canPayNow = normalizedStatus === 'pending' && !isPaid && isOnline;
    if (canPayNow) {
        actionButtonsHtml += `
            <button type="button" class="btn-order-action btn-action-modify" onclick="event.stopPropagation(); openChangePaymentMethodModal('${escapeHtml(orderId)}')">
                Đổi phương thức
            </button>
        `;
    }

    // 5. Liên hệ hotline
    actionButtonsHtml += `
        <button type="button" class="btn-order-action btn-action-hotline" onclick="event.stopPropagation(); contactHotline('${escapeHtml(orderId)}')">
            Liên hệ hotline
        </button>
    `;

    // 6. Đánh giá sản phẩm (tùy chọn hậu mãi tại Đã giao hoặc Hoàn thành)
    if (isDelivered || isCompleted) {
        if (!orderAlreadyReviewed) {
            actionButtonsHtml += `
                <a class="btn-order-action btn-action-review" href="#order-detail?id=${encodeURIComponent(orderId)}&section=reviews" onclick="event.stopPropagation()">
                    Đánh giá
                </a>
            `;
        } else {
            actionButtonsHtml += `<span class="badge-reviewed-9px">Đã đánh giá</span>`;
        }
    }

    // 7. Xác nhận nhận hàng sớm (khi shipper đã giao thành công)
    if (normalizedStatus === 'delivered') {
        actionButtonsHtml += `
            <button type="button" class="btn-order-action btn-action-primary" onclick="event.stopPropagation(); confirmOrderReceipt('${escapeHtml(orderId)}')">
                Đã nhận được hàng
            </button>
        `;
    }

    // 8. Primary Action: Thanh toán ngay (vàng hổ phách) hoặc Mua lại (vàng hổ phách)
    if (canPayNow) {
        actionButtonsHtml += `
            <button type="button" class="btn-order-action btn-action-primary" onclick="event.stopPropagation(); openOrderPaymentModal('${escapeHtml(orderId)}')">
                Thanh toán ngay
            </button>
        `;
    } else if (isCompleted) {
        actionButtonsHtml += `
            <button type="button" class="btn-order-action btn-action-primary" onclick="event.stopPropagation(); reorder('${escapeHtml(orderId)}')">
                Mua lại
            </button>
        `;
    }

    let statusNoticeHtml = '';
    if (normalizedStatus === 'pending' && !isPaid && isOnline && order.paymentExpiry) {
        statusNoticeHtml = `
            <div class="order-alert-note order-pending-countdown" data-expiry="${order.paymentExpiry}" data-order-id="${orderId}">
                ⏳ Thời gian thanh toán còn lại: <strong class="countdown-clock">--:--</strong>
            </div>
        `;
    }

    const detailUrl = `#order-detail?id=${encodeURIComponent(orderId)}`;

    return `
        <article class="order-card pawpal-smooth-entrance status-${normalizedStatus}" data-order-id="${orderId}">
            <div class="order-card-main-content" onclick="window.location.href='${detailUrl}'" role="link" tabindex="0">
                <div class="order-product-thumb-wrapper">
                    <img src="${firstProduct.image || '/assets/images/publics/feed.jpg'}" alt="${escapeHtml(firstProduct.name)}" class="order-product-thumb" loading="lazy" onerror="this.onerror=null; this.src='/assets/images/publics/feed.jpg';">
                </div>
                <div class="order-info-col">
                    <div class="order-title-row">
                        <span class="order-code">Mã: #${escapeHtml(orderId)}</span>
                        <span class="order-dot-sep">•</span>
                        <span class="order-date">${formatDate(order.createdAt)}</span>
                    </div>
                    <h4 class="order-product-name">${escapeHtml(firstProduct.name)}</h4>
                    <div class="order-meta-row">
                        <span class="order-meta-item">${productCount > 0 ? `${productCount} sản phẩm` : '1 sản phẩm'}${remainingCount > 0 ? ` (và ${remainingCount} sản phẩm khác)` : ''}</span>
                        <span class="order-dot-sep">•</span>
                        <span class="order-meta-item">${escapeHtml(paymentLabel)}</span>
                    </div>
                    ${statusNoticeHtml}
                </div>
                <div class="order-status-price-col">
                    <span class="order-badge-status ${displayStatusClass}">${displayStatusLabel}</span>
                    <span class="order-price-value">${formatCurrency(toNumber(order.pricing?.total ?? order.pricing?.grandTotal ?? order.total))}</span>
                </div>
            </div>
            ${actionButtonsHtml ? `
                <div class="order-card-footer-actions">
                    <div class="order-card-actions-group">
                        ${actionButtonsHtml}
                    </div>
                </div>
            ` : ''}
        </article>
    `;
}

function showEmptyState(message) {
    const container = document.getElementById('orders-list');
    container.innerHTML = `
        <div class="empty-state">
            <h4 class="empty-title">Chưa có đơn hàng nào</h4>
            <p class="empty-desc">${escapeHtml(message || 'Các đơn mua sắm vật phẩm và phụ kiện cho bé cưng sẽ hiển thị tại đây')}</p>
            <a href="/pages/shop/index.html" class="btn-order-primary-cta">+ Mua sắm cho bé ngay</a>
        </div>
    `;
    const pagination = document.getElementById('pagination');
    if (pagination) pagination.classList.add('d-none');
}

function renderPagination() {
    const totalPages = Math.ceil(ordersState.filteredOrders.length / ordersState.ordersPerPage);

    if (totalPages <= 1) {
        document.getElementById('pagination').classList.add('d-none');
        return;
    }

    document.getElementById('pagination').classList.remove('d-none');

    const prevBtn = document.getElementById('prev-page');
    const nextBtn = document.getElementById('next-page');
    const pageNumbers = document.getElementById('page-numbers');

    prevBtn.disabled = ordersState.currentPage === 1;
    nextBtn.disabled = ordersState.currentPage === totalPages;

    let pagesHTML = '';
    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= ordersState.currentPage - 1 && i <= ordersState.currentPage + 1)) {
            pagesHTML += `<button class="page-btn ${i === ordersState.currentPage ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
        } else if (i === ordersState.currentPage - 2 || i === ordersState.currentPage + 2) {
            pagesHTML += '<span>...</span>';
        }
    }

    pageNumbers.innerHTML = pagesHTML;
}

function goToPage(page) {
    ordersState.currentPage = page;
    renderOrders();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

window.goToPage = goToPage;

function contactHotline(orderId) {
    showOrdersToast(`Tổng đài hỗ trợ đơn hàng ${orderId}: 1900 1234`, 'info');
}

window.contactHotline = contactHotline;

function cancelOrder(orderId) {
    const order = ordersState.allOrders.find((item) => item.id === orderId);
    if (!order) {
        showOrdersToast('Không tìm thấy đơn hàng để hủy.', 'error');
        return;
    }

    const modalId = 'orders-cancel-modal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const el = document.createElement('div');
    el.id = modalId;
    el.className = 'modal fade';
    el.tabIndex = -1;
    el.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Xác nhận hủy đơn hàng</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Bạn có chắc chắn muốn hủy đơn hàng <strong>${orderId}</strong>?</p>
                    <p class="text-muted small">Đơn hàng sau khi hủy sẽ không thể khôi phục.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-green-outline" data-bs-dismiss="modal">Quay lại</button>
                    <button type="button" class="btn-danger-outline" id="orders-cancel-confirm">Xác nhận hủy</button>
                </div>
            </div>
        </div>`;
    document.body.appendChild(el);

    const modal = new bootstrap.Modal(el);
    modal.show();

    document.getElementById('orders-cancel-confirm').addEventListener('click', async () => {
        modal.hide();

        const db = window.SupabaseClient;

        if (Array.isArray(order.products)) {
            try {
                const storedProducts = JSON.parse(localStorage.getItem('pawpal_products') || '[]');
                if (storedProducts.length) {
                    order.products.forEach((item) => {
                        const idx = storedProducts.findIndex((product) => String(product.id) === String(item.id));
                        if (idx !== -1) {
                            storedProducts[idx].stock = (Number(storedProducts[idx].stock) || 0) + (Number(item.quantity) || 0);
                            storedProducts[idx].inStock = true;
                        }
                    });
                    localStorage.setItem('pawpal_products', JSON.stringify(storedProducts));
                }
            } catch (error) {
                console.warn('cancelOrder stock restore error:', error);
            }
        }

        // Hoàn lại điểm PawPoints nếu đơn hàng có sử dụng điểm
        const pointsDiscount = Number(order.pricing?.pointsDiscount || 0);
        if (pointsDiscount > 0) {
            try {
                const pointsToRefund = Math.round(pointsDiscount / 1000);
                const currentUser = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
                if (currentUser) {
                    currentUser.points = (Number(currentUser.points) || 0) + pointsToRefund;
                    localStorage.setItem('pawpal_current_user', JSON.stringify(currentUser));
                }
                const users = JSON.parse(localStorage.getItem('pawpal_users') || '[]');
                const uIdx = users.findIndex(u => String(u.id) === String(order.userId) || String(u.phone) === String(order.userPhone));
                if (uIdx !== -1) {
                    users[uIdx].points = (Number(users[uIdx].points) || 0) + pointsToRefund;
                    localStorage.setItem('pawpal_users', JSON.stringify(users));
                }
            } catch (err) {
                console.warn('Lỗi hoàn điểm khi hủy đơn:', err);
            }
        }

        // Hoàn lại Voucher nếu đơn hàng có sử dụng
        const voucherCode = order.voucherCode || order.pricing?.voucherCode || order.discount?.code;
        if (voucherCode) {
            try {
                const userVouchers = JSON.parse(localStorage.getItem('pawpal_user_vouchers') || '[]');
                const vIdx = userVouchers.findIndex(v => (v.code === voucherCode || v.id === voucherCode));
                if (vIdx !== -1) {
                    userVouchers[vIdx].isUsed = false;
                    userVouchers[vIdx].usedAt = null;
                    localStorage.setItem('pawpal_user_vouchers', JSON.stringify(userVouchers));
                }
            } catch (vErr) {
                console.warn('Lỗi khôi phục voucher khi hủy đơn:', vErr);
            }
        }

        const isPaid = order.paymentMethod && order.paymentMethod !== 'cod' && (order.paymentStatus === 'paid' || order.paymentStatus === 'da_thanh_toan');
        const newPaymentStatus = isPaid ? 'da_thanh_toan' : 'chua_thanh_toan';

        if (db) {
            try {
                const targetId = order._supabaseId || order.id || orderId;
                const isUUID = typeof targetId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(targetId);
                let query = db.from('sales_order').update({
                    order_status: 'da_huy',
                    payment_status: newPaymentStatus,
                    updated_at: new Date().toISOString()
                });
                query = isUUID ? query.eq('id', targetId) : query.eq('order_code', targetId);
                const { error: cancelErr } = await query;

                if (cancelErr) {
                    console.error('[Orders] Supabase cancel error:', cancelErr);
                    showOrdersToast(`Không thể hủy đơn hàng trên hệ thống: ${cancelErr.message || 'Lỗi CSDL'}`, 'error');
                    return;
                }
            } catch (err) {
                console.error('[Orders] Supabase cancel exception:', err);
                showOrdersToast(`Không thể hủy đơn hàng trên hệ thống: ${err.message || 'Lỗi kết nối'}`, 'error');
                return;
            }
        }

        if (isPaid) {
            const refunds = JSON.parse(localStorage.getItem('pawpal_refunds') || '[]');
            refunds.push({
                orderId: order.id,
                amount: order.pricing?.total || 0,
                paymentMethod: order.paymentMethod,
                status: 'pending_refund',
                createdAt: new Date().toISOString()
            });
            localStorage.setItem('pawpal_refunds', JSON.stringify(refunds));
        }

        order.status = 'cancelled';
        order.paymentStatus = isPaid ? 'pending_refund' : 'cancelled';
        order.updatedAt = new Date().toISOString();
        saveOrderToLocalStorage(order);

        const currentUser = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
        if (currentUser?.id && window.PawPalAPI?.createSystemNotification) {
            try {
                await window.PawPalAPI.createSystemNotification({
                    customerId: currentUser.id,
                    type: 'don_hang_da_duoc_huy',
                    title: 'Đã hủy đơn hàng',
                    content: `Bạn đã hủy thành công đơn hàng #${order.id || orderId}.`,
                    orderId: order._supabaseId || order.id || orderId
                });
            } catch (e) {
                console.warn('[Orders] Could not send cancel notification:', e);
            }
        }

        updateTabCounts();
        applyFilters();

        if (isPaid) {
            showOrdersToast(`Đơn hàng ${orderId} đã được hủy. Yêu cầu hoàn tiền đã ghi nhận và sẽ được xử lý trong 24-48 giờ.`, 'success');
        } else {
            showOrdersToast(`Đơn hàng ${orderId} đã được hủy thành công.`, 'success');
        }
    });
}

window.cancelOrder = cancelOrder;

function awardLoyaltyPointsForOrder(order) {
    if (!order || order.pointsAwarded) return;

    const user = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
    if (!user || user.is_temporary) return; // Khách vãng lai không có Paw Points

    const grandTotal = Number(
        order.pricing?.total ?? order.pricing?.grandTotal ?? order.total ?? 0
    );
    if (grandTotal <= 0) return;

    const pointsEarned = Math.floor(grandTotal / 1000);
    if (pointsEarned <= 0) return;

    try {
        const users = JSON.parse(localStorage.getItem('pawpal_users') || '[]');
        const idx = users.findIndex(u => String(u.id) === String(user.id) || String(u.phone) === String(user.phone));
        if (idx !== -1) {
            users[idx].points = (users[idx].points || 0) + pointsEarned;
            users[idx].spend = (users[idx].spend || 0) + grandTotal;
            users[idx].lastTransactionAt = new Date().toISOString();
            localStorage.setItem('pawpal_users', JSON.stringify(users));
        }

        user.points = (user.points || 0) + pointsEarned;
        user.spend = (user.spend || 0) + grandTotal;
        user.lastTransactionAt = new Date().toISOString();
        localStorage.setItem('pawpal_current_user', JSON.stringify(user));

        order.pointsAwarded = true;
        order.pointsEarned = pointsEarned;

        const headerPoints = document.getElementById('headerPoints');
        if (headerPoints) headerPoints.textContent = user.points + ' Paw Points';

        showOrdersToast(`Bạn nhận được +${pointsEarned} Paw Points từ đơn hàng hoàn thành!`, 'success');
    } catch (e) {
        console.warn('Lỗi tích điểm PawPoint cho đơn hàng:', e);
    }
}

function confirmOrderReceipt(orderId) {
    const order = ordersState.allOrders.find((item) => String(item.id) === String(orderId));
    if (!order) {
        showOrdersToast(`Không tìm thấy đơn hàng ${orderId} để xác nhận.`, 'error');
        return;
    }

    const nowISO = new Date().toISOString();
    const currentTimeline = Array.isArray(order.timeline) ? order.timeline : [];
    
    const updatedOrder = {
        ...order,
        status: 'completed',
        orderStatus: 'COMPLETED',
        updatedAt: nowISO,
        timeline: [
            ...currentTimeline,
            {
                status: 'completed',
                timestamp: nowISO,
                title: 'Hoàn thành',
                description: 'Khách hàng xác nhận đã nhận hàng'
            }
        ]
    };

    awardLoyaltyPointsForOrder(updatedOrder);
    saveOrderToLocalStorage(updatedOrder);
    if (window.API && typeof window.API.updateOrderStatus === 'function') {
        window.API.updateOrderStatus(updatedOrder.id, 'COMPLETED').catch((err) => {
            console.warn('[Orders] Failed to sync completed status:', err);
        });
    }
    ordersState.allOrders = ordersState.allOrders.map((item) =>
        String(item.id) === String(orderId) ? updatedOrder : item
    );
    applyFilters();
    updateStats();
    updateTabCounts();

    showOrdersToast(`Đã xác nhận đơn hàng ${orderId} thành công.`, 'success');
}

window.confirmOrderReceipt = confirmOrderReceipt;

function reorder(orderId) {
    const order = ordersState.allOrders.find((item) => String(item.id) === String(orderId));
    if (!order || !Array.isArray(order.products) || order.products.length === 0) {
        showOrdersToast(`Không tìm thấy sản phẩm để mua lại cho đơn hàng ${orderId}.`, 'error');
        return;
    }

    const cart = JSON.parse(localStorage.getItem('pawpal_cart') || '[]');
    order.products.forEach((product) => {
        const productId = product?.id == null ? '' : String(product.id);
        if (!productId) return;

        const quantity = Number(product.quantity || 1);
        const existing = cart.find((item) => String(item.id) === productId);
        if (existing) {
            existing.quantity = (Number(existing.quantity) || 1) + quantity;
            existing.qty = existing.quantity;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                brand: product.brand || '',
                price: Number(product.price || 0),
                quantity,
                image: product.image || '',
                stock: Number(product.stock || 99),
                category: product.category || null
            });
        }
    });

    if (window.saveCart) window.saveCart(cart); else localStorage.setItem('pawpal_cart', JSON.stringify(cart));
    if (typeof window.updateCartBadge === 'function') {
        window.updateCartBadge();
    } else {
        const badge = document.querySelector('.cart-count, .cart-badge');
        if (badge) badge.textContent = cart.length;
    }

    showOrdersToast(`Đã thêm các sản phẩm của đơn hàng ${orderId} vào giỏ hàng.`, 'success');
}

function hasReviewedOrder(order) {
    const reviewedList = JSON.parse(localStorage.getItem('pawpal_reviewed') || '[]');
    return reviewedList.some((item) => String(item.orderId) === String(order.id));
}

window.reorder = reorder;

function openQuickReviewModal(orderId) {
    const order = ordersState.allOrders.find((item) => String(item.id) === String(orderId));
    if (!order || !Array.isArray(order.products) || order.products.length === 0) {
        showOrdersToast('Không tìm thấy đơn hàng để đánh giá.', 'error');
        return;
    }

    const existing = document.getElementById('quickReviewModal');
    if (existing) existing.remove();

    const savedReviews = JSON.parse(localStorage.getItem('pawpal_reviews') || '[]');
    const savedByProduct = new Map(
        savedReviews
            .filter((item) => String(item.orderId) === String(order.id))
            .map((item) => [String(item.productId), item])
    );

    const productBlocks = order.products.map((product) => {
        const saved = savedByProduct.get(String(product.id)) || {};
        const rating = Number(saved.rating) || 5;
        const comment = saved.comment || '';
        const stars = [1, 2, 3, 4, 5].map((value) => `
            <button type="button" class="quick-review-star ${value <= rating ? 'active' : ''}" data-product-id="${product.id}" data-rating="${value}" aria-label="${value} sao">★</button>
        `).join('');

        return `
            <div class="quick-review-item" data-product-id="${product.id}">
                <div class="quick-review-product">
                    <img src="${product.image || '/assets/images/shop/products/placeholder.webp'}" alt="${product.name}" class="quick-review-thumb" loading="lazy">
                    <div>
                        <div class="quick-review-name">${product.name}</div>
                        <div class="quick-review-sub">Đánh giá sản phẩm này</div>
                    </div>
                </div>
                <div class="quick-review-stars">${stars}</div>
                <textarea class="quick-review-comment" rows="3" placeholder="Nhận xét về sản phẩm này...">${comment}</textarea>
            </div>
        `;
    }).join('');

    const el = document.createElement('div');
    el.id = 'quickReviewModal';
    el.className = 'modal fade';
    el.tabIndex = -1;
    el.innerHTML = `
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Đánh giá đơn hàng ${order.id}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted small mb-3">Chọn số sao và ghi nhận xét cho từng sản phẩm trong đơn. Bạn có thể bấm nút đánh giá ngay ở đây.</p>
                    <div class="quick-review-list">${productBlocks}</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-green-outline" data-bs-dismiss="modal">Để sau</button>
                    <button type="button" class="btn-cta" id="quickReviewSaveBtn">Lưu đánh giá</button>
                </div>
            </div>
        </div>`;
    document.body.appendChild(el);

    const modal = new bootstrap.Modal(el);
    modal.show();

    el.querySelectorAll('.quick-review-star').forEach((starBtn) => {
        starBtn.addEventListener('click', () => {
            const productId = String(starBtn.dataset.productId);
            const rating = Number(starBtn.dataset.rating);
            const item = el.querySelector(`.quick-review-item[data-product-id="${productId}"]`);
            if (!item) return;
            item.querySelectorAll('.quick-review-star').forEach((btn) => {
                btn.classList.toggle('active', Number(btn.dataset.rating) <= rating);
            });
        });
    });

    el.querySelector('#quickReviewSaveBtn').addEventListener('click', () => {
        const allReviews = JSON.parse(localStorage.getItem('pawpal_reviews') || '[]');
        const filtered = allReviews.filter((item) => String(item.orderId) !== String(order.id));
        const reviewedFlags = JSON.parse(localStorage.getItem('pawpal_reviewed') || '[]')
            .filter((item) => String(item.orderId) !== String(order.id));

        let hasAtLeastOneReview = false;
        el.querySelectorAll('.quick-review-item').forEach((itemEl) => {
            const productId = itemEl.dataset.productId;
            const activeStars = Array.from(itemEl.querySelectorAll('.quick-review-star.active'));
            const rating = activeStars.length ? Math.max(...activeStars.map((btn) => Number(btn.dataset.rating) || 0)) : 5;
            const comment = itemEl.querySelector('.quick-review-comment')?.value?.trim() || '';

            filtered.push({
                orderId: order.id,
                productId,
                productName: order.products.find((p) => String(p.id) === String(productId))?.name || '',
                rating,
                comment,
                createdAt: new Date().toISOString()
            });
            reviewedFlags.push({ orderId: order.id, productId, hasMedia: false });
            hasAtLeastOneReview = true;
        });

        localStorage.setItem('pawpal_reviews', JSON.stringify(filtered));
        localStorage.setItem('pawpal_reviewed', JSON.stringify(reviewedFlags));
        modal.hide();
        if (hasAtLeastOneReview) {
            showOrdersToast('Đã lưu đánh giá thành công.', 'success');
            applyFilters();
        }
    });
}

window.openQuickReviewModal = openQuickReviewModal;

function showOrdersToast(message, type = 'info') {
    let container = document.getElementById('orders-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'orders-toast-container';
        container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;';
        document.body.appendChild(container);
    }

    const colors = { success: '#2a5944', error: '#dc3545', info: '#0d6efd', warning: '#ffc107' };
    const toast = document.createElement('div');
    toast.style.cssText = `background:${colors[type] || colors.info};color:${type === 'warning' ? '#000' : '#fff'};padding:12px 18px;border-radius:8px;font-size:0.88rem;box-shadow:0 4px 12px rgba(0,0,0,.15);max-width:320px;`;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity .3s';
    }, 3000);
    setTimeout(() => toast.remove(), 3400);
}

function formatCurrency(amount) {
    const value = Number(amount);
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(Number.isFinite(value) ? value : 0);
}

function toNumber(value, fallback = 0) {
    const normalized = Number(value);
    return Number.isFinite(normalized) ? normalized : fallback;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

function saveOrderToLocalStorage(order) {
    const allOrders = JSON.parse(localStorage.getItem('pawpal_orders') || '[]');
    const index = allOrders.findIndex((item) => item.id === order.id);
    if (index !== -1) {
        allOrders[index] = order;
    } else {
        allOrders.push(order);
    }
    localStorage.setItem('pawpal_orders', JSON.stringify(allOrders));
}

function getPaymentMethodLabel(method) {
    const labels = {
        cod:           'Thanh toán khi nhận hàng (COD)',
        momo:          'Thanh toán MoMo',
        vnpay:         'VNPay',
        zalopay:       'ZaloPay',
        vietqr:        'VietQR',
        bank_transfer: 'Chuyển khoản ngân hàng',
        card:          'Thẻ ngân hàng',
        cash:          'Tiền mặt tại quầy',
        transfer:      'Chuyển khoản tại quầy'
    };
    return labels[method] || 'Thanh toán online';
}

async function openOrderPaymentModal(orderId) {
    const order = ordersState.allOrders.find(o => String(o.id) === String(orderId));
    if (!order) return;
    localStorage.setItem('pawpal_current_order', JSON.stringify(order));

    const payMethod = (order.paymentMethod || order.payment?.method || '').toLowerCase();
    if (payMethod === 'vnpay') {
        const grandTotal = order.pricing?.total || order.pricing?.grandTotal || 0;
        try {
            const vnpRes = await fetch('/api/vnpay/create-payment-url', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    orderId: order.id,
                    amount: grandTotal,
                    orderInfo: `Thanh toan don hang ${order.id} tai PawPal`
                })
            });
            const vnpData = await vnpRes.json();
            if (vnpData.success && vnpData.paymentUrl) {
                window.location.href = vnpData.paymentUrl;
                return;
            }
        } catch (err) {
            console.warn('[Orders] Lỗi tạo link VNPAY thật, fallback sang mô phỏng:', err);
        }
        window.location.href = `/pages/shop/vnpay-sandbox/vnpay-sandbox.html?orderId=${orderId}&amount=${grandTotal}`;
        return;
    }

    window.location.href = `#order-detail?id=${encodeURIComponent(orderId)}&pay=now`;
}
window.openOrderPaymentModal = openOrderPaymentModal;

function openChangePaymentMethodModal(orderId) {
    const order = ordersState.allOrders.find(o => String(o.id) === String(orderId));
    if (!order) return;

    const modalId = 'orders-change-payment-modal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const currentMethod = (order.paymentMethod || order.payment?.method || 'vnpay').toLowerCase();

    const el = document.createElement('div');
    el.id = modalId;
    el.className = 'modal fade';
    el.tabIndex = -1;
    el.innerHTML = `
        <div class="modal-dialog modal-dialog-centered" style="max-width: 480px;">
            <div class="modal-content" style="border-radius: 9px; border: 1px solid #ECF2EE;">
                <div class="modal-header" style="border-bottom: 1px solid #ECF2EE; padding: 18px 24px;">
                    <h5 class="modal-title" style="color: #236B48; font-weight: 700; font-size: 17px;">Đổi phương thức thanh toán</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" style="padding: 20px 24px;">
                    <p class="text-muted small mb-3">Đơn hàng <strong>#${order.id}</strong> đang chờ thanh toán. Vui lòng chọn phương thức bạn muốn chuyển đổi:</p>
                    <div class="d-flex flex-column gap-2 mb-3" id="paymentMethodRadioGroup">
                        <label class="d-flex align-items-center gap-3 p-3 rounded cursor-pointer" style="border: 1px solid ${currentMethod === 'cod' ? '#236B48' : '#ECF2EE'}; background: ${currentMethod === 'cod' ? '#F4FAF6' : '#fff'}; border-radius: 9px;">
                            <input type="radio" name="newPayMethod" value="cod" ${currentMethod === 'cod' ? 'checked' : ''} style="accent-color: #236B48;">
                            <div class="flex-grow-1">
                                <div class="fw-bold" style="color: #203A2C; font-size: 14px;">Thanh toán khi nhận hàng (COD)</div>
                                <div class="text-muted small">Trả tiền mặt cho shipper khi nhận hàng (Không lo hết hạn 15 phút)</div>
                            </div>
                        </label>
                        <label class="d-flex align-items-center gap-3 p-3 rounded cursor-pointer" style="border: 1px solid ${currentMethod === 'vnpay' ? '#236B48' : '#ECF2EE'}; background: ${currentMethod === 'vnpay' ? '#F4FAF6' : '#fff'}; border-radius: 9px;">
                            <input type="radio" name="newPayMethod" value="vnpay" ${currentMethod === 'vnpay' ? 'checked' : ''} style="accent-color: #236B48;">
                            <div class="flex-grow-1">
                                <div class="fw-bold" style="color: #203A2C; font-size: 14px;">Cổng thanh toán VNPay</div>
                                <div class="text-muted small">Quét QR VNPAY, Thẻ ATM nội địa, Thẻ Visa/Mastercard</div>
                            </div>
                        </label>
                        <label class="d-flex align-items-center gap-3 p-3 rounded cursor-pointer" style="border: 1px solid ${currentMethod === 'vietqr' ? '#236B48' : '#ECF2EE'}; background: ${currentMethod === 'vietqr' ? '#F4FAF6' : '#fff'}; border-radius: 9px;">
                            <input type="radio" name="newPayMethod" value="vietqr" ${currentMethod === 'vietqr' ? 'checked' : ''} style="accent-color: #236B48;">
                            <div class="flex-grow-1">
                                <div class="fw-bold" style="color: #203A2C; font-size: 14px;">Quét mã VietQR</div>
                                <div class="text-muted small">Mở app ngân hàng quét mã QR chuyển khoản tức thì</div>
                            </div>
                        </label>
                        <label class="d-flex align-items-center gap-3 p-3 rounded cursor-pointer" style="border: 1px solid ${currentMethod === 'momo' ? '#236B48' : '#ECF2EE'}; background: ${currentMethod === 'momo' ? '#F4FAF6' : '#fff'}; border-radius: 9px;">
                            <input type="radio" name="newPayMethod" value="momo" ${currentMethod === 'momo' ? 'checked' : ''} style="accent-color: #236B48;">
                            <div class="flex-grow-1">
                                <div class="fw-bold" style="color: #203A2C; font-size: 14px;">Ví điện tử MoMo</div>
                                <div class="text-muted small">Quét mã bằng ứng dụng ví MoMo</div>
                            </div>
                        </label>
                        <label class="d-flex align-items-center gap-3 p-3 rounded cursor-pointer" style="border: 1px solid ${currentMethod === 'zalopay' ? '#236B48' : '#ECF2EE'}; background: ${currentMethod === 'zalopay' ? '#F4FAF6' : '#fff'}; border-radius: 9px;">
                            <input type="radio" name="newPayMethod" value="zalopay" ${currentMethod === 'zalopay' ? 'checked' : ''} style="accent-color: #236B48;">
                            <div class="flex-grow-1">
                                <div class="fw-bold" style="color: #203A2C; font-size: 14px;">Ví điện tử ZaloPay</div>
                                <div class="text-muted small">Quét mã bằng ứng dụng Zalo / ZaloPay</div>
                            </div>
                        </label>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid #ECF2EE; padding: 14px 24px;">
                    <button type="button" class="btn-green-outline" data-bs-dismiss="modal">Đóng</button>
                    <button type="button" class="btn-cta" id="btn-confirm-change-payment">Xác nhận đổi</button>
                </div>
            </div>
        </div>`;
    document.body.appendChild(el);

    const modal = new bootstrap.Modal(el);
    modal.show();

    const radios = el.querySelectorAll('input[name="newPayMethod"]');
    radios.forEach(r => {
        r.addEventListener('change', () => {
            el.querySelectorAll('#paymentMethodRadioGroup label').forEach(lbl => {
                lbl.style.borderColor = '#ECF2EE';
                lbl.style.backgroundColor = '#fff';
            });
            const parent = r.closest('label');
            if (parent) {
                parent.style.borderColor = '#236B48';
                parent.style.backgroundColor = '#F4FAF6';
            }
        });
    });

    document.getElementById('btn-confirm-change-payment').addEventListener('click', async () => {
        const selectedRadio = el.querySelector('input[name="newPayMethod"]:checked');
        if (!selectedRadio) return;
        const newMethod = selectedRadio.value;
        modal.hide();

        const methodNames = {
            cod: 'Thanh toán khi nhận hàng (COD)',
            vnpay: 'Cổng thanh toán VNPay',
            vietqr: 'Quét mã VietQR',
            momo: 'Ví MoMo',
            zalopay: 'Ví ZaloPay'
        };

        order.paymentMethod = newMethod;
        if (!order.payment) order.payment = {};
        order.payment.method = newMethod;

        if (!Array.isArray(order.timeline)) order.timeline = [];

        if (newMethod === 'cod') {
            order.status = 'pending';
            order.paymentStatus = 'pending_payment';
            order.paymentExpiry = null;
            order.timeline.push({
                status: 'pending',
                title: 'Đổi phương thức thanh toán sang COD',
                description: 'Khách hàng đã đổi sang Thanh toán khi nhận hàng (COD). Đơn hàng đang chờ cửa hàng xác nhận.',
                timestamp: new Date().toISOString()
            });
        } else {
            order.timeline.push({
                status: 'pending_payment',
                title: `Đổi phương thức thanh toán sang ${methodNames[newMethod] || newMethod}`,
                description: `Khách hàng đã đổi phương thức thanh toán sang ${methodNames[newMethod] || newMethod}.`,
                timestamp: new Date().toISOString()
            });
        }

        order.updatedAt = new Date().toISOString();
        saveOrderToLocalStorage(order);

        const db = window.SupabaseClient;
        if (db) {
            try {
                await db.from('sales_order').update({
                    order_status: 'cho_xac_nhan',
                    updated_at: new Date().toISOString()
                }).eq('id', order.id);
            } catch (err) {
                console.warn('[Orders] Supabase update payment method error:', err);
            }
        }

        updateTabCounts();
        applyFilters();

        showOrdersToast(`Đã đổi phương thức thanh toán sang "${methodNames[newMethod]}" thành công!`, 'success');

        if (newMethod !== 'cod') {
            setTimeout(() => {
                openOrderPaymentModal(order.id);
            }, 600);
        }
    });
}
window.openChangePaymentMethodModal = openChangePaymentMethodModal;

let isInitRunning = false;

export async function initOrders() {
    if (isInitRunning) return;
    isInitRunning = true;
    try {
        const user = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
        const client = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        stopOrdersRealtime = watchCustomerTables(client, user?.id, ['sales_order', 'return_request', 'review'], loadOrders);
        if (typeof window.setUserSubBreadcrumb === 'function') {
            window.setUserSubBreadcrumb('', 'orders');
        }

        // Kiểm tra tab ban đầu từ URL parameter (ví dụ ?status=pending_payment hoặc ?tab=pending_payment)
        const urlParams = new URLSearchParams(window.location.hash.split('?')[1] || window.location.search);
        const initialStatus = urlParams.get('status') || urlParams.get('tab');
        if (initialStatus) {
            ordersState.currentTab = initialStatus;
            const targetTab = document.querySelector(`.order-filter-tab[data-status="${initialStatus}"], .tab-btn[data-status="${initialStatus}"]`);
            if (targetTab) {
                document.querySelectorAll('.order-filter-tab, .tab-btn').forEach((item) => {
                    item.classList.remove('active');
                    item.setAttribute('aria-selected', 'false');
                });
                targetTab.classList.add('active');
                targetTab.setAttribute('aria-selected', 'true');
            }
        }

        await loadOrders();

        document.querySelectorAll('.order-filter-tab, .tab-btn').forEach((button) => {
            button.addEventListener('click', (event) => {
                document.querySelectorAll('.order-filter-tab, .tab-btn').forEach((item) => {
                    item.classList.remove('active');
                    item.setAttribute('aria-selected', 'false');
                });
                event.currentTarget.classList.add('active');
                event.currentTarget.setAttribute('aria-selected', 'true');
                filterByStatus(event.currentTarget.dataset.status);
            });
        });

        const searchInput = document.getElementById('order-search');
        const searchBtn = document.getElementById('search-btn');

        if (searchBtn && searchInput) {
            searchBtn.addEventListener('click', () => {
                searchOrders(searchInput.value);
            });

            searchInput.addEventListener('keypress', (event) => {
                if (event.key === 'Enter') {
                    searchOrders(searchInput.value);
                }
            });
        }

        const prevBtn = document.getElementById('prev-page');
        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (ordersState.currentPage > 1) goToPage(ordersState.currentPage - 1);
            });
        }

        const nextBtn = document.getElementById('next-page');
        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                const totalPages = Math.ceil(ordersState.filteredOrders.length / ordersState.ordersPerPage);
                if (ordersState.currentPage < totalPages) goToPage(ordersState.currentPage + 1);
            });
        }
    } finally {
        isInitRunning = false;
    }
}

export const init = initOrders;
window.initOrders = initOrders;

