import { normalizeOrderStatus } from '/scripts/shared/order-status.mjs';
import { resolveAuthenticatedCustomerId } from '/scripts/shared/customer-identity.mjs';
import { normalizeCartItems, publishCart } from '/scripts/shared/cart-state.mjs';

let cartWriteQueue = Promise.resolve();
function queueCartWrite(task) {
    const result = cartWriteQueue.then(() => typeof navigator !== 'undefined' && navigator.locks
        ? navigator.locks.request('pawpal-cart-write', task)
        : task());
    cartWriteQueue = result.catch(() => {});
    return result;
}

function assertCartOwner(userId) {
    const user = JSON.parse(localStorage.getItem('pawpal_current_user') || 'null');
    if (!userId || user?.id !== userId) throw new Error('Tài khoản đã thay đổi. Vui lòng tải lại giỏ hàng.');
}

const resolveCustomerId = resolveAuthenticatedCustomerId;

export const API = {
    DATA_VERSION: '2026-07-04-v14-guest-data',

    async getJSON(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error(`[API] Cannot load ${url}:`, error);
            return null;
        }
    },

    async request(path, options = {}) {
        if (!this.USE_BACKEND) return null;
        try {
            const response = await fetch(`${this.getBaseUrl()}${path}`, {
                headers: {
                    'Content-Type': 'application/json',
                    ...(options.headers || {})
                },
                ...options
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error(`[API] request failed: ${path}`, error);
            return null;
        }
    },

    async initData() {
    },

    async getUserPets(userOrId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !userOrId) return [];
        try {
            const customerId = await resolveCustomerId(db, userOrId);
            if (!customerId) return [];

            const { data, error } = await db
                .from('pet_profile')
                .select('*')
                .eq('customer_id', customerId);
            
            if (error) {
                console.error('[API] Supabase getUserPets error:', error.message);
                return [];
            }
            return (data || []).map(p => ({
                id: p.id,
                name: p.pet_name,
                type: p.pet_type,
                breed: p.breed,
                age: p.age,
                weight: p.weight,
                gender: p.gender,
                note: p.note,
                image: p.avatar_url || '/assets/images/placeholder.webp'
            }));
        } catch (err) {
            console.error('[API] Supabase getUserPets failed:', err);
            return [];
        }
    },

    async getUserBookings(userOrId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !userOrId) throw new Error('Vui lòng đăng nhập để tải dữ liệu.');
        try {
            const customerId = await resolveCustomerId(db, userOrId);
            if (!customerId) return [];

            const { data, error } = await db
                .from('appointment')
                .select(`
                    id, appointment_code, appointment_date, appointment_time,
                    appointment_status, payment_status, note, change_count, total_price,
                    service ( 
                        service_name, service_category, estimated_duration,
                        service_price_matrix ( unit_price )
                    ),
                    pet_profile ( id, pet_code, pet_name, breed, species, avatar_url )
                `)
                .eq('customer_id', customerId)
                .order('appointment_date', { ascending: false });
                
            if (error) {
                console.error('[API] Supabase getUserBookings error:', error.message);
                throw error;
            }

            const mapAppointmentStatus = (status) => {
                if (!status) return 'upcoming';
                const s = String(status).toLowerCase().trim();
                if (['dang_giu_cho', 'tam_giu'].includes(s)) return 'pending';
                if (['cho_xac_nhan', 'pending'].includes(s)) return 'pending';
                if (['da_xac_nhan', 'confirmed', 'upcoming'].includes(s)) return 'confirmed';
                if (['da_check_in', 'accepted'].includes(s)) return 'accepted';
                if (['dang_thuc_hien', 'in_progress', 'in-progress'].includes(s)) return 'in-progress';
                if (['da_hoan_tat', 'completed', 'done'].includes(s)) return 'completed';
                if (['da_huy', 'cancelled'].includes(s)) return 'cancelled';
                if (['da_het_han', 'expired'].includes(s)) return 'cancelled';
                if (['vang_mat', 'no_show'].includes(s)) return 'cancelled';
                return 'upcoming';
            };

            const getPriceFromMatrix = (matrix, species) => {
                if (!matrix || !Array.isArray(matrix)) return 0;
                if (!species) species = 'other';
                const row = matrix.find(m => m.pet_species?.toLowerCase() === species.toLowerCase());
                if (row) return row.unit_price;
                return matrix[0]?.unit_price || 0;
            };

            return (data || []).map(b => {
                const srv = Array.isArray(b.service) ? b.service[0] : b.service;
                const pet = Array.isArray(b.pet_profile) ? b.pet_profile[0] : b.pet_profile;

                return {
                    id:              b.appointment_code || b.id,
                    _supabaseId:     b.id,
                    userId:          customerId,
                    date:            b.appointment_date,
                    time:            b.appointment_time?.slice(0, 5) || '',
                    timeStart:       b.appointment_time?.slice(0, 5) || '',
                    status:          mapAppointmentStatus(b.appointment_status),
                    bookingStatus:   b.appointment_status,
                    paymentStatus:   b.payment_status,
                    service:         srv?.service_name      || '',
                    serviceName:     srv?.service_name      || '',
                    serviceCategory: srv?.service_category  || '',
                    petId:           pet?.pet_code      || pet?.id || '',
                    petName:         pet?.pet_name      || '',
                    petBreed:        pet?.breed         || '',
                    petSpecies:      pet?.species       || '',
                    petAvatar:       pet?.avatar_url    || '',
                    changeCount:     b.change_count     || 0,
                    note:            b.note             || '',
                    price:           b.total_price      || getPriceFromMatrix(srv?.service_price_matrix, pet?.species) || 0,
                    _source:         'supabase'
                };
            });
        } catch (err) {
            console.error('[API] Supabase getUserBookings failed:', err);
                throw err;
        }
    },

    async getUserAppointments(userOrId) {
        return this.getUserBookings(userOrId);
    },

    async getUserOrders(userOrId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !userOrId) throw new Error('Vui lòng đăng nhập để tải dữ liệu.');
        try {
            const customerId = await resolveCustomerId(db, userOrId);
            if (!customerId) return [];

            const { data, error } = await db
                .from('sales_order')
                .select(`
                    id, order_code, order_status, payment_status,
                    total_amount,
                    created_at, updated_at, note,
                    sales_order_detail (
                        id, quantity, unit_price, discount_amount, subtotal, product_variant_id,
                        product_variant ( id, sku_variant, sale_price, product ( id, product_name, image_urls ) )
                    ),
                    customer_address ( receiver_name, receiver_phone, province, street_address )
                `)
                .eq('customer_id', customerId)
                .order('created_at', { ascending: false });

            if (error) { 
                console.error('[API] Supabase getUserOrders error:', error.message);
                throw error;
            }

            const normalizeImageUrl = (url) => {
                if (!url) return '';
                if (!url.startsWith('http') && !url.startsWith('/')) return '/' + url;
                return url;
            };

            const mapOrderStatus = normalizeOrderStatus;

            const orders = (data || []).map(o => {
                const details = o.sales_order_detail || [];
                const products = details.map(d => {
                    const pv = d.product_variant || {};
                    const pr = pv.product || d.product || {};
                    return {
                        id:       pr.id || '',
                        variant_id: d.product_variant_id || pv.id,
                        name:     pr.product_name || 'Sản phẩm',
                        sku:      pv.sku_variant || pr.sku || '',
                        image:    normalizeImageUrl(pr.image_urls?.[0]),
                        quantity: d.quantity,
                        price:    d.unit_price,
                        total:    d.subtotal,
                    };
                });
                const addr = o.customer_address;
                const calculatedSubtotal = products.reduce((sum, p) => sum + (p.total || (p.price * p.quantity)), 0);
                const discount = 0;
                const shippingFee = Math.max(0, (o.total_amount || 0) - calculatedSubtotal + discount);
                
                return {
                    id:          o.order_code || o.id,
                    _supabaseId: o.id,
                    userId:      customerId,
                    status:      mapOrderStatus(o.order_status),
                    orderStatus: o.order_status,
                    paymentStatus: (o.payment_status || '').toLowerCase(),
                    paymentMethod: 'cod',
                    products,
                    pricing: {
                        subtotal:    calculatedSubtotal,
                        shippingFee: shippingFee,
                        discount:    discount,
                        total:       o.total_amount,
                    },
                    shipping: addr ? {
                        name:    addr.receiver_name  || '',
                        phone:   addr.receiver_phone || '',
                        address: [addr.street_address, addr.province].filter(Boolean).join(', '),
                    } : {},
                    note:      o.note || '',
                    createdAt: o.created_at,
                    updatedAt: o.updated_at,
                    _source:   'supabase',
                };
            });
            return orders;
        } catch (err) {
            console.error('[API] Supabase getUserOrders failed:', err);
                throw err;
        }
    },

    async getUserReviews(userOrId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !userOrId) return [];
        try {
            const customerId = await resolveCustomerId(db, userOrId);
            if (!customerId) return [];

            const { data, error } = await db.from('review').select('*').eq('customer_id', customerId);
            if (error) { 
                console.error('[API] Supabase getUserReviews error:', error.message); 
                return []; 
            }
            return data || [];
        } catch (err) {
            console.error('[API] Supabase getUserReviews failed:', err);
            return [];
        }
    },

    async getUserVouchers(userOrId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !userOrId) return [];
        try {
            const customerId = await resolveCustomerId(db, userOrId);
            if (!customerId) return [];

            const { data, error } = await db.from('customer_voucher')
                .select(`
                    id, 
                    voucher_status, 
                    used_at,
                    voucher ( id, voucher_code, discount_value, type, minimum_order_amount, start_date, end_date, description )
                `)
                .eq('customer_id', customerId);
            if (error) { 
                console.error('[API] Supabase getUserVouchers error:', error.message); 
                return []; 
            }
            
            return (data || []).map(row => {
                const v = row.voucher || {};
                return {
                    id: row.id,
                    voucherId: v.id,
                    code: v.voucher_code,
                    discountAmount: v.discount_value,
                    discountType: v.type,
                    type: String(v.type || 'percentage').toLowerCase() === 'percent' ? 'percentage' : String(v.type || 'percentage').toLowerCase(),
                    value: Number(v.discount_value || 0),
                    maxDiscount: v.max_discount || null,
                    minOrderValue: Number(v.minimum_order_amount || 0),
                    minOrderAmount: v.minimum_order_amount,
                    validFrom: v.start_date,
                    validUntil: v.end_date,
                    validTo: v.end_date,
                    usageCount: Number(v.usage_count || 0),
                    maxUsage: v.max_usage,
                    applicableFor: v.applicable_for || ['all'],
                    active: !row.voucher_status || row.voucher_status.toUpperCase() !== 'USED',
                    description: v.description,
                    isUsed: row.voucher_status === 'USED' || row.voucher_status === 'used',
                    usedAt: row.used_at
                };
            });
        } catch (err) {
            console.error('[API] Supabase getUserVouchers failed:', err);
            return [];
        }
    },

    async getCareLogs() {
        const careLogs = await this.request('/api/care-logs');
        if (careLogs && typeof careLogs === 'object') return careLogs;
        return safeReadObject('pawpal_pet_tracker_logs') || {};
    },

    async getUserCart(userId, { waitForWrites = true } = {}) {
        if (!userId) return [];
        assertCartOwner(userId);
        if (waitForWrites) await cartWriteQueue;
        assertCartOwner(userId);
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) throw new Error('Chưa kết nối được giỏ hàng.');

        try {
            const { data: cartData, error: cartError } = await db.from('cart').select('id').eq('customer_id', userId).maybeSingle();
            if (cartError) throw cartError;
            if (!cartData) return publishCart([], userId);

            const { data: items, error: itemsError } = await db.from('cart_item')
                .select('id, product_variant_id, quantity, unit_price, subtotal, product_variant(id, product_id, sku_variant, sale_price, product(id, product_name, brand_name, image_urls))')
                .eq('cart_id', cartData.id);
            if (itemsError) throw itemsError;
            let cached = [];
            try { if (localStorage.getItem('pawpal_cart_owner') === String(userId)) cached = JSON.parse(localStorage.getItem('pawpal_cart') || '[]'); } catch {}
            return publishCart((items || []).map(item => {
                const prod = item.product_variant?.product || {};
                const prodId = prod.id || item.product_variant_id || item.product_id || item.id;
                const cachedItem = Array.isArray(cached) ? cached.find(c => String(c.id) === String(prodId) || String(c.id) === String(item.product_variant_id) || String(c.variantId) === String(item.product_variant_id)) : null;
                return {
                    ...(cachedItem || {}),
                    id: prodId,
                    variantId: item.product_variant_id || prodId,
                    product_variant_id: item.product_variant_id || prodId,
                    name: prod.product_name || cachedItem?.name || 'Sản phẩm',
                    sku: item.product_variant?.sku_variant || cachedItem?.sku || '',
                    quantity: Number(item.quantity),
                    qty: Number(item.quantity),
                    price: Number(item.unit_price) || Number(item.product_variant?.sale_price) || 0,
                    subtotal: Number(item.subtotal) || ((Number(item.unit_price) || 0) * Number(item.quantity))
                };
            }), userId);
        } catch (err) {
            throw err;
        }
    },

    async getOrCreateCart(userId) {
        if (!userId) return null;
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) throw new Error('Chưa kết nối được giỏ hàng.');

        let { data: cartData, error: readError } = await db.from('cart').select('id').eq('customer_id', userId).maybeSingle();
        if (readError) throw readError;
        if (!cartData) {
            const { data: newCart, error } = await db.from('cart').insert({ customer_id: userId, cart_status: 'ACTIVE' }).select('id').single();
            if (error) throw error;
            cartData = newCart;
        }
        return cartData;
    },

    async saveUserCart(userId, cartItems) {
        const snapshot = normalizeCartItems(cartItems);
        return queueCartWrite(() => this.persistUserCart(userId, snapshot));
    },

    async validateCartStock(cartItems) {
        const items = normalizeCartItems(cartItems);
        if (!items.length) return { valid: true };
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) throw new Error('Không thể kiểm tra tồn kho. Vui lòng thử lại.');
        const rawIds = items.map(item => item.variantId || item.product_variant_id || item.id).filter(Boolean);
        if (!rawIds.length) return { valid: true };
        const idList = rawIds.map(id => `"${id}"`).join(',');
        const { data: variants } = await db.from('product_variant').select('id, product_id').or(`id.in.(${idList}),product_id.in.(${idList})`);
        const variantIdMap = new Map();
        for (const v of variants || []) {
            variantIdMap.set(String(v.id), v.id);
            variantIdMap.set(String(v.product_id), v.id);
        }
        const vIds = [...new Set(items.map(i => variantIdMap.get(String(i.variantId || i.product_variant_id || i.id))).filter(Boolean))];
        if (vIds.length) {
            const { data: invData, error } = await db.from('inventory').select('product_variant_id, quantity_in_stock').in('product_variant_id', vIds);
            if (error) throw new Error('Không thể kiểm tra tồn kho. Vui lòng thử lại.');
            const stockByVariant = new Map();
            for (const row of invData || []) {
                const count = Number(row.quantity_in_stock);
                if (Number.isSafeInteger(count) && count >= 0) {
                    stockByVariant.set(String(row.product_variant_id), (stockByVariant.get(String(row.product_variant_id)) || 0) + count);
                }
            }
            for (const item of items) {
                const resolvedVId = variantIdMap.get(String(item.variantId || item.product_variant_id || item.id));
                const remaining = resolvedVId ? (stockByVariant.get(String(resolvedVId)) ?? 999) : 999;
                if (item.quantity > remaining) throw new Error(`Chỉ còn ${remaining} sản phẩm trong kho`);
            }
        }
        return { valid: true };
    },

    async prepareCartCheckout(userId, selectedItems) {
        const requested = normalizeCartItems(selectedItems);
        return queueCartWrite(async () => {
            const current = await this.getUserCart(userId, { waitForWrites: false });
            const selected = current.filter(item => requested.some(entry => entry.id === String(item.id)));
            if (!selected.length || selected.length !== requested.length) throw new Error('Giỏ hàng đã thay đổi. Vui lòng chọn lại sản phẩm.');
            await this.validateCartStock(selected);
            return selected;
        });
    },

    async restoreCartBackup(userId, backupItems, { mode = 'add', token = JSON.stringify(backupItems) } = {}) {
        const backup = normalizeCartItems(backupItems);
        return queueCartWrite(async () => {
            const current = await this.getUserCart(userId, { waitForWrites: false });
            const key = `pawpal_cart_restore_${userId}`;
            const payload = JSON.stringify(backup);
            const previous = JSON.parse(localStorage.getItem(key) || 'null');
            if (previous?.token === token && previous.payload === payload && previous.status === 'applied') return current;
            let merged;
            if (previous?.token === token && previous.payload === payload && previous.status === 'prepared') {
                // A prior request may have committed before its response was lost.
                merged = normalizeCartItems([...current]);
                for (const target of previous.target) {
                    const item = merged.find(entry => entry.id === target.id);
                    if (item) { item.quantity = Math.max(item.quantity, target.quantity); item.qty = item.quantity; }
                    else merged.push(target);
                }
            } else {
                const additions = mode === 'included'
                    ? backup.filter(item => !current.some(entry => String(entry.id) === item.id))
                    : backup;
                merged = normalizeCartItems([...current, ...additions]);
            }
            const journal = { token, payload, target: merged, status: 'prepared' };
            localStorage.setItem(key, JSON.stringify(journal));
            // Restoring a saved cart does not purchase items or reserve stock.
            if (JSON.stringify(merged) !== JSON.stringify(current)) await this.persistUserCart(userId, merged, { checkStock: false });
            journal.status = 'applied';
            localStorage.setItem(key, JSON.stringify(journal));
            return merged;
        });
    },

    async removePurchasedCartItems(userId, purchasedItems) {
        const purchased = normalizeCartItems(purchasedItems);
        return queueCartWrite(async () => {
            const current = await this.getUserCart(userId, { waitForWrites: false });
            const remaining = current.map(item => {
                const quantity = item.quantity - (purchased.find(entry => entry.id === String(item.id))?.quantity || 0);
                return { ...item, quantity, qty: quantity };
            }).filter(item => item.quantity > 0);
            await this.persistUserCart(userId, remaining, { checkStock: false });
            return { success: true };
        });
    },

    async persistUserCart(userId, items, { checkStock = true } = {}) {
        if (!userId) { publishCart(items); return { success: true }; }
        assertCartOwner(userId);
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) throw new Error('Cart database unavailable');
        if (checkStock) await this.validateCartStock(items);
        const cart = await this.getOrCreateCart(userId);
        if (!cart) throw new Error('Cart unavailable');
        const { data: existing, error: readError } = await db.from('cart_item')
            .select('id, product_variant_id, quantity').eq('cart_id', cart.id);
        if (readError) throw readError;

        const rawIds = items.map(item => item.variantId || item.product_variant_id || item.id).filter(Boolean);
        let variantMap = new Map();
        if (rawIds.length) {
            const idList = rawIds.map(id => `"${id}"`).join(',');
            const { data: vRows } = await db.from('product_variant').select('id, product_id').or(`id.in.(${idList}),product_id.in.(${idList})`);
            for (const v of vRows || []) {
                variantMap.set(String(v.id), v.id);
                variantMap.set(String(v.product_id), v.id);
            }
        }

        const keep = new Set();
        for (const item of items) {
            const resolvedVId = variantMap.get(String(item.variantId || item.product_variant_id || item.id)) || item.variantId || item.product_variant_id || item.id;
            const price = Number(item.price) || 0;
            const values = { quantity: item.quantity, unit_price: price, subtotal: price * item.quantity, product_variant_id: resolvedVId };
            const current = (existing || []).find(row => String(row.product_variant_id) === String(resolvedVId));
            const query = current
                ? db.from('cart_item').update({ quantity: values.quantity, unit_price: values.unit_price, subtotal: values.subtotal }).eq('cart_id', cart.id).eq('id', current.id)
                : db.from('cart_item').insert({ ...values, cart_id: cart.id });
            const { data, error } = await query.select('id');
            if (error) throw error;
            if (!data?.length) throw new Error('Cart write was not applied');
            keep.add(data[0].id);
        }
        const removals = (existing || []).filter(row => !keep.has(row.id)).map(row => row.id);
        if (removals.length) {
            const { data, error } = await db.from('cart_item').delete()
                .eq('cart_id', cart.id).in('id', removals).select('id');
            if (error) throw error;
            if (data?.length !== removals.length) throw new Error('Cart deletion was not applied');
        }
        publishCart(items, userId);
        return { success: true };
    },

    async addToCart(userId, productId, quantity = 1, details = {}) {
        if (!userId) return { success: false, error: 'User not logged in' };
        if (!Number.isSafeInteger(Number(quantity)) || Number(quantity) < 1) throw new Error('Invalid quantity');
        return queueCartWrite(async () => {
            const items = await this.getUserCart(userId, { waitForWrites: false });
            const existing = items.find(item => String(item.id) === String(productId));
            if (existing) {
                const nextQuantity = existing.quantity + Number(quantity);
                Object.assign(existing, details, { id: String(productId), quantity: nextQuantity, qty: nextQuantity });
            }
            else items.push({ ...details, id: String(productId), quantity: Number(quantity), qty: Number(quantity) });
            return this.persistUserCart(userId, normalizeCartItems(items));
        });
    },

    async adjustCartQuantity(userId, productId, delta) {
        if (!Number.isSafeInteger(delta) || !delta) throw new Error('Số lượng không hợp lệ.');
        return queueCartWrite(async () => {
            const items = await this.getUserCart(userId, { waitForWrites: false });
            const item = items.find(entry => String(entry.id) === String(productId));
            if (!item) throw new Error('Sản phẩm đã được xóa khỏi giỏ hàng.');
            item.quantity += delta;
            item.qty = item.quantity;
            return this.persistUserCart(userId, normalizeCartItems(items));
        });
    },

    async removeCartProduct(userId, productId) {
        return queueCartWrite(async () => {
            const items = await this.getUserCart(userId, { waitForWrites: false });
            return this.persistUserCart(userId, items.filter(item => String(item.id) !== String(productId)), { checkStock: false });
        });
    },

    async updateCartItemQuantity(userId, variantOrProductId, quantity) {
        if (!userId) return { success: false, error: 'User not logged in' };
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        const cart = await this.getOrCreateCart(userId);
        if (!cart) return { success: false };

        if (quantity <= 0) return this.removeFromCart(userId, variantOrProductId);

        const { error } = await db.from('cart_item')
            .update({ quantity })
            .eq('cart_id', cart.id).or(`product_variant_id.eq.${variantOrProductId},id.eq.${variantOrProductId}`);
        return { success: !error, error };
    },

    async removeFromCart(userId, variantOrProductId) {
        if (!userId) return { success: false, error: 'User not logged in' };
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        const cart = await this.getOrCreateCart(userId);
        if (!cart) return { success: false };

        const { error } = await db.from('cart_item').delete().eq('cart_id', cart.id).or(`product_variant_id.eq.${variantOrProductId},id.eq.${variantOrProductId}`);
        return { success: !error, error };
    },

    async clearCart(userId) {
        if (!userId) return { success: false };
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        const cart = await this.getOrCreateCart(userId);
        if (!cart) return { success: false };

        const { error } = await db.from('cart_item').delete().eq('cart_id', cart.id);
        return { success: !error, error };
    },

    async getUserWishlist(userId, { strict = false } = {}) {
        if (!userId) return { productIds: [], serviceIds: [] };
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) {
            if (strict) throw new Error('Chưa kết nối được dữ liệu yêu thích.');
            return { productIds: [], serviceIds: [] };
        }

        try {
            const { data: wl, error: readError } = await db.from('wishlist').select('id').eq('customer_id', userId).maybeSingle();
            if (readError) throw readError;
            if (wl && wl.id) {
                const { data: items, error: itError } = await db.from('wishlist_item').select('product_id, service_id').eq('wishlist_id', wl.id);
                if (itError) throw itError;
                if (!itError && items) {
                    return {
                        productIds: items.map(i => i.product_id).filter(Boolean),
                        serviceIds: items.map(i => i.service_id).filter(Boolean)
                    };
                }
            }
        } catch (err) {
            if (strict) throw err;
            console.warn('[API] getUserWishlist Supabase error:', err);
        }
        return { productIds: [], serviceIds: [] };
    },

    async getOrCreateWishlist(userId) {
        if (!userId) return null;
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        
        if (!db) throw new Error('Chưa kết nối được dữ liệu yêu thích.');
        let { data: wl, error: readError } = await db.from('wishlist').select('id').eq('customer_id', userId).maybeSingle();
        if (readError) throw readError;
        if (!wl) {
            const { data: newWl, error } = await db.from('wishlist').insert({ customer_id: userId }).select('id').single();
            if (error) throw error;
            wl = newWl;
        }
        return wl;
    },

    async saveUserWishlist(userId, { productIds } = {}) {
        if (!Array.isArray(productIds)) throw new Error('Danh sách yêu thích không hợp lệ.');
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        const customerId = await resolveCustomerId(db, userId);
        const wishlist = await this.getOrCreateWishlist(customerId);
        if (!wishlist) throw new Error('Không thể tải danh sách yêu thích.');
        const { data: existing, error: readError } = await db.from('wishlist_item')
            .select('id, product_id, service_id').eq('wishlist_id', wishlist.id);
        if (readError) throw readError;
        const desired = new Set(productIds.map(String));
        const current = new Set((existing || []).filter(item => item.product_id).map(item => String(item.product_id)));
        const additions = [...desired].filter(id => !current.has(id))
            .map(product_id => ({ wishlist_id: wishlist.id, product_id }));
        if (additions.length) {
            const { error } = await db.from('wishlist_item').insert(additions);
            if (error) throw error;
        }
        // This operation saves products only; service wishlist entries remain intact.
        const removals = (existing || []).filter(item => item.product_id && !desired.has(String(item.product_id))).map(item => item.id);
        if (removals.length) {
            const { error } = await db.from('wishlist_item').delete().eq('wishlist_id', wishlist.id).in('id', removals);
            if (error) throw error;
        }
        return { success: true, productIds: [...desired] };
    },

    async toggleWishlist(userId, itemId, isService = false) {
        if (!userId) return { success: false, error: 'User not logged in' };
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        const wl = await this.getOrCreateWishlist(userId);
        if (!wl) return { success: false };

        const column = isService ? 'service_id' : 'product_id';
        const { data: existing, error: readError } = await db.from('wishlist_item')
            .select('id').eq('wishlist_id', wl.id).eq(column, itemId).maybeSingle();
        if (readError) throw readError;

        if (existing) {
            const { error } = await db.from('wishlist_item').delete().eq('id', existing.id);
            return { success: !error, action: 'removed', error: error?.message };
        } else {
            const insertData = { wishlist_id: wl.id };
            insertData[column] = itemId;
            const { error } = await db.from('wishlist_item').insert(insertData);
            return { success: !error, action: 'added', error: error?.message };
        }
    },

    async getUserById(userId) {
        const users = await this.request('/api/users');
        if (Array.isArray(users)) {
            return users.find(user => sameUserId(user._id || user.id, userId) || sameUserId(user.legacyId, userId)) || null;
        }
        const localUsers = safeReadArray('pawpal_users_db');
        return localUsers.find(user => sameUserId(user.id, userId)) || null;
    },

    async updateUserProfile(userId, newData) {
        const updated = await this.request(`/api/users/${userId}`, {
            method: 'PUT',
            body: JSON.stringify(newData)
        });

        if (updated) {
            const currentUser = safeReadObject('pawpal_current_user');
            if (currentUser && sameUserId(currentUser.id, userId)) {
                safeWrite('pawpal_current_user', updated);
            }
            return { success: true, data: updated };
        }

        await this.initData();
        const users = safeReadArray('pawpal_users_db');
        const idx = users.findIndex(user => sameUserId(user.id, userId));
        if (idx === -1) {
            return { success: false, message: 'Khong tim thay user' };
        }
        users[idx] = { ...users[idx], ...newData };
        safeWrite('pawpal_users_db', users);
        const currentUser = safeReadObject('pawpal_current_user');
        if (currentUser && sameUser(currentUser, users[idx])) {
            safeWrite('pawpal_current_user', users[idx]);
        }
        return { success: true, data: users[idx] };
    },

    async submitOrder(orderData) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) {
            return { success: false, error: 'No Supabase connection' };
        }

        try {
            let customerId = orderData.userId;
            const isUuidLike = typeof customerId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(customerId);
            
            if (!customerId || !isUuidLike) {
                const phone = orderData.shipping?.phone || '';
                if (phone) {
                    const response = await fetch('/api/customer/auth/guest', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ phone, name: orderData.shipping?.name || 'Khách vãng lai' })
                    });
                    const result = await response.json();
                    if (!response.ok || !result.success) throw new Error(result.message || 'Không thể tạo hồ sơ nhận hàng.');
                    customerId = result.customerId;
                } else {
                    customerId = null;
                }
            }

            let shippingAddressId = 'f0000000-0000-0000-2222-000000000001'; // Fallback
            if (orderData.shipping && customerId) {
                const { data: addrData, error: addrError } = await db.from('customer_address').insert({
                    customer_id: customerId,
                    receiver_name: orderData.shipping.name || 'Khách hàng',
                    receiver_phone: orderData.shipping.phone || '',
                    province: orderData.shipping.city || '',
                    street_address: (orderData.shipping.address || '') + (orderData.shipping.district ? ', ' + orderData.shipping.district : ''),
                    is_default: false
                }).select('id').single();
                
                if (addrError) {
                    console.warn('Could not insert address (maybe guest without customer_id?), using fallback', addrError);
                } else if (addrData && addrData.id) {
                    shippingAddressId = addrData.id;
                }
            }

            const mapPaymentMethodConfigId = (method) => {
                const m = String(method || 'cod').toLowerCase().trim();
                if (m === 'cod') return 'cod';
                if (m === 'momo') return 'momo';
                if (m === 'vnpay') return 'vnpay';
                if (m === 'vietqr' || m === 'qr') return 'vietqr';
                if (m === 'bank' || m === 'bank_transfer' || m === 'banking') return 'bank';
                return 'cod';
            };

            const paymentMethodConfigId = mapPaymentMethodConfigId(orderData.payment?.method);
            const isPaid = orderData.payment?.status === 'paid' || orderData.payment?.status === 'PAID';
            
            const initialOrderStatus = isPaid ? 'da_xac_nhan' : 'cho_xac_nhan';
            const initialPaymentStatus = isPaid ? 'da_thanh_toan' : 'chua_thanh_toan';

            const totalOrderAmount = Number(orderData.pricing?.grandTotal ?? orderData.pricing?.total ?? 0);
            const salesOrder = {
                order_code: orderData.orderId,
                customer_id: customerId,
                shipping_address_id: shippingAddressId,
                order_status: initialOrderStatus,
                payment_status: initialPaymentStatus,
                total_amount: isNaN(totalOrderAmount) ? 0 : totalOrderAmount,
            };

            const { data: newOrder, error: orderError } = await db.from('sales_order').insert(salesOrder).select('id').single();
            if (orderError) throw orderError;

            // Bọc quá trình tạo payment và order_detail trong cơ chế rollback dọn dẹp nếu có lỗi
            try {
                const paymentCode = 'PAY-' + Date.now();
                const paymentInsert = {
                    payment_code: paymentCode,
                    order_id: newOrder.id,
                    payment_type: 'mua_hang',
                    payment_method_config_id: paymentMethodConfigId,
                    amount: isNaN(totalOrderAmount) ? 0 : totalOrderAmount,
                    transaction_status: isPaid ? 'thanh_cong' : 'cho_xu_ly'
                };
                const { error: payError } = await db.from('payment').insert(paymentInsert);
                if (payError) {
                    console.error('[API] Failed to insert payment:', payError);
                    throw payError;
                }

                if (orderData.items && orderData.items.length > 0) {
                    const orderDetails = [];
                    for (const item of orderData.items) {
                        const uPrice = Number(item.price || 0);
                        const qty = Number(item.qty || item.quantity || 1);
                        let vId = item.variantId || item.product_variant_id;
                        if (!vId && item.id) {
                            const { data: vData } = await db.from('product_variant').select('id').eq('product_id', item.id).limit(1);
                            vId = vData?.[0]?.id || item.id;
                        }
                        orderDetails.push({
                            order_id: newOrder.id,
                            product_variant_id: vId,
                            quantity: isNaN(qty) ? 1 : qty,
                            unit_price: isNaN(uPrice) ? 0 : uPrice,
                            discount_amount: 0,
                            subtotal: (isNaN(uPrice) ? 0 : uPrice) * (isNaN(qty) ? 1 : qty)
                        });
                    }
                    const { error: itemsError } = await db.from('sales_order_detail').insert(orderDetails);
                    if (itemsError) throw itemsError;
                }
            } catch (subErr) {
                // Rollback: Xóa bản ghi sales_order nếu tạo payment hoặc detail thất bại để tránh đơn mồ côi
                console.error('[API] Rollback sales_order do lỗi tạo chi tiết/thanh toán:', subErr);
                await db.from('sales_order').delete().eq('id', newOrder.id);
                throw subErr;
            }

            if (orderData.appliedVoucher?.code || orderData.voucherCode) {
                const vCode = orderData.appliedVoucher?.code || orderData.voucherCode;
                try {
                    const { data: vRow } = await db.from('voucher').select('id, usage_count').ilike('voucher_code', vCode).maybeSingle();
                    if (vRow) {
                        await db.from('voucher').update({ usage_count: (vRow.usage_count || 0) + 1 }).eq('id', vRow.id);
                    }
                } catch (vErr) {
                    console.warn('[API] Could not increment voucher usage_count:', vErr);
                }
            }

            if (customerId) {
                try {
                    await this.createSystemNotification({
                        customerId,
                        type: 'don_hang_moi',
                        title: 'Đặt hàng thành công',
                        content: `Đơn hàng #${orderData.orderId} của bạn đã được ghi nhận và đang chờ xử lý.`,
                        orderId: newOrder.id
                    });
                } catch (notifErr) {
                    console.warn('[API] SubmitOrder notification warning:', notifErr);
                }
            }

            return { success: true, orderId: newOrder.id };
        } catch (err) {
            console.error('Submit order error:', err);
            return { success: false, error: err };
        }
    },

    async updateOrderPaymentStatus(orderId, paymentStatus) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !orderId) {
            return { success: false, error: 'No Supabase connection' };
        }

        try {
            const rawStatus = String(paymentStatus || '').toLowerCase().trim();
            const normalizedStatus = {
                'paid': 'da_thanh_toan',
                'da_thanh_toan': 'da_thanh_toan',
                'failed': 'thanh_toan_that_bai',
                'thanh_toan_that_bai': 'thanh_toan_that_bai',
                'pending': 'chua_thanh_toan',
                'chua_thanh_toan': 'chua_thanh_toan',
                'unpaid': 'chua_thanh_toan',
                'refunded': 'da_hoan_tien',
                'da_hoan_tien': 'da_hoan_tien'
            }[rawStatus] || 'chua_thanh_toan';

            const isUUID = typeof orderId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(orderId);

            let query = db.from('sales_order').update({
                payment_status: normalizedStatus,
                updated_at: new Date().toISOString()
            });

            query = isUUID
                ? query.eq('id', orderId)
                : query.eq('order_code', orderId);

            const { data, error } = await query.select('id, order_code, payment_status').maybeSingle();
            if (error) throw error;

            if (data && data.id) {
                const transStatus = normalizedStatus === 'da_thanh_toan' ? 'thanh_cong' : (normalizedStatus === 'thanh_toan_that_bai' ? 'that_bai' : (normalizedStatus === 'da_hoan_tien' ? 'da_hoan_tien' : 'cho_xu_ly'));
                await db.from('payment').update({
                    transaction_status: transStatus,
                    updated_at: new Date().toISOString()
                }).eq('order_id', data.id);
            }

            return { success: true, data };
        } catch (err) {
            console.error('[API] updateOrderPaymentStatus failed:', err);
            return { success: false, error: err };
        }
    },

    async updateOrderStatus(orderId, orderStatus) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !orderId) {
            return { success: false, error: 'No Supabase connection' };
        }

        try {
            const rawStatus = String(orderStatus || '').toLowerCase().trim();
            const normalizedStatus = {
                'placed': 'cho_xac_nhan',
                'cho_xac_nhan': 'cho_xac_nhan',
                'pending': 'cho_xac_nhan',
                'confirmed': 'da_xac_nhan',
                'da_xac_nhan': 'da_xac_nhan',
                'preparing': 'dang_dong_goi',
                'packing': 'dang_dong_goi',
                'dang_dong_goi': 'dang_dong_goi',
                'dang_chuan_bi': 'dang_dong_goi',
                'shipping': 'dang_giao_hang',
                'dang_giao': 'dang_giao_hang',
                'dang_giao_hang': 'dang_giao_hang',
                'delivered': 'da_giao_hang',
                'da_giao': 'da_giao_hang',
                'da_giao_hang': 'da_giao_hang',
                'completed': 'da_giao_hang',
                'da_hoan_tat': 'da_giao_hang',
                'cancelled': 'da_huy',
                'canceled': 'da_huy',
                'da_huy': 'da_huy',
                'returned': 'da_tra_hang',
                'da_tra_hang': 'da_tra_hang'
            }[rawStatus] || 'cho_xac_nhan';

            const isUUID = typeof orderId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(orderId);

            let query = db.from('sales_order').update({
                order_status: normalizedStatus,
                updated_at: new Date().toISOString()
            });

            query = isUUID
                ? query.eq('id', orderId)
                : query.eq('order_code', orderId);

            const { data, error } = await query.select('id, order_code, order_status').maybeSingle();
            if (error) throw error;

            return { success: true, data };
        } catch (err) {
            console.error('[API] updateOrderStatus failed:', err);
            return { success: false, error: err };
        }
    },

    async getVouchers() {
        try {
            const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
            if (!db) {
                console.error('[API] Supabase Client not initialized');
                return [];
            }
            
            const { data, error } = await db.from('voucher')
                .select('*')
                
            if (error) throw error;
            
            const mappedVouchers = (data || []).map(v => {
                let maxDiscount = v.max_discount;
                if (maxDiscount == null && v.description) {
                    const match = v.description.match(/tối đa\s+([\d.,]+)(k|đ)/i);
                    if (match) {
                        let val = parseFloat(match[1].replace(/[.,]/g, ''));
                        if (match[2].toLowerCase() === 'k') val *= 1000;
                        maxDiscount = val;
                    }
                }
                
                return {
                    id: v.id,
                    code: v.voucher_code,
                    name: v.voucher_name || v.voucher_code,
                    type: (String(v.type || 'percentage').toLowerCase() === 'percent' ? 'percentage' : String(v.type || 'percentage').toLowerCase()),
                    value: v.discount_value || 0,
                    minOrderValue: v.minimum_order_amount || 0,
                    maxDiscount: maxDiscount,
                    pointsCost: v.required_points || 0,
                    validFrom: v.start_date,
                    validUntil: v.end_date,
                    usageCount: v.usage_count || 0,
                    maxUsage: v.max_usage,
                    applicableFor: v.applicable_for || ['all'],
                    description: v.description,
                    is_active: v.is_active,
                    active: (() => {
                        if (v.is_active !== true) return false;
                        const now = Date.now();
                        const from = v.start_date ? new Date(v.start_date).getTime() : -Infinity;
                        const until = v.end_date ? new Date(v.end_date).getTime() : Infinity;
                        const quotaOk = v.max_usage == null || Number(v.usage_count || 0) < Number(v.max_usage);
                        return now >= from && now <= until && quotaOk;
                    })(),
                };
            });
            
            console.log('[API] Đã tải danh sách voucher từ Supabase:', mappedVouchers);
            return mappedVouchers;
        } catch (err) {
            console.error('[API] Error fetching vouchers from Supabase:', err);
            return [];
        }
    },

    async getDeliveryOptions() {
        try {
            const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
            if (!db) {
                console.error('[API] Supabase Client not initialized');
                return [];
            }
            
            const { data, error } = await db.from('delivery_option_config')
                .select('*')
                .eq('available', true)
                .order('fee', { ascending: true });
                
            if (error) throw error;
            
            return (data || []).map(d => ({
                id: d.id,
                name: d.name,
                description: d.description,
                fee: Number(d.fee),
                estimatedDays: d.estimated_days,
                icon: d.icon,
                available: d.available
            }));
        } catch (err) {
            console.error('[API] getDeliveryOptions failed:', err);
            const res = await fetch('/data/delivery-options.json');
            return await res.json().catch(() => []);
        }
    },

    async getPaymentMethods() {
        try {
            const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
            if (!db) {
                console.warn('[API] Supabase Client not initialized, falling back to mock payment methods');
                const res = await fetch('/data/payment-methods.json');
                return await res.json();
            }
            
            const { data, error } = await db.from('payment_method_config')
                .select('*')
                .eq('available', true)
                .order('id', { ascending: true });
                
            if (error) {
                if (error.code === '42P01') {
                    const res = await fetch('/data/payment-methods.json');
                    return await res.json();
                }
                throw error;
            }
            
            return (data || []).map(p => ({
                id: p.id,
                name: p.name,
                shortName: p.short_name,
                description: p.description,
                icon: p.icon,
                fee: Number(p.fee),
                available: p.available,
                requiresInfo: p.requires_info,
                redirectUrl: p.redirect_url,
                bankInfo: p.bank_info
            }));
        } catch (err) {
            console.error('[API] getPaymentMethods failed:', err);
            const res = await fetch('/data/payment-methods.json');
            return await res.json().catch(() => []);
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 2: CƠ CHẾ GIỮ CHỖ 15 PHÚT (SLOT HOLD)
       ========================================================================== */
    async releaseExpiredHoldSlots() {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return;
        try {
            const fifteenMinsAgo = new Date(Date.now() - 15 * 60 * 1000).toISOString();
            await db.from('appointment')
                .update({ appointment_status: 'da_het_han' })
                .eq('appointment_status', 'dang_giu_cho')
                .lt('created_at', fifteenMinsAgo);
        } catch (e) {
            console.warn('[API] releaseExpiredHoldSlots error:', e);
        }
    },

    async checkSlotAvailability(serviceId, date, time, staffId = null) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return { available: true };
        try {
            await this.releaseExpiredHoldSlots();
            const fifteenMinsAgo = new Date(Date.now() - 15 * 60 * 1000).toISOString();

            let query = db.from('appointment')
                .select('id, appointment_status, created_at')
                .eq('appointment_date', date)
                .eq('appointment_time', time.length === 5 ? time + ':00' : time)
                .not('appointment_status', 'in', '("da_huy","da_het_han")');

            if (serviceId) query = query.eq('service_id', serviceId);
            if (staffId) query = query.eq('staff_id', staffId);

            const { data, error } = await query;
            if (error) throw error;

            const activeHold = (data || []).find(row => {
                if (row.appointment_status === 'dang_giu_cho') {
                    return row.created_at && row.created_at > fifteenMinsAgo;
                }
                return ['cho_xac_nhan', 'da_xac_nhan', 'da_check_in', 'dang_thuc_hien'].includes(row.appointment_status);
            });

            return { available: !activeHold, conflictBooking: activeHold || null };
        } catch (err) {
            console.warn('[API] checkSlotAvailability failed:', err);
            return { available: true };
        }
    },

    async holdAppointmentSlot({ customerId, petId, serviceId, staffId, date, time, totalPrice = 0, note = '' }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return { success: false, error: 'No DB connection' };
        try {
            const check = await this.checkSlotAvailability(serviceId, date, time, staffId);
            if (!check.available) {
                return { success: false, error: 'Khung giờ này vừa có người giữ chỗ hoặc đã được đặt. Vui lòng chọn giờ khác.' };
            }

            const holdExpiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
            const appointmentCode = 'APT-' + Math.floor(100000 + Math.random() * 900000);

            const insertPayload = {
                appointment_code: appointmentCode,
                customer_id: customerId,
                pet_id: petId,
                service_id: serviceId,
                staff_id: staffId || null,
                appointment_date: date,
                appointment_time: time.length === 5 ? time + ':00' : time,
                appointment_status: 'dang_giu_cho',
                payment_status: 'chua_thanh_toan',
                total_price: totalPrice,
                note: note,
                change_count: 0
            };

            const { data, error } = await db.from('appointment').insert([insertPayload]).select('*').single();
            if (error) throw error;

            return { success: true, booking: data, expiresAt: holdExpiresAt };
        } catch (err) {
            console.error('[API] holdAppointmentSlot failed:', err);
            return { success: false, error: err.message };
        }
    },

    async confirmHeldSlot(appointmentId, isDepositPaid = false) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return { success: false };
        try {
            const newStatus = isDepositPaid ? 'da_xac_nhan' : 'cho_xac_nhan';
            const payStatus = isDepositPaid ? 'da_thanh_toan_mot_phan' : 'chua_thanh_toan';

            const { data, error } = await db.from('appointment')
                .update({
                    appointment_status: newStatus,
                    payment_status: payStatus,
                    updated_at: new Date().toISOString()
                })
                .eq('id', appointmentId)
                .select()
                .single();

            if (error) throw error;
            return { success: true, data };
        } catch (err) {
            console.error('[API] confirmHeldSlot failed:', err);
            return { success: false, error: err.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 2: CƠ CHẾ GIỮ TỒN KHO 15 PHÚT (STOCK RESERVATION)
       ========================================================================== */
    async releaseExpiredStockReservations() {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return;
        try {
            const now = new Date().toISOString();
            await db.from('stock_reservation')
                .update({ status: 'da_het_han', updated_at: now })
                .eq('status', 'dang_giu')
                .lt('expires_at', now);
        } catch (e) {
            // bỏ qua nếu bảng chưa tạo
        }
    },

    async getAvailableStock(productVariantId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return 99;
        try {
            await this.releaseExpiredStockReservations();
            const { data: inv } = await db.from('inventory').select('quantity_in_stock').eq('product_variant_id', productVariantId).maybeSingle();
            const totalStock = inv?.quantity_in_stock || 0;

            const now = new Date().toISOString();
            const { data: res } = await db.from('stock_reservation')
                .select('quantity')
                .eq('product_variant_id', productVariantId)
                .eq('status', 'dang_giu')
                .gt('expires_at', now);

            const reservedQty = (res || []).reduce((sum, r) => sum + Number(r.quantity || 0), 0);
            return Math.max(0, totalStock - reservedQty);
        } catch (err) {
            return 99;
        }
    },

    async reserveStock(cartId, customerId, items) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !items?.length) return { success: true };
        try {
            const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
            const rows = items.map(it => ({
                product_variant_id: it.variantId || it.id,
                customer_id: customerId,
                cart_id: cartId,
                quantity: it.quantity || it.qty || 1,
                reserved_at: new Date().toISOString(),
                expires_at: expiresAt,
                status: 'dang_giu'
            }));

            await db.from('stock_reservation').insert(rows);
            return { success: true, expiresAt };
        } catch (err) {
            console.warn('[API] reserveStock skipped or failed:', err.message);
            return { success: true };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 2: CARE LOG & CARE LOG MEDIA
       ========================================================================== */
    async getPetCareLogs(petId, appointmentId = null) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !petId) return [];
        try {
            let query = db.from('care_log')
                .select(`
                    id, description, health_status, recorded_at, created_at,
                    care_log_media ( id, media_type, media_url, file_name ),
                    care_action ( action_name, service_category )
                `)
                .eq('pet_id', petId)
                .order('recorded_at', { ascending: false });

            if (appointmentId) query = query.eq('appointment_id', appointmentId);

            const { data, error } = await query;
            if (error) throw error;
            return data || [];
        } catch (err) {
            console.warn('[API] getPetCareLogs failed:', err.message);
            return [];
        }
    },

    async addCareLogEntry({ appointmentId, petId, careActionId, description, healthStatus, mediaUrls = [], staffId = null }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return { success: false };
        try {
            const logPayload = {
                appointment_id: appointmentId,
                pet_id: petId,
                care_action_id: careActionId || null,
                description,
                health_status: healthStatus || 'bình thường',
                recorded_at: new Date().toISOString()
            };

            const { data: newLog, error } = await db.from('care_log').insert([logPayload]).select().single();
            if (error) throw error;

            if (mediaUrls.length > 0 && newLog?.id) {
                const mediaRows = mediaUrls.map(url => ({
                    care_log_id: newLog.id,
                    media_type: url.match(/\.(mp4|mov|avi)$/i) ? 'video' : 'hinh_anh',
                    media_url: url,
                    staff_id: staffId,
                    uploaded_at: new Date().toISOString()
                }));
                await db.from('care_log_media').insert(mediaRows);
            }

            return { success: true, data: newLog };
        } catch (err) {
            console.error('[API] addCareLogEntry error:', err);
            return { success: false, error: err.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 2: REVIEW RESPONSE (PHẢN HỒI ĐÁNH GIÁ CỦA ADMIN)
       ========================================================================== */
    async getReviewResponses(reviewId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !reviewId) return [];
        try {
            const { data, error } = await db.from('review_response')
                .select('*, staff(full_name)')
                .eq('review_id', reviewId)
                .order('created_at', { ascending: true });
            if (error) throw error;
            return data || [];
        } catch (e) {
            return [];
        }
    },

    async addReviewResponse(reviewId, staffId, responseContent) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return { success: false };
        try {
            const payload = {
                review_id: reviewId,
                staff_id: staffId,
                response_content: responseContent,
                created_at: new Date().toISOString()
            };
            const { data, error } = await db.from('review_response').insert([payload]).select().single();
            if (error) throw error;
            return { success: true, data };
        } catch (err) {
            console.error('[API] addReviewResponse failed:', err);
            return { success: false, error: err.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 3: CẤU HÌNH HỆ THỐNG ĐỘNG (PAWPAL_SETTING)
       ========================================================================== */
    async getSetting(key, fallback = null) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !key) return fallback;
        try {
            const { data, error } = await db.from('pawpal_setting')
                .select('setting_value, setting_type')
                .eq('setting_key', key)
                .maybeSingle();

            if (error || !data) return fallback;
            const val = data.setting_value;
            if (data.setting_type === 'json') {
                try { return JSON.parse(val); } catch { return val; }
            }
            if (data.setting_type === 'so' || data.setting_type === 'number') return Number(val);
            if (data.setting_type === 'boolean') return val === 'true' || val === '1';
            return val;
        } catch (e) {
            return fallback;
        }
    },

    async getAllSettings() {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return {};
        try {
            const { data, error } = await db.from('pawpal_setting').select('*');
            if (error) throw error;
            const map = {};
            (data || []).forEach(row => {
                let val = row.setting_value;
                if (row.setting_type === 'json') {
                    try { val = JSON.parse(val); } catch {}
                } else if (row.setting_type === 'so' || row.setting_type === 'number') {
                    val = Number(val);
                } else if (row.setting_type === 'boolean') {
                    val = val === 'true' || val === '1';
                }
                map[row.setting_key] = val;
            });
            return map;
        } catch (e) {
            return {};
        }
    },

    async updateSetting(key, value, type = 'chuoi', description = '') {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !key) return { success: false };
        try {
            const strVal = typeof value === 'object' ? JSON.stringify(value) : String(value);
            const payload = {
                setting_key: key,
                setting_value: strVal,
                setting_type: type,
                description,
                updated_at: new Date().toISOString()
            };
            const { data, error } = await db.from('pawpal_setting')
                .upsert(payload, { onConflict: 'setting_key' })
                .select()
                .single();

            if (error) throw error;
            return { success: true, data };
        } catch (e) {
            console.error('[API] updateSetting error:', e);
            return { success: false, error: e.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 3: QUẢN LÝ PHÒNG VẬT LÝ HOTEL (HOTEL_ROOM & HOTEL_ROOM_TYPE)
       ========================================================================== */
    async getHotelRooms(status = null) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return [];
        try {
            let query = db.from('hotel_room')
                .select('*, hotel_room_type(room_type, capacity, daily_price, amenities)')
                .order('room_number', { ascending: true });

            if (status) query = query.eq('status', status);
            const { data, error } = await query;
            if (error) throw error;
            return data || [];
        } catch (e) {
            console.warn('[API] getHotelRooms error:', e);
            return [];
        }
    },

    async updateHotelRoomStatus(roomId, status, description = null) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !roomId) return { success: false };
        try {
            const payload = {
                status,
                updated_at: new Date().toISOString()
            };
            if (description !== null) payload.description = description;

            const { data, error } = await db.from('hotel_room').update(payload).eq('id', roomId).select().single();
            if (error) throw error;
            return { success: true, data };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 3: BẢNG GIÁ VÀ TÍNH CƯỚC PET TAXI (TAXI_PRICE_RULE)
       ========================================================================== */
    async getTaxiPriceRules() {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return [];
        try {
            const { data, error } = await db.from('taxi_price_rule')
                .select('*')
                .eq('status', 'dang_ap_dung')
                .order('distance_from', { ascending: true });

            if (error) throw error;
            return data || [];
        } catch (e) {
            return [];
        }
    },

    async calculateTaxiFare(distanceKm, petWeightKg = 5) {
        try {
            const rules = await this.getTaxiPriceRules();
            if (!rules.length) {
                // Fallback default formula: 50,000đ base (0-3km) + 12,000đ/km tiếp theo
                const base = 50000;
                const extraKm = Math.max(0, distanceKm - 3);
                const surchargeWeight = petWeightKg > 10 ? (petWeightKg - 10) * 5000 : 0;
                return base + (extraKm * 12000) + surchargeWeight;
            }

            const match = rules.find(r => 
                distanceKm >= Number(r.distance_from) && 
                (r.distance_to === null || distanceKm <= Number(r.distance_to)) &&
                petWeightKg >= Number(r.weight_from || 0) &&
                (r.weight_to === null || petWeightKg <= Number(r.weight_to))
            );

            if (match) {
                return Number(match.base_price || 0) + Number(match.surcharge || 0);
            }

            return Number(rules[0].base_price || 60000);
        } catch (e) {
            return 50000;
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 3: ĐỐI TÁC GIAO VẬN VÀ PHƯƠNG THỨC THANH TOÁN (LIVE SUPABASE)
       ========================================================================== */
    async getShippingProviders() {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return [];
        try {
            const { data, error } = await db.from('shipping_provider')
                .select('*')
                .eq('status', 'dang_hoat_dong')
                .order('provider_name', { ascending: true });
            if (error) throw error;
            return data || [];
        } catch (e) {
            return [];
        }
    },

    async getDeliveryOptions() {
        try {
            const providers = await this.getShippingProviders();
            if (providers && providers.length > 0) {
                return providers.map(p => {
                    const feeVal = Number(p.base_fee !== undefined ? p.base_fee : 30000);
                    return {
                        id: p.provider_code || p.id,
                        name: p.provider_name,
                        fee: isNaN(feeVal) ? 30000 : feeVal,
                        price: isNaN(feeVal) ? 30000 : feeVal,
                        estimatedDays: p.estimated_days ? [p.estimated_days, p.estimated_days] : [2, 3],
                        estimatedTime: p.estimated_days ? `${p.estimated_days} ngày` : '2-3 ngày',
                        description: p.note || 'Giao hàng tiêu chuẩn toàn quốc',
                        available: true,
                        icon: 'truck'
                    };
                });
            }
        } catch (e) {}

        // Dynamic fallback from settings or standard options
        return [
            { id: 'standard', name: 'Giao hàng tiêu chuẩn', fee: 30000, price: 30000, estimatedDays: [2, 3], estimatedTime: '2-3 ngày', description: 'Giao hàng tiết kiệm toàn quốc', available: true, icon: 'truck' },
            { id: 'express', name: 'Giao hàng hỏa tốc 2H', fee: 50000, price: 50000, estimatedDays: [1, 1], estimatedTime: '2 giờ', description: 'Áp dụng nội thành TP.HCM', available: true, icon: 'truck' }
        ];
    },

    async getPaymentMethods() {
        try {
            const config = await this.getSetting('payment_gateways', null);
            if (config && typeof config === 'object') {
                const methods = [];
                if (config.cod_enabled !== false) {
                    methods.push({ id: 'cod', name: 'Thanh toán khi nhận hàng (COD)', description: 'Thanh toán bằng tiền mặt khi shipper giao hàng', icon: 'cash' });
                }
                if (config.vnpay_enabled !== false) {
                    methods.push({ id: 'vnpay', name: 'Thanh toán qua VNPAY-QR', description: 'Thẻ ATM, Visa/Mastercard hoặc ứng dụng Ngân hàng', icon: 'vnpay' });
                }
                if (config.bank_transfer_enabled) {
                    methods.push({ id: 'bank_transfer', name: 'Chuyển khoản Ngân hàng', description: 'Chuyển khoản trực tiếp vào tài khoản ngân hàng Pawpal', icon: 'bank' });
                }
                if (methods.length > 0) return methods;
            }
        } catch (e) {}

        return [
            { id: 'cod', name: 'Thanh toán khi nhận hàng (COD)', description: 'Thanh toán tiền mặt khi nhận hàng', icon: 'cash' },
            { id: 'vnpay', name: 'Cổng thanh toán VNPAY-QR / Thẻ', description: 'Hỗ trợ thẻ ATM, Visa, Mastercard, VNPAY-QR', icon: 'vnpay' }
        ];
    },

    /* ==========================================================================
       GIAI ĐOẠN 4: QUẢN LÝ KHO VẬN 2 LỚP & BIẾN ĐỘNG KHO (INVENTORY_TRANSACTION)
       ========================================================================== */
    async getInventoryLevels() {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return [];
        try {
            const { data, error } = await db.from('inventory')
                .select('*, product_variant(id, sku_variant, sale_price, product(id, product_name, category_id))')
                .order('last_updated_at', { ascending: false });

            if (error) throw error;
            return data || [];
        } catch (e) {
            console.warn('[API] getInventoryLevels error:', e);
            return [];
        }
    },

    async recordInventoryTransaction({ productVariantId, purchaseOrderId = null, transactionType, quantity, staffId = null, note = '' }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !productVariantId || !transactionType || !quantity) return { success: false, message: 'Thiếu dữ liệu kho' };

        try {
            // 1. Lấy tồn kho hiện tại
            const { data: currentInv, error: invErr } = await db.from('inventory')
                .select('*')
                .eq('product_variant_id', productVariantId)
                .maybeSingle();

            if (invErr) throw invErr;

            const stockBefore = currentInv ? Number(currentInv.quantity_in_stock || 0) : 0;
            let stockAfter = stockBefore;

            if (transactionType === 'nhap_kho' || transactionType === 'dieu_chinh_tang' || transactionType === 'hoan_kho') {
                stockAfter = stockBefore + Number(quantity);
            } else if (transactionType === 'xuat_kho' || transactionType === 'dieu_chinh_giam') {
                stockAfter = Math.max(0, stockBefore - Number(quantity));
            }

            // 2. Cập nhật bảng inventory
            const now = new Date().toISOString();
            if (currentInv) {
                await db.from('inventory').update({
                    quantity_in_stock: stockAfter,
                    last_updated_at: now
                }).eq('id', currentInv.id);
            } else {
                await db.from('inventory').insert([{
                    product_variant_id: productVariantId,
                    quantity_in_stock: stockAfter,
                    minimum_stock: 5,
                    quantity_reserved: 0,
                    last_updated_at: now
                }]);
            }

            // 3. Ghi log lịch sử biến động kho
            const { data: txData, error: txErr } = await db.from('inventory_transaction').insert([{
                product_variant_id: productVariantId,
                purchase_order_id: purchaseOrderId,
                transaction_type: transactionType,
                quantity: Number(quantity),
                stock_before: stockBefore,
                stock_after: stockAfter,
                note,
                staff_id: staffId,
                created_at: now
            }]).select().single();

            if (txErr) throw txErr;
            return { success: true, data: txData, stockBefore, stockAfter };
        } catch (e) {
            console.error('[API] recordInventoryTransaction error:', e);
            return { success: false, error: e.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 4: ĐỔI TRẢ HÀNG & HẬU MÃI RMA (RETURN_REQUEST & RETURN_DETAIL)
       ========================================================================== */
    async getReturnRequests({ customerId = null, orderId = null, status = null } = {}) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return [];
        try {
            let query = db.from('return_request')
                .select('*, return_request_detail(*, product_variant(id, sku_variant, sale_price)), customer(id, phone_main, customer_profile(full_name))')
                .order('created_at', { ascending: false });

            if (customerId) query = query.eq('customer_id', customerId);
            if (orderId) query = query.eq('sales_order_id', orderId);
            if (status) query = query.eq('request_status', status);

            const { data, error } = await query;
            if (error) throw error;
            return data || [];
        } catch (e) {
            console.warn('[API] getReturnRequests error:', e);
            return [];
        }
    },

    async createReturnRequest({ salesOrderId, customerId, returnType = 'doi_san_pham', reason, description = '', evidenceImages = [], items = [] }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !salesOrderId || !customerId || !reason) return { success: false, message: 'Thiếu thông tin yêu cầu đổi trả' };

        try {
            const now = new Date().toISOString();
            // 1. Tạo bản ghi return_request
            const { data: request, error: reqErr } = await db.from('return_request').insert([{
                sales_order_id: salesOrderId,
                customer_id: customerId,
                return_type: returnType,
                reason,
                description,
                evidence_images: evidenceImages,
                request_status: 'cho_xu_ly',
                created_at: now,
                updated_at: now
            }]).select().single();

            if (reqErr) throw reqErr;

            // 2. Tạo các dòng chi tiết return_request_detail nếu có
            if (items && items.length > 0) {
                const details = items.map(item => ({
                    return_request_id: request.id,
                    product_variant_id: item.productVariantId,
                    quantity: Number(item.quantity || 1),
                    unit_price: Number(item.unitPrice || 0)
                }));
                const { error: detErr } = await db.from('return_request_detail').insert(details);
                if (detErr) console.warn('[API] return_request_detail insert warning:', detErr);
            }

            // 3. Tự động gửi thông báo hệ thống cho khách hàng
            await this.createSystemNotification({
                customerId,
                type: 'cap_nhat_yeu_cau_ho_tro',
                title: 'Yêu cầu đổi trả đã được tiếp nhận',
                content: `Yêu cầu ${returnType === 'doi_san_pham' ? 'đổi sản phẩm' : 'trả hàng/hoàn tiền'} cho đơn hàng đã được gửi thành công và đang chờ chuyên viên xử lý.`,
                orderId: salesOrderId
            });

            return { success: true, data: request };
        } catch (e) {
            console.error('[API] createReturnRequest error:', e);
            return { success: false, error: e.message };
        }
    },

    async updateReturnRequestStatus(requestId, { requestStatus, resolutionType = null, refundAmount = 0, resolvedBy = null, restockItems = false }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !requestId) return { success: false };

        try {
            const now = new Date().toISOString();
            const payload = {
                request_status: requestStatus,
                updated_at: now
            };
            if (resolutionType) payload.resolution_type = resolutionType;
            if (refundAmount > 0) payload.refund_amount = refundAmount;
            if (resolvedBy) payload.resolved_by = resolvedBy;

            const { data: updatedReq, error } = await db.from('return_request')
                .update(payload)
                .eq('id', requestId)
                .select('*, return_request_detail(*)')
                .single();

            if (error) throw error;

            // Nếu chấp nhận hoàn kho (restock), tự động ghi nhận inventory_transaction
            if (restockItems && updatedReq.return_request_detail?.length > 0) {
                for (const item of updatedReq.return_request_detail) {
                    if (item.product_variant_id && item.quantity > 0) {
                        await this.recordInventoryTransaction({
                            productVariantId: item.product_variant_id,
                            transactionType: 'hoan_kho',
                            quantity: item.quantity,
                            staffId: resolvedBy,
                            note: `Hoàn kho từ yêu cầu đổi trả RMA #${requestId.substring(0, 8)}`
                        });
                    }
                }
            }

            if (updatedReq?.customer_id) {
                try {
                    const isApproved = requestStatus === 'da_duyet' || requestStatus === 'approved';
                    const isCompleted = requestStatus === 'da_hoan_tat' || requestStatus === 'completed';
                    const isRejected = requestStatus === 'da_tu_choi' || requestStatus === 'rejected';
                    let notiTitle = 'Cập nhật yêu cầu đổi trả';
                    let notiContent = `Yêu cầu đổi trả #${requestId.slice(0, 8)} đã được cập nhật trạng thái: ${requestStatus}.`;
                    if (isApproved) {
                        notiTitle = 'Yêu cầu đổi trả đã được duyệt';
                        notiContent = `Yêu cầu đổi trả #${requestId.slice(0, 8)} của bạn đã được chấp thuận.`;
                    } else if (isCompleted) {
                        notiTitle = 'Yêu cầu đổi trả đã hoàn tất';
                        notiContent = `Yêu cầu đổi trả #${requestId.slice(0, 8)} đã hoàn tất xử lý.`;
                    } else if (isRejected) {
                        notiTitle = 'Yêu cầu đổi trả bị từ chối';
                        notiContent = `Yêu cầu đổi trả #${requestId.slice(0, 8)} không được chấp thuận. Vui lòng liên hệ CSKH để biết thêm chi tiết.`;
                    }
                    await this.createSystemNotification({
                        customerId: updatedReq.customer_id,
                        type: 'cap_nhat_yeu_cau_ho_tro',
                        title: notiTitle,
                        content: notiContent,
                        orderId: updatedReq.sales_order_id
                    });
                } catch (notiErr) {
                    console.warn('[API] Return status notification warning:', notiErr);
                }
            }

            return { success: true, data: updatedReq };
        } catch (e) {
            console.error('[API] updateReturnRequestStatus error:', e);
            return { success: false, error: e.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 4: HỖ TRỢ KHÁCH HÀNG & KHIẾU NẠI (SUPPORT_TICKET & TICKET_MESSAGE)
       ========================================================================== */
    async getSupportTickets({ customerId = null, status = null, priority = null } = {}) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db) return [];
        try {
            let query = db.from('support_ticket')
                .select('*, support_ticket_message(*), customer(id, phone_main, customer_profile(full_name))')
                .order('created_at', { ascending: false });

            if (customerId) query = query.eq('customer_id', customerId);
            if (status) query = query.eq('status', status);
            if (priority) query = query.eq('priority', priority);

            const { data, error } = await query;
            if (error) throw error;
            return data || [];
        } catch (e) {
            console.warn('[API] getSupportTickets error:', e);
            return [];
        }
    },

    async createSupportTicket({ customerId, orderId = null, appointmentId = null, channel = 'web', category = 'khac', subject, description, priority = 'trung_binh', requestedResolution = null, requestedAmount = null }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !customerId || !subject || !description) return { success: false, message: 'Thiếu thông tin ticket' };

        try {
            const ticketCode = `TK-${Date.now().toString(36).toUpperCase().slice(-6)}`;
            const now = new Date().toISOString();

            const { data, error } = await db.from('support_ticket').insert([{
                ticket_code: ticketCode,
                customer_id: customerId,
                order_id: orderId,
                appointment_id: appointmentId,
                channel,
                category,
                subject,
                description,
                priority,
                status: 'mo',
                requested_resolution: requestedResolution,
                requested_amount: requestedAmount,
                created_at: now,
                updated_at: now
            }]).select().single();

            if (error) throw error;
            return { success: true, data };
        } catch (e) {
            console.error('[API] createSupportTicket error:', e);
            return { success: false, error: e.message };
        }
    },

    async addTicketMessage({ ticketId, senderType = 'khach_hang', senderId = null, content, attachmentUrls = [], isInternal = false }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !ticketId || !content) return { success: false };

        try {
            const now = new Date().toISOString();
            const { data, error } = await db.from('support_ticket_message').insert([{
                ticket_id: ticketId,
                sender_type: senderType,
                sender_id: senderId,
                content,
                attachment_urls: attachmentUrls,
                is_internal: isInternal,
                created_at: now
            }]).select().single();

            if (error) throw error;

            // Cập nhật updated_at cho ticket và ghi nhận first_response_at nếu nhân viên phản hồi lần đầu
            const isStaffReply = ['cskh', 'nhan_vien', 'admin', 'staff'].includes(senderType) && !isInternal;
            if (isStaffReply) {
                await db.from('support_ticket').update({
                    updated_at: now,
                    first_response_at: now
                }).eq('id', ticketId).is('first_response_at', null);
            } else {
                await db.from('support_ticket').update({ updated_at: now }).eq('id', ticketId);
            }

            return { success: true, data };
        } catch (e) {
            console.error('[API] addTicketMessage error:', e);
            return { success: false, error: e.message };
        }
    },

    async resolveSupportTicket(ticketId, {
        status = 'completed',
        resolutionType = null,
        resolutionNote = null,
        investigationNote = null,
        approvedAmount = 0,
        resolvedBy = null,
        closedAt = null
    } = {}) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !ticketId) return { success: false };

        try {
            const now = new Date().toISOString();
            const payload = {
                status,
                updated_at: now
            };
            if (resolutionType) payload.resolution_type = resolutionType;
            if (resolutionNote) payload.resolution_note = resolutionNote;
            if (investigationNote) payload.investigation_note = investigationNote;
            if (approvedAmount > 0) payload.approved_amount = approvedAmount;
            if (resolvedBy) payload.resolved_by = resolvedBy;
            if (status === 'completed' || status === 'resolved') {
                payload.resolved_at = now;
                payload.closed_at = closedAt || now;
            }

            const { data, error } = await db.from('support_ticket')
                .update(payload)
                .eq('id', ticketId)
                .select()
                .single();

            if (error) throw error;
            return { success: true, data };
        } catch (e) {
            console.error('[API] resolveSupportTicket error:', e);
            return { success: false, error: e.message };
        }
    },

    /* ==========================================================================
       GIAI ĐOẠN 4: THÔNG BÁO HỆ THỐNG & TRUY VẾT NHẬT KÝ (NOTIFICATION & AUDIT_LOG)
       ========================================================================== */
    async getUserNotifications(customerId, limit = 20) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !customerId) return [];
        try {
            const { data, error } = await db.from('notification')
                .select('*')
                .eq('customer_id', customerId)
                .order('sent_at', { ascending: false })
                .limit(limit);

            if (error) throw error;
            return data || [];
        } catch (e) {
            return [];
        }
    },

    async markNotificationAsRead(notificationId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !notificationId) return { success: false };
        try {
            const { data, error } = await db.from('notification')
                .update({ is_read: true, read_at: new Date().toISOString() })
                .eq('id', notificationId)
                .select()
                .single();

            if (error) throw error;
            return { success: true, data };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },

    async markAllNotificationsAsRead(customerId) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !customerId) return { success: false };
        try {
            const { data, error } = await db.from('notification')
                .update({ is_read: true, read_at: new Date().toISOString() })
                .eq('customer_id', customerId)
                .eq('is_read', false);

            if (error) throw error;
            return { success: true, data };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },

    async createSystemNotification({ customerId, type = 'don_hang_moi', title, content, orderId = null, appointmentId = null, ticketId = null, refundId = null }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !customerId || !title || !content) return { success: false };
        try {
            const { data, error } = await db.from('notification').insert([{
                customer_id: customerId,
                notification_type: type,
                title,
                content,
                sales_order_id: orderId,
                appointment_id: appointmentId,
                support_ticket_id: ticketId,
                refund_transaction_id: refundId,
                is_read: false,
                sent_at: new Date().toISOString()
            }]).select().single();

            if (error) throw error;
            try {
                if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
                    window.dispatchEvent(new CustomEvent('notifications_updated', { detail: { action: 'created', notification: data } }));
                }
            } catch (_) {}
            return { success: true, data };
        } catch (e) {
            console.warn('[API] createSystemNotification warning:', e);
            return { success: false };
        }
    },

    async recordAuditLog({ staffId, action, entityName, entityId, description = '' }) {
        const db = window.getSupabaseClient ? window.getSupabaseClient() : window.SupabaseClient;
        if (!db || !action || !entityName || !entityId) return { success: false };
        try {
            const { data, error } = await db.from('audit_log').insert([{
                staff_id: staffId,
                action,
                entity_name: entityName,
                entity_id: entityId,
                description,
                created_at: new Date().toISOString()
            }]).select().single();

            if (error) throw error;
            return { success: true, data };
        } catch (e) {
            console.warn('[API] recordAuditLog warning:', e);
            return { success: false };
        }
    }
};

function safeReadArray(key) {
    if (window.PawpalStorage) {
        return window.PawpalStorage.get(key, []);
    }
    try {
        const value = JSON.parse(localStorage.getItem(key) || '[]');
        return Array.isArray(value) ? value : [];
    } catch (error) {
        return [];
    }
}

function safeReadObject(key) {
    if (window.PawpalStorage) {
        return window.PawpalStorage.get(key, null);
    }
    try {
        const value = JSON.parse(localStorage.getItem(key) || 'null');
        return value && typeof value === 'object' ? value : null;
    } catch (error) {
        return null;
    }
}

function safeWrite(key, value) {
    if (window.PawpalStorage) {
        return window.PawpalStorage.set(key, value);
    }
    try {
        localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
    } catch (error) {
        console.error(error);
    }
}

function mergeById(seedItems, localItems) {
    const merged = new Map();
    (Array.isArray(localItems) ? localItems : []).forEach(item => {
        if (item && item.id) merged.set(String(item.id), item);
    });
    (Array.isArray(seedItems) ? seedItems : []).forEach(item => {
        if (item && item.id) {
            const local = merged.get(String(item.id));
            if (local) {
                merged.set(String(item.id), {
                    ...item,
                    status:      local.status      ?? item.status,
                    date:        local.date        ?? item.date,
                    time:        local.time        ?? item.time,
                    timeStart:   local.timeStart   ?? item.timeStart,
                    timeEnd:     local.timeEnd     ?? item.timeEnd,
                    staff:       local.staff       ?? item.staff,
                    changeCount: local.changeCount ?? item.changeCount,
                    cancelCount: local.cancelCount ?? item.cancelCount,
                    note:        local.note        ?? item.note,
                    pointsAwarded: local.pointsAwarded ?? item.pointsAwarded,
                    pointsEarned:  local.pointsEarned  ?? item.pointsEarned,
                });
            } else {
                merged.set(String(item.id), item);
            }
        }
    });
    return Array.from(merged.values());
}

function mergeCareLogs(seedLogs, localLogs) {
    const result = { ...(localLogs && typeof localLogs === 'object' ? localLogs : {}) };
    if (seedLogs && typeof seedLogs === 'object') {
        Object.keys(seedLogs).forEach(petId => {
            result[petId] = seedLogs[petId];
        });
    }
    return result;
}

function normalizeOrders(orders) {
    return (Array.isArray(orders) ? orders : []).map(order => {
        const subtotal = toNumber(order?.pricing?.subtotal);
        const shippingFee = toNumber(order?.pricing?.shippingFee);
        const discount = toNumber(order?.pricing?.discount);
        const itemTotals = Array.isArray(order?.products)
            ? order.products.reduce((sum, item) => sum + toNumber(item?.total, toNumber(item?.price) * toNumber(item?.quantity, 1)), 0)
            : 0;
        const resolvedSubtotal = subtotal > 0 ? subtotal : itemTotals;
        const resolvedTotal = toNumber(order?.pricing?.total, resolvedSubtotal + shippingFee - discount);

        return {
            ...order,
            products: Array.isArray(order?.products)
                ? order.products.map(item => ({
                    ...item,
                    quantity: toNumber(item?.quantity, 1),
                    price: toNumber(item?.price),
                    total: toNumber(item?.total, toNumber(item?.price) * toNumber(item?.quantity, 1))
                }))
                : [],
            pricing: {
                ...(order?.pricing || {}),
                subtotal: resolvedSubtotal,
                shippingFee,
                discount,
                total: resolvedTotal > 0 ? resolvedTotal : Math.max(0, resolvedSubtotal + shippingFee - discount)
            }
        };
    });
}

function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function sameUser(user, currentUser) {
    return sameUserId(user.id, currentUser.id)
        || (user.phone && currentUser.phone && String(user.phone) === String(currentUser.phone));
}

function sameUserId(a, b) {
    return a != null && b != null && String(a) === String(b);
}

API.initData();

window.API = API;
