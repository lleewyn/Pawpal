
const dataCache = {
    products: null,
    services: null,
    blogs: null,
    blogCategories: null
};

function parseCSV(csvText) {
    const data = [];
    let row = [];
    let field = '';
    let inQuotes = false;
    
    for (let i = 0; i < csvText.length; i++) {
        const char = csvText[i];
        const nextChar = csvText[i + 1];
        
        if (char === '"') {
            if (inQuotes && nextChar === '"') {
                field += '"';
                i++; 
            } else {
                inQuotes = !inQuotes;
            }
        } else if (char === '\t' && !inQuotes) {
            row.push(field.trim());
            field = '';
        } else if ((char === '\r' || char === '\n') && !inQuotes) {
            if (char === '\r' && nextChar === '\n') {
                i++; 
            }
            if (field || row.length > 0) {
                row.push(field.trim());
                data.push(row);
            }
            row = [];
            field = '';
        } else {
            field += char;
        }
    }
    
    if (field || row.length > 0) {
        row.push(field.trim());
        data.push(row);
    }
    
    if (data.length === 0) return [];
    
    const headers = data[0].map(h => {
        let cleaned = h.trim();
        if (cleaned.startsWith('"') && cleaned.endsWith('"')) {
            cleaned = cleaned.slice(1, -1);
        }
        return cleaned;
    });
    
    const result = [];
    for (let i = 1; i < data.length; i++) {
        const rowData = data[i];
        if (rowData.length === 0 || (rowData.length === 1 && rowData[0] === '')) continue;
        
        const obj = {};
        headers.forEach((header, index) => {
            let val = rowData[index] || '';
            if (val.startsWith('"') && val.endsWith('"')) {
                val = val.slice(1, -1);
            }
            obj[header] = val;
        });
        result.push(obj);
    }
    
    return result;
}

function transformProductData(rawData) {
    return rawData.map((item, index) => {
        const categoryMap = {
            'Thức ăn khô': 'food-dry',
            'Thức ăn ướt': 'food-wet',
            'Xương gặm': 'bones',
            'Sức khỏe': 'health',
            'Đồ chơi': 'toys',
            'Quần áo': 'clothes',
            'Vệ sinh': 'hygiene',
            'Bát ăn': 'bowls',
            'Chăm sóc': 'grooming',
            'Phụ kiện': 'accessories',
            'Nội thất': 'furniture',
            'Khác': 'other'
        };
        
        const category = categoryMap[item['Danh mục (Category)']] || 'other';
        
        const price = parseInt(item['Giá sau tích điểm']?.replace(/\./g, '').replace(/[^\d]/g, '') || item['Giá bán lẻ']?.replace(/\./g, '').replace(/[^\d]/g, '') || '0');
        const originalPrice = parseInt(item['Giá bán lẻ']?.replace(/\./g, '').replace(/[^\d]/g, '') || '0');
        
        const sale = price < originalPrice;
        
        const stock = parseInt(item['Số lượng tồn kho (Inventory)'] || '0');
        const inStock = item['Trạng thái']?.toLowerCase().includes('còn hàng') || item['Trạng thái']?.toLowerCase() === 'available';
        
        let badge = null;
        const label = item['Nhãn sản phẩm']?.toLowerCase() || '';
        if (label.includes('bán chạy')) badge = 'best';
        else if (label.includes('mới')) badge = 'new';
        else if (label.includes('khuyên dùng')) badge = 'hot';
        
        const rating = parseFloat(item['Đánh giá (Rating)'] || '4.5');
        const reviewCount = parseInt(item['Lượt đánh giá (Review Count)'] || '0');
        
            let rawImagesStr = item['Hình ảnh'] || '';
            const rootPath = window.pawpalGetRootPath ? window.pawpalGetRootPath() : '../../';
            let parsedImages = rawImagesStr ? rawImagesStr.split(',').map(s => rootPath + s.trim()) : [rootPath + 'assets/images/shop/products/placeholder.webp'];

            return {
                id: index + 1,
                dbId: null,
                sku: item['Mã sản phẩm (SKU)'] || `PROD-${index + 1}`,
                name: item['Tên sản phẩm'] || 'Sản phẩm không tên',
                brand: item['Thương hiệu (Brand)'] || 'Chưa xác định',
                category: category,
                categoryName: item['Danh mục (Category)'] || 'Khác',
                price: price,
                originalPrice: sale ? originalPrice : null,
                oldPrice: sale ? originalPrice : null,
                image: parsedImages[0],
                images: parsedImages,
            inStock: inStock,
            stock: stock,
            sale: sale,
            badge: badge,
            trending: badge === 'hot' || badge === 'best',
            rating: rating,
            reviewCount: reviewCount,
            origin: item['Xuất xứ'] || 'Chưa rõ',
            ingredients: item['Thành phần'] || '',
            benefits: item['Công dụng'] || '',
            usage: item['Hướng dẫn sử dụng'] || '',
            specs: item['Thuộc tính đặc biệt / Quy cách đóng gói'] || '',
            description: item['Công dụng'] || item['Thành phần'] || 'Thông tin sản phẩm đang được cập nhật.'
        };
    });
}

async function loadProducts() {
    if (dataCache.products) {
        return dataCache.products;
    }
    
    try {
        const db = window.SupabaseClient;
        if (!db) {
            throw new Error('Supabase client is not initialized');
        }

        console.log('Loading products from Supabase...');
        const { data: rawProducts, error } = await db.from('product').select('*, product_category!inner(category_name), product_variant(*, inventory(quantity_in_stock))');
        
        if (error) {
            throw error;
        }

        console.log(` Loaded ${rawProducts.length} products from Supabase`);
        const rootPath = window.pawpalGetRootPath ? window.pawpalGetRootPath() : '../../';
        
        const knownBrands = ['Royal Canin', 'Pedigree', 'Me-O', 'Whiskas', "Hill's", 'Purina', 'Kong', 'Taste of the Wild', 'Frontline', 'Furminator', 'Nylabone', 'Hartz', "King's Pet", 'Inaba', 'Nutrience', 'Zenith', 'Orijen', 'Acana', 'GimCat', 'Gimborn', 'TropiClean', 'Bio-Pharmachemie'];

        const products = rawProducts.map(item => {
            // Prices belong to variants; use the lowest available active variant price.
            const variants = Array.isArray(item.product_variant) ? item.product_variant : [];
            const pricedVariants = variants
                .filter(variant => (variant.status === 'dang_ban' || variant.status === 'ACTIVE') && variant.sale_price != null
                    && Number.isFinite(Number(variant.sale_price)) && Number(variant.sale_price) >= 0)
                .sort((a, b) => Number(a.sale_price) - Number(b.sale_price));
            const baseVariant = pricedVariants[0] || variants[0] || null;
            const price = baseVariant && baseVariant.sale_price != null ? Number(baseVariant.sale_price) : (Number(item.sale_price) || 0);
            const compareAtPrice = baseVariant?.compare_at_price != null
                ? Number(baseVariant.compare_at_price)
                : (baseVariant?.cost_price != null ? Number(baseVariant.cost_price) : (Number(item.cost_price) || null));
            const sale = price !== null && Number.isFinite(compareAtPrice) && compareAtPrice > price;
            const effectiveSku = baseVariant?.sku_variant || item.sku || '';
            let images = [];
            if (Array.isArray(item.image_urls)) {
                images = item.image_urls.map(url => rootPath + url);
            }
            if (images.length === 0) images = [rootPath + 'assets/images/shop/products/placeholder.webp'];

            let badgeStr = item.badge ? String(item.badge).toLowerCase() : null;
            
            let stockCount = 0;
            for (const v of variants) {
                if (v.inventory) {
                    if (Array.isArray(v.inventory)) {
                        stockCount += v.inventory.reduce((sum, inv) => sum + Number(inv.quantity_in_stock || 0), 0);
                    } else {
                        stockCount += Number(v.inventory.quantity_in_stock || 0);
                    }
                }
            }

            // Guess brand from product_name
            let detectedBrand = 'PawPal';
            if (item.product_name) {
                const lowerName = item.product_name.toLowerCase();
                for (const b of knownBrands) {
                    if (lowerName.includes(b.toLowerCase())) {
                        detectedBrand = b;
                        break;
                    }
                }
            }

            return {
                id: item.id,
                sku: effectiveSku,
                name: item.product_name,
                brand: item.brand_name || detectedBrand,
                brand_name: item.brand_name || detectedBrand,
                target_pet: item.target_pet || 'Chó và Mèo',
                targetPet: item.target_pet || 'Chó và Mèo',
                category: item.category_id,
                categoryName: item.product_category?.category_name || 'Khác',
                price,
                originalPrice: sale ? compareAtPrice : null,
                oldPrice: sale ? compareAtPrice : null,
                image: images[0],
                images: images,
                inStock: (item.status === 'ACTIVE' || item.status === 'dang_ban') && stockCount > 0,
                stock: stockCount,
                sale: sale,
                badge: badgeStr,
                trending: badgeStr === 'hot' || badgeStr === 'best',
                rating: Number(item.rating) || 4.5,
                reviewCount: Number(item.review_count) || 0,
                origin: item.origin || 'Chưa rõ',
                ingredients: item.ingredients || '',
                benefits: item.benefits || item.description || '',
                usage: item.usage_instructions || '',
                specs: item.specs || '',
                description: item.description || '',
                variants: variants.map(v => ({
                    id: v.id,
                    sku: v.sku_variant,
                    price: Number(v.sale_price) || 0,
                    costPrice: Number(v.cost_price) || 0,
                    comparePrice: v.compare_at_price ? Number(v.compare_at_price) : null
                }))
            };
        });
        
        dataCache.products = products;
        return products;
    } catch (error) {
        console.error('Error loading products from Supabase:', error);
        return [];
    }
}

async function getProductById(productId) {
    const products = await loadProducts();
    const product = products.find(p => p.id === productId);
    
    if (!product) {
        console.error(` Product not found: ID ${productId}`);
        return null;
    }
    
    console.log(` Found product:`, product.name);
    return product;
}

async function getProductsByCategory(category) {
    const products = await loadProducts();
    return products.filter(p => p.category === category);
}

async function getProductsByBrand(brand) {
    const products = await loadProducts();
    return products.filter(p => p.brand === brand);
}

async function searchProducts(keyword) {
    const products = await loadProducts();
    const lowerKeyword = keyword.toLowerCase();
    
    return products.filter(p => 
        p.name.toLowerCase().includes(lowerKeyword) ||
        p.brand.toLowerCase().includes(lowerKeyword) ||
        p.description.toLowerCase().includes(lowerKeyword)
    );
}

async function loadComponent(placeholderId, componentPath) {
    const el = document.getElementById(placeholderId);
    if (!el) {
        console.warn(`[loadComponent] Target not found: #${placeholderId}`);
        return;
    }
    try {
        const response = await fetch(componentPath);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const html = await response.text();
        el.innerHTML = html;
        el.querySelectorAll('script').forEach(function(oldScript) {
            const newScript = document.createElement('script');
            Array.from(oldScript.attributes).forEach(function(attr) {
                newScript.setAttribute(attr.name, attr.value);
            });
            newScript.textContent = oldScript.textContent;
            oldScript.parentNode.replaceChild(newScript, oldScript);
        });
        (function tryLucide() {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            } else {
                setTimeout(tryLucide, 100);
            }
        })();
        console.log(`[loadComponent] Injected: #${placeholderId}`);
    } catch (err) {
        console.error(`[loadComponent] Failed to load ${componentPath}:`, err);
    }
}

function transformServiceData(rawData) {
    return rawData.map((item, index) => {
        const rawCategory = item['Phân loại'] || '';
        let category = 'other';
        if (rawCategory.includes('Spa và Grooming') || rawCategory.includes('Spa & Grooming')) {
            category = 'spa';
        } else if (rawCategory.includes('Pet Hotel')) {
            category = 'hotel';
        } else if (rawCategory.includes('Pet Taxi')) {
            category = 'taxi';
        }

        const priceSub5 = parseInt(item['Giá <5kg (VNĐ)']?.replace(/[^\d]/g, '') || '0', 10);
        const price5to10 = parseInt(item['Giá 5-10kg (VNĐ)']?.replace(/[^\d]/g, '') || '0', 10);
        const price10to20 = parseInt(item['Giá 10-20kg (VNĐ)']?.replace(/[^\d]/g, '') || '0', 10);
        const priceOver20 = parseInt(item['Giá >20kg (VNĐ)']?.replace(/[^\d]/g, '') || '0', 10);

        const prices = {
            '< 5kg': priceSub5,
            '5 - 10kg': price5to10,
            '10 - 20kg': price10to20,
            '> 20kg': priceOver20
        };

        const validPrices = Object.values(prices).filter(p => p > 0);
        const basePrice = validPrices.length > 0 ? Math.min(...validPrices) : 0;

        const rating = parseFloat(item['Đánh giá (Rating)'] || '4.8');
        const reviewCount = parseInt(item['Lượt đánh giá (Review Count)'] || '0', 10);

        const rootPath = window.pawpalGetRootPath ? window.pawpalGetRootPath() : '../../';
        const cleanImagePath = (rawPath) => {
            const trimmed = rawPath.trim();
            return trimmed.replace(/^\/*/, '');
        };
        const serviceImages = item['Hình ảnh'] ? item['Hình ảnh'].split(',').map(s => rootPath + cleanImagePath(s)) : [rootPath + 'assets/images/services/spa.png'];

        return {
            id: index + 1,
            dbId: null,
            serviceId: item['Mã dịch vụ (Service ID)'] || `SVC-${index + 1}`,
            name: item['Tên dịch vụ'] || 'Dịch vụ',
            category: category,
            rawCategory: rawCategory,
            petType: item['Loại thú cưng'] || 'Tất cả',
            weightClass: validPrices.length > 0 ? 'Tùy chọn cân nặng' : 'Tất cả',
            price: basePrice,
            prices: prices,
            priceDisplay: category === 'hotel' ? 'đêm' : '',
            memberPrice: item['Giá ưu đãi thành viên (VNĐ)'] || '',
            duration: item['Thời gian thực hiện (Duration)'] || '',
            rating: rating,
            reviewCount: reviewCount,
            description: item['Mô tả chi tiết (Description)'] || '',
            benefits: item['Lợi ích chính (Key Benefits)'] || '',
            checklist: item['Quy trình thực hiện (Checklist)'] || '',
            amenities: item['Tiện ích / Cơ sở vật chất (Amenities)'] || '',
            groomerLevel: item['Cấp độ nhân viên thực hiện (Groomer Level)'] || '',
            image: serviceImages[0],
            images: serviceImages,
            status: item['Trạng thái kinh doanh'] || 'Đang phục vụ'
        };
    });
}

async function loadServices() {
    if (dataCache.services) {
        console.log(' Using cached services data');
        return dataCache.services;
    }
    
    try {
        const supabase = window.SupabaseClient;
        if (!supabase) throw new Error("Supabase client not found");

        console.log('Loading services from Supabase...');
        const { data: servicesData, error: servicesError } = await supabase
            .from('service')
            .select('*')
            .order('service_code');

        if (servicesError) throw servicesError;

        const { data: pricesData, error: pricesError } = await supabase
            .from('service_price_matrix')
            .select('*')
            .eq('status', 'dang_hoat_dong')
            .is('effective_to', null);

        if (pricesError) throw pricesError;

        const rootPath = window.pawpalGetRootPath ? window.pawpalGetRootPath() : '../../';
        const cleanImagePath = (rawPath) => {
            if (!rawPath) return '';
            const trimmed = rawPath.trim();
            return rootPath + trimmed.replace(/^\/*/, '');
        };

        const services = servicesData.map((svc, index) => {
            let category = 'spa';
            if (svc.service_category === 'PET_HOTEL' || svc.service_category === 'khach_san_thu_cung') category = 'hotel';
            else if (svc.service_category === 'PET_TAXI' || svc.service_category === 'dua_don_tan_noi') category = 'taxi';

            const name = String(svc.service_name || '').toLowerCase();
            const code = String(svc.service_code || '').toUpperCase();
            if (code.startsWith('HTL') || name.includes('phòng') || name.includes('lưu trú') || name.includes('daycare')) category = 'hotel';
            if (code.startsWith('TAX') || name.includes('taxi')) category = 'taxi';

            const svcPrices = pricesData.filter(p => p.service_id === svc.id);
            const prices = {};
            let basePrice = 0;
            
            if (svcPrices.length > 0) {
                svcPrices.forEach(p => {
                    let label = '';
                    if (p.weight_to < 5) label = '< 5kg';
                    else if (p.weight_from >= 5 && p.weight_to <= 10) label = '5 - 10kg';
                    else if (p.weight_from >= 10 && p.weight_to <= 20) label = '10 - 20kg';
                    else if (p.weight_from >= 20) label = '> 20kg';
                    else label = 'Khác';
                    
                    if (label) prices[label] = p.unit_price;
                });
                const validPrices = Object.values(prices).filter(p => p > 0);
                if (validPrices.length > 0) {
                    basePrice = Math.min(...validPrices);
                }
            }

            let imageList = [cleanImagePath(svc.thumbnail_url)];
            if (svc.images && Array.isArray(svc.images) && svc.images.length > 0) {
                imageList = svc.images.map(img => cleanImagePath(img));
            }

            return {
                id: index + 1,
                dbId: svc.id,
                serviceId: svc.service_code,
                name: svc.service_name,
                category: category,
                rawCategory: svc.service_category,
                petType: svc.pet_type || 'Tất cả',
                weightClass: basePrice > 0 ? 'Tùy chọn cân nặng' : 'Tất cả',
                price: basePrice,
                prices: prices,
                priceDisplay: category === 'hotel' ? 'đêm' : '',
                memberPrice: '', // We don't have this in DB yet
                duration: svc.estimated_duration ? `${svc.estimated_duration} phút` : '',
                rating: parseFloat(svc.rating || 4.8),
                reviewCount: parseInt(svc.review_count || 0),
                description: svc.description || '',
                benefits: svc.benefits || '',
                checklist: svc.checklist || '',
                amenities: svc.amenities || '',
                groomerLevel: svc.groomer_level || '',
                image: imageList[0],
                images: imageList,
                status: (svc.status === 'dang_hoat_dong' || svc.status === 'ACTIVE') ? 'Đang phục vụ' : 'Ngưng phục vụ'
            };
        });

        if (services.length > 0) {
            console.log(` Transformed ${services.length} services from DB`);
            dataCache.services = services;
            return services;
        }
        throw new Error("Supabase returned empty services list");
    } catch (error) {
        console.warn(' Error loading services from DB, falling back to CSV:', error);
        try {
            let csvText = '';
            try {
                const res = await fetch('/data/dichvu.csv');
                if (res.ok) csvText = await res.text();
            } catch (e) {
                const res = await fetch('../../data/dichvu.csv');
                if (res.ok) csvText = await res.text();
            }
            if (csvText) {
                const rawData = parseCSV(csvText);
                const csvServices = transformServiceData(rawData);
                console.log(` Loaded ${csvServices.length} services from CSV fallback`);
                dataCache.services = csvServices;
                return csvServices;
            }
        } catch (csvErr) {
            console.error(' Failed to load services from CSV fallback:', csvErr);
        }
        return [];
    }
}

async function getServiceById(serviceId) {
    if (!serviceId) return null;
    const services = await loadServices();
    if (!services || services.length === 0) return null;

    const rawQuery = String(serviceId).trim();
    const cleanQuery = rawQuery.toLowerCase().replace(/[-_\s]/g, '');

    // 1. Exact match by serviceId
    let service = services.find(s => s.serviceId === rawQuery);

    // 2. Case-insensitive match by serviceId
    if (!service) {
        service = services.find(s => String(s.serviceId || '').toLowerCase() === rawQuery.toLowerCase());
    }

    // 3. Normalized match (e.g., HTL01 matches HTL-01 or HTL01)
    if (!service) {
        service = services.find(s => {
            const sCode = String(s.serviceId || '').toLowerCase().replace(/[-_\s]/g, '');
            return sCode === cleanQuery;
        });
    }

    // 4. Match by dbId or numeric id
    if (!service) {
        service = services.find(s => String(s.dbId) === rawQuery || String(s.id) === rawQuery);
    }

    // 5. Match by partial code
    if (!service) {
        service = services.find(s => {
            const sCode = String(s.serviceId || '').toLowerCase();
            return sCode.includes(rawQuery.toLowerCase()) || rawQuery.toLowerCase().includes(sCode);
        });
    }

    if (!service) {
        console.error(` Service not found: ID ${serviceId}`);
        return null;
    }
    
    console.log(` Found service:`, service.name);
    return service;
}

async function getProductReviews(productId) {
    if (!window.SupabaseClient) {
        console.warn('Supabase not available for fetching reviews.');
        return [];
    }
    const db = window.SupabaseClient;
    if (!db) return [];

    try {
        const { data, error } = await db
            .from('review')
            .select(`
                *,
                customer:customer_id (
                    customer_profile (full_name)
                )
            `)
            .eq('product_id', productId)
            .eq('review_status', 'da_duyet')
            .order('created_at', { ascending: false });

        if (error) throw error;
        
        return data.map(r => ({
            id: r.id,
            rating: r.rating,
            content: r.review_content,
            createdAt: r.created_at,
            customerName: Array.isArray(r.customer?.customer_profile)
                ? (r.customer.customer_profile[0]?.full_name || 'Khách hàng')
                : (r.customer?.customer_profile?.full_name || 'Khách hàng'),
            hasMedia: r.image_urls && r.image_urls.length > 0,
            media: r.image_urls || [],
            hasReply: !!r.shop_reply,
            shopReply: r.shop_reply || ''
        }));
    } catch (err) {
        console.error('Error fetching product reviews:', err);
        return [];
    }
}

async function getServiceReviews(serviceId) {
    const supabase = window.SupabaseClient;
    if (!supabase) return [];
    try {
        const { data, error } = await supabase
            .from('review')
            .select(`
                id,
                rating,
                review_content,
                image_urls,
                created_at,
                customer (
                    customer_profile (
                        full_name
                    )
                ),
                review_response (
                    response_content
                )
            `)
            .eq('review_type', 'dich_vu')
            .eq('service_id', serviceId)
            .order('created_at', { ascending: false });

        if (error) throw error;
        
        const getTierName = (tierStr) => {
            if (!tierStr) return 'Thành viên';
            const t = tierStr.toLowerCase();
            switch(t) {
                case 'diamond': return 'Hội viên Kim Cương';
                case 'gold': return 'Hội viên Vàng';
                case 'silver': return 'Hội viên Bạc';
                default: return 'Thành viên';
            }
        };

        return data.map(r => {
            const rawTier = r.customer?.membership_tier?.name ? r.customer.membership_tier.name.toLowerCase() : 'member';
            const sellerReply = (r.review_response && r.review_response.length > 0) ? r.review_response[0].response_content : null;
            
            return {
                id: r.id,
                name: Array.isArray(r.customer?.customer_profile)
                    ? (r.customer.customer_profile[0]?.full_name || 'Khách hàng')
                    : (r.customer?.customer_profile?.full_name || 'Khách hàng'),
                tier: rawTier,
                tierName: getTierName(rawTier),
                rating: r.rating,
                date: r.created_at ? new Date(r.created_at).toLocaleDateString('vi-VN') : '',
                text: r.review_content,
                images: r.image_urls || [],
                sellerReply: sellerReply,
                helpfulCount: Math.floor(Math.random() * 10) + 1
            };
        });
    } catch (error) {
        console.error('Error fetching service reviews:', error);
        return [];
    }
}

async function loadBlogCategories() {
    if (dataCache.blogCategories) return dataCache.blogCategories;

    try {
        const db = window.SupabaseClient;
        if (!db) throw new Error('Supabase client is not initialized');

        const { data, error } = await db.from('blog_category').select('*').order('display_order', { ascending: true });
        if (error) throw error;

        dataCache.blogCategories = data;
        return data;
    } catch (error) {
        console.error('Error fetching blog categories:', error);
        return [];
    }
}

async function loadBlogs(forceRefresh = false) {
    if (!forceRefresh && dataCache.blogs?.length) return dataCache.blogs;

    try {
        const db = window.getSupabaseClient?.() || window.SupabaseClient;
        if (!db) throw new Error('Supabase client is not initialized');

        const { data, error } = await db.from('blog_post').select('*, blog_category(category_name)').eq('status', 'PUBLISHED').order('publish_at', { ascending: false });
        if (error) throw error;

        const rootPath = window.pawpalGetRootPath ? window.pawpalGetRootPath() : '../../';
        const formatted = data.map(item => {
            return {
                id: item.id,
                title: item.title,
                slug: item.slug,
                summary: item.summary,
                content: item.content,
                thumbnail: item.thumbnail_url ? (item.thumbnail_url.startsWith('http') ? item.thumbnail_url : rootPath + item.thumbnail_url.replace(/^[\/\\]+/, '')) : rootPath + 'assets/images/shop/products/placeholder.webp',
                authorId: item.author_id,
                date: item.publish_at || item.created_at,
                viewCount: item.view_count || 0,
                categoryId: item.category_id,
                categoryName: item.blog_category?.category_name || 'Uncategorized',
                categorySlug: item.blog_category?.category_name ? item.blog_category.category_name.toLowerCase().replace(/[^a-z0-9]+/g, '-') : 'uncategorized'
            };
        });

        dataCache.blogs = formatted;
        return formatted;
    } catch (error) {
        console.error('Error fetching blogs:', error);
        throw error;
    }
}

async function loadBanners() {
    if (dataCache.banners) return dataCache.banners;

    try {
        const db = window.SupabaseClient || (window.getSupabaseClient ? window.getSupabaseClient() : null);
        if (!db) throw new Error('Supabase client is not initialized');

        const { data, error } = await db.from('banner')
            .select('*')
            .or('status.eq.dang_hien_thi,status.eq.ACTIVE')
            .order('created_at', { ascending: false });

        if (error) throw error;

        const rootPath = window.pawpalGetRootPath ? window.pawpalGetRootPath() : '../../';
        const banners = (data || []).map(b => {
            let imgUrl = b.image_url || b.image_desktop_url || '';
            if (imgUrl && !imgUrl.startsWith('http') && !imgUrl.startsWith('/')) {
                imgUrl = rootPath + imgUrl;
            }
            return {
                id: b.id,
                title: b.title || 'Ưu đãi PawPal',
                image: imgUrl || '/assets/images/banners/spa_animation.png',
                link: b.link || b.target_url || '/pages/services/services.html',
                buttonText: b.button_text || b.cta_text || 'Xem ngay',
                status: b.status || (b.is_active ? 'active' : 'paused')
            };
        });

        dataCache.banners = banners;
        return banners;
    } catch (error) {
        console.warn('Error fetching banners from Supabase:', error);
        return [];
    }
}

window.DataLoader = {
    loadProducts,
    getProductById,
    getProductsByCategory,
    getProductsByBrand,
    searchProducts,
    loadServices,
    getServiceById,
    getProductReviews,
    getServiceReviews,
    loadBlogs,
    loadBlogCategories,
    loadBanners
};

console.log(' DataLoader module initialized');

